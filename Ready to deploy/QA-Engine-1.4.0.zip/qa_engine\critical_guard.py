"""Keeps an unproven critical fail from zeroing a call: it must quote a line the agent said that bears on the check's rules."""

import re


class CriticalGuard:
    """Marks as unverified every critical fail whose reason does not quote an agent line found in the transcript.

    A critical fail sets the whole score to 0, so it needs evidence a person can check. A small model sometimes writes a
    "violation" that is not in the call at all, or quotes a real line that has nothing to do with the rule. Such a
    verdict is not dropped: it is marked ``unverified`` and the score calculator turns it into a "needs review" flag
    instead of an automatic 0. The quote is "relevant" when it shares a meaningful word with the check's label or rules.
    """

    AGENT_LINE: re.Pattern[str] = re.compile(r"^\s*agent\s*:\s*(.*)$", re.IGNORECASE)
    ROLE_LINE: re.Pattern[str] = re.compile(r"^\s*(?:agent|customer)\s*:", re.IGNORECASE)
    DOUBLE_QUOTED: re.Pattern[str] = re.compile(r"[\"“]([^\"”]{8,}?)[\"”]")
    SINGLE_QUOTED: re.Pattern[str] = re.compile(r"(?<![A-Za-z])['‘]([^'’]{8,}?)['’](?![A-Za-z])")
    MIN_WORDS: int = 3
    MEANINGFUL: re.Pattern[str] = re.compile(r"[0-9a-zà-ÿ]{4,}")
    COMMON_WORDS: frozenset[str] = frozenset((
        "agent", "customer", "caller", "call", "calls", "check", "that", "this", "with", "from", "your", "have", "been", "does",
        "they", "them", "when", "only", "also", "into", "than", "then", "there", "what", "will", "would", "about", "before",
        "after", "never", "always", "must", "which", "their", "these", "those", "were", "such", "even", "some", "same", "line",
        "says", "said", "mark", "rule", "rules", "passed", "false", "true", "transcript", "mention", "mentions", "language"))

    @staticmethod
    def apply(rubric: dict, verdicts: dict[str, dict], transcript: str) -> dict[str, dict]:
        """Sets ``unverified`` on the failed critical verdicts that quote nothing real; returns the same dict."""
        agent_text: str = CriticalGuard._agent_text(transcript)
        for check in rubric.get("checks", []):
            verdict: dict | None = verdicts.get(check.get("key"))
            if not verdict or verdict.get("passed") or not check.get("critical") or verdict.get("computed"):
                continue
            rule_words: set[str] = CriticalGuard._meaningful(" ".join([check.get("label") or ""] + list(check.get("rules") or [])))
            if not CriticalGuard.quotes_agent(verdict.get("reason") or "", agent_text, rule_words):
                verdict["unverified"] = True
        return verdicts

    @staticmethod
    def quotes_agent(reason: str, agent_text: str, rule_words: set[str] | None = None) -> bool:
        """True when some quoted part of the reason (at least a few words) appears in the agent's own lines.

        :param rule_words: the meaningful words of the check; when given, the quote must also share one of them, so a
            real but unrelated line ("Of course, I can help in Portuguese") is not accepted as evidence
        """
        quotes: list[str] = CriticalGuard.DOUBLE_QUOTED.findall(reason) + CriticalGuard.SINGLE_QUOTED.findall(reason)
        for quote in quotes:
            for fragment in re.split(r"\.\.\.|…", quote):
                words: str = CriticalGuard._normalize(fragment)
                if len(words.split()) < CriticalGuard.MIN_WORDS or words not in agent_text:
                    continue
                if rule_words is None or CriticalGuard._meaningful(words) & rule_words:
                    return True
        return False

    @staticmethod
    def _meaningful(text: str) -> set[str]:
        """The words (four letters or more, not everyday filler) that carry the meaning of a rule or a quote."""
        return {word for word in CriticalGuard.MEANINGFUL.findall(CriticalGuard._normalize(text)) if word not in CriticalGuard.COMMON_WORDS}

    @staticmethod
    def _agent_text(transcript: str) -> str:
        """The normalized text of the agent's lines (the whole call when it has no role prefixes)."""
        lines: list[str] = [line for line in (transcript or "").splitlines() if line.strip()]
        agent_lines: list[str] = [m.group(1) for m in (CriticalGuard.AGENT_LINE.match(line) for line in lines) if m]
        if not any(CriticalGuard.ROLE_LINE.match(line) for line in lines):
            agent_lines = lines
        return CriticalGuard._normalize(" ".join(agent_lines))

    @staticmethod
    def _normalize(text: str) -> str:
        """Lower case, letters and digits only, single spaces."""
        return " ".join(re.sub(r"[^0-9a-zà-ÿ]+", " ", (text or "").lower()).split())
