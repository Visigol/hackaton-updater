-- QA Platform: multi-tenant schema (pool model + Row-Level Security) for Supabase.
-- Run once in Supabase Dashboard -> SQL Editor. Safe to re-run only on an empty project.

create extension if not exists vector;

-- ---------------------------------------------------------------------------
-- Tenants and users
-- ---------------------------------------------------------------------------
create table public.tenants (
    id              uuid primary key default gen_random_uuid(),
    name            text not null,
    slug            text not null unique,
    status          text not null default 'active',
    branding_config jsonb not null default '{}'::jsonb,
    created_at      timestamptz not null default now()
);

create table public.users (
    id         uuid primary key references auth.users (id) on delete cascade,
    tenant_id  uuid not null references public.tenants (id),
    email      text not null,
    role       text not null check (role in ('admin', 'supervisor', 'team_lead', 'agent')),
    created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Helpers used by every policy. SECURITY DEFINER avoids recursive RLS on public.users.
-- plpgsql so the body is resolved lazily (public.users already exists here anyway).
-- ---------------------------------------------------------------------------
create or replace function public.current_tenant_id() returns uuid
language plpgsql stable security definer set search_path = public as $$
begin
    return (select tenant_id from public.users where id = auth.uid());
end $$;

create or replace function public.current_user_role() returns text
language plpgsql stable security definer set search_path = public as $$
begin
    return (select role from public.users where id = auth.uid());
end $$;

-- ---------------------------------------------------------------------------
-- Tenant-scoped tables. tenant_id defaults to the caller's tenant.
-- ---------------------------------------------------------------------------
create table public.rubrics (
    id          uuid primary key default gen_random_uuid(),
    tenant_id   uuid not null default public.current_tenant_id() references public.tenants (id),
    version     int not null,
    is_active   boolean not null default false,
    parameters  jsonb not null default '{}'::jsonb,
    approved_by uuid references public.users (id),
    created_at  timestamptz not null default now(),
    unique (tenant_id, version)
);

create table public.rubric_change_requests (
    id            uuid primary key default gen_random_uuid(),
    tenant_id     uuid not null default public.current_tenant_id() references public.tenants (id),
    proposed_by   text not null default 'user' check (proposed_by in ('system', 'user')),
    source_doc_id uuid,
    diff          jsonb not null default '{}'::jsonb,
    status        text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
    created_at    timestamptz not null default now()
);

create table public.knowledge_base_docs (
    id          uuid primary key default gen_random_uuid(),
    tenant_id   uuid not null default public.current_tenant_id() references public.tenants (id),
    title       text not null,
    source_url  text,
    embedding   vector(1536),
    uploaded_at timestamptz not null default now()
);

create table public.transcripts (
    id          uuid primary key default gen_random_uuid(),
    tenant_id   uuid not null default public.current_tenant_id() references public.tenants (id),
    agent_name  text not null,
    channel     text not null default 'voice',
    raw_text    text not null,
    uploaded_at timestamptz not null default now()
);

create table public.audit_scores (
    id             uuid primary key default gen_random_uuid(),
    tenant_id      uuid not null default public.current_tenant_id() references public.tenants (id),
    transcript_id  uuid not null references public.transcripts (id) on delete cascade,
    rubric_version int not null,
    scores         jsonb not null default '{}'::jsonb,
    flags          jsonb not null default '[]'::jsonb,
    overall_score  numeric(5, 2),
    scored_at      timestamptz not null default now()
);

create table public.performance_reports (
    id              uuid primary key default gen_random_uuid(),
    tenant_id       uuid not null default public.current_tenant_id() references public.tenants (id),
    agent_name      text not null,
    period          text not null,
    trends          jsonb not null default '{}'::jsonb,
    recommendations jsonb not null default '[]'::jsonb,
    generated_at    timestamptz not null default now()
);

create table public.notifications_log (
    id        uuid primary key default gen_random_uuid(),
    tenant_id uuid not null default public.current_tenant_id() references public.tenants (id),
    type      text not null,
    recipient text not null,
    payload   jsonb not null default '{}'::jsonb,
    sent_at   timestamptz not null default now()
);

create index on public.audit_scores (tenant_id, scored_at desc);
create index on public.transcripts (tenant_id, uploaded_at desc);

-- ---------------------------------------------------------------------------
-- Row-Level Security
-- ---------------------------------------------------------------------------
alter table public.tenants enable row level security;
alter table public.users   enable row level security;

create policy tenants_select on public.tenants for select to authenticated
    using (id = public.current_tenant_id());

create policy users_select on public.users for select to authenticated
    using (tenant_id = public.current_tenant_id());

create policy users_admin_insert on public.users for insert to authenticated
    with check (tenant_id = public.current_tenant_id() and public.current_user_role() = 'admin');
create policy users_admin_update on public.users for update to authenticated
    using (tenant_id = public.current_tenant_id() and public.current_user_role() = 'admin')
    with check (tenant_id = public.current_tenant_id());
create policy users_admin_delete on public.users for delete to authenticated
    using (tenant_id = public.current_tenant_id() and public.current_user_role() = 'admin');

-- Same pattern on every tenant-scoped table. Agents (role 'agent') get no access to
-- these tables for now; per-agent visibility is a later, explicit policy.
do $$
declare
    table_name text;
begin
    foreach table_name in array array[
        'rubrics', 'rubric_change_requests', 'knowledge_base_docs',
        'transcripts', 'audit_scores', 'performance_reports', 'notifications_log'
    ]
    loop
        execute format('alter table public.%I enable row level security', table_name);
        execute format(
            'create policy tenant_select on public.%I for select to authenticated
             using (tenant_id = public.current_tenant_id() and public.current_user_role() <> ''agent'')',
            table_name);
        execute format(
            'create policy tenant_insert on public.%I for insert to authenticated
             with check (tenant_id = public.current_tenant_id() and public.current_user_role() <> ''agent'')',
            table_name);
        execute format(
            'create policy tenant_update on public.%I for update to authenticated
             using (tenant_id = public.current_tenant_id() and public.current_user_role() <> ''agent'')
             with check (tenant_id = public.current_tenant_id())',
            table_name);
        execute format(
            'create policy tenant_delete on public.%I for delete to authenticated
             using (tenant_id = public.current_tenant_id() and public.current_user_role() <> ''agent'')',
            table_name);
    end loop;
end $$;

-- ---------------------------------------------------------------------------
-- Tenant onboarding (step 1-2 of the onboarding flow): creates the tenant and seeds
-- the default rubric. Not callable from the browser; run it from the SQL Editor.
-- ---------------------------------------------------------------------------
create or replace function public.create_tenant(p_name text, p_slug text) returns uuid
language plpgsql security definer set search_path = public as $$
declare
    new_tenant_id uuid;
begin
    insert into public.tenants (name, slug) values (p_name, p_slug) returning id into new_tenant_id;

    insert into public.rubrics (tenant_id, version, is_active, parameters)
    values (new_tenant_id, 1, true, jsonb_build_object(
        'greeting',   jsonb_build_object('weight', 10, 'description', 'Proper greeting and identification'),
        'empathy',    jsonb_build_object('weight', 20, 'description', 'Acknowledges the customer''s situation'),
        'resolution', jsonb_build_object('weight', 40, 'description', 'Issue resolved or correctly escalated'),
        'compliance', jsonb_build_object('weight', 20, 'description', 'Required disclosures and policy adherence'),
        'closing',    jsonb_build_object('weight', 10, 'description', 'Summary and courteous close')
    ));

    return new_tenant_id;
end $$;

revoke execute on function public.create_tenant(text, text) from public, anon, authenticated;
