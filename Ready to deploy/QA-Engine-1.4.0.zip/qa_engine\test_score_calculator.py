"""Unit tests for deterministic scoring and auto-fail."""

import unittest

from qa_engine.score_calculator import ScoreCalculator


class TestScoreCalculator(unittest.TestCase):
    """Covers the weighted score, the pass threshold and the regulatory auto-fail."""

    RUBRIC: dict = {
        "pass_threshold": 80,
        "checks": [
            {"key": "compliance", "label": "Compliance", "weight": 0.40, "critical": True},
            {"key": "procedural", "label": "Procedural", "weight": 0.40, "critical": False},
            {"key": "closing", "label": "Closing", "weight": 0.20, "critical": False},
        ],
    }

    @staticmethod
    def _verdicts(compliance: bool, procedural: bool, closing: bool) -> dict:
        """Builds verdicts for the three checks."""
        return {
            "compliance": {"passed": compliance, "reason": "r1"},
            "procedural": {"passed": procedural, "reason": "r2"},
            "closing": {"passed": closing, "reason": "r3"},
        }

    def test_all_pass_scores_100(self) -> None:
        """All checks passing gives 100 and a pass."""
        result = ScoreCalculator.calculate(self.RUBRIC, self._verdicts(True, True, True))
        self.assertEqual(100.0, result["overall_score"])
        self.assertTrue(result["passed"])
        self.assertFalse(result["critical_fail"])

    def test_closing_failure_still_passes_at_80(self) -> None:
        """Failing only the closing check scores 80, which meets the threshold."""
        result = ScoreCalculator.calculate(self.RUBRIC, self._verdicts(True, True, False))
        self.assertEqual(80.0, result["overall_score"])
        self.assertTrue(result["passed"])

    def test_procedural_failure_fails_below_threshold(self) -> None:
        """Failing the procedural check scores 60 and fails."""
        result = ScoreCalculator.calculate(self.RUBRIC, self._verdicts(True, False, True))
        self.assertEqual(60.0, result["overall_score"])
        self.assertFalse(result["passed"])

    def test_compliance_failure_is_auto_fail_with_zero(self) -> None:
        """A failed critical check forces score 0, fail, and a REGULATORY_AUTO_FAIL flag."""
        result = ScoreCalculator.calculate(self.RUBRIC, self._verdicts(False, True, True))
        self.assertEqual(0.0, result["overall_score"])
        self.assertFalse(result["passed"])
        self.assertTrue(result["critical_fail"])
        self.assertTrue(result["flags"][0].startswith("REGULATORY_AUTO_FAIL"))

    def test_missing_verdict_counts_as_failed(self) -> None:
        """A check that did not run is a failure, so a missing critical verdict is an auto-fail."""
        result = ScoreCalculator.calculate(self.RUBRIC, {})
        self.assertTrue(result["critical_fail"])


if __name__ == "__main__":
    unittest.main()
