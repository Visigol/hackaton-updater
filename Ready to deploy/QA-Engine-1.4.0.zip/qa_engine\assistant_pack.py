"""The facts the chat assistant may use: a compact summary of a tenant's recent audits, computed in code."""

from qa_engine.performance_stats import PerformanceStats


class AssistantPack:
    """Builds the data pack sent to the assistant in ``sly_data``. The assistant looks things up in it; it never queries
    the database itself, so it can only ever see what the worker, under the tenant's scope, chose to give it."""

    MAX_AGENTS: int = 60
    CRITICAL_FAILS_SHOWN: int = 10

    @staticmethod
    def build(audits: list[dict], checks: list[dict], period: str) -> dict:
        """Summarizes the audits.

        :param audits: audit rows with ``agent_name``, ``overall_score``, ``passed``, ``critical_fail``, ``scored_at``, ``scores``
        :param checks: the rubric's checks ({"key", "label", "critical"})
        :param period: a label such as "last 30 days"
        :return: {"period", "overview", "agents": {name: stats}, "checks": {key: stats}, "critical_fails": [...]}
        """
        by_agent: dict[str, list[dict]] = {}
        for audit in audits:
            by_agent.setdefault(str(audit.get("agent_name") or "Unknown"), []).append(audit)
        busiest: list[str] = sorted(by_agent, key=lambda name: len(by_agent[name]), reverse=True)[:AssistantPack.MAX_AGENTS]

        everyone: dict = PerformanceStats.compute(audits, checks, "all agents", period)
        return {
            "period": period,
            "overview": {key: everyone[key] for key in ("audits", "average_score", "pass_rate", "critical_fails", "trend")}
                        | {"agents": len(by_agent)},
            "agents": {name: PerformanceStats.compute(by_agent[name], checks, name, period) for name in busiest},
            "checks": {check["key"]: stats for check, stats in zip(checks, everyone["checks"])},
            "critical_fails": AssistantPack._critical_fails(audits, checks),
        }

    @staticmethod
    def _critical_fails(audits: list[dict], checks: list[dict]) -> list[dict]:
        """The latest critical fails with the check that caused each and its reason."""
        critical_keys: list[str] = [check["key"] for check in checks if check.get("critical")]
        failed: list[dict] = sorted((audit for audit in audits if audit.get("critical_fail")),
                                    key=lambda audit: str(audit.get("scored_at")), reverse=True)
        result: list[dict] = []
        for audit in failed[:AssistantPack.CRITICAL_FAILS_SHOWN]:
            scores: dict = audit.get("scores") or {}
            cause: str = next((f"{key}: {scores[key].get('reason') or 'no reason recorded'}"
                               for key in critical_keys if isinstance(scores.get(key), dict) and not scores[key].get("passed")), "")
            result.append({"agent_name": audit.get("agent_name"), "scored_at": str(audit.get("scored_at"))[:10], "cause": cause[:200]})
        return result
