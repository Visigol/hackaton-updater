"""Coded tool of the qa_audit network: hands an auditor agent the task for one rubric check."""

import logging
from typing import Any

from neuro_san.interfaces.coded_tool import CodedTool

logger = logging.getLogger(__name__)


class LoadCheck(CodedTool):
    """Returns the transcript excerpt and the audit rules of one check, read from the request's sly_data.

    The audit worker puts every check's task into ``sly_data["checks"]`` (``{check_key: {"task": "..."}}``). The
    task text never passes through an LLM until this tool returns it to the auditor that asked for it, so a small
    model is never asked to copy a transcript.

    Demo mode: when the network is started without ``checks`` (for example by typing into the Neuro SAN Studio chat),
    a built-in sample call is used so the agents can be watched working. Anything produced that way carries
    ``sly_data["demo"] = True`` and the audit worker refuses it (see AuditRunner), so it can never become a score.
    """

    DEMO_CHECKS: dict[str, dict[str, str]] = {
        "compliance": {"task": (
            "DEMO DATA, not a real audit.\n"
            "Compliance & Authentication - transcript excerpt:\n"
            "Agent: Thank you for calling Horizon Telecom Billing Support, my name is Anna. This call is recorded for "
            "quality and training purposes. How can I help you today?\n"
            "Customer: Hi Anna. I'm calling because I saw a charge on my bill that I don't recognize.\n"
            "Agent: Let me pull that up. Right, I can see the charge you mean: a sixty-four dollar Premium Sports Pass "
            "added on the ninth.\n"
            "Customer: Yes! I never ordered a sports pass.\n"
            "Agent: Understood. Before I go any further, for your security, could I confirm your date of birth and the "
            "postcode on the account?\n"
            "Customer: Sure. Seventh of June nineteen ninety, and the postcode is M5V 2T6.\n\n"
            "AUDIT RULES:\n"
            "1. The agent states that the call is recorded or monitored (any wording).\n"
            "2. Before discussing or changing ANY account detail, the agent verifies the caller's identity with something "
            "only the account holder would know. Asking only for a name or phone number does NOT count.\n"
            "3. If verification is merely implied, assumed, or performed after revealing details, mark passed false.\n")},
        "procedural": {"task": (
            "DEMO DATA, not a real audit.\n"
            "Procedural Resolution - summary of the call:\n"
            "The customer disputed a 64 dollar Premium Sports Pass. The agent cancelled it and credited 64 dollars. The "
            "customer also asked to change the billing date; the agent opened ticket TKT-44018 for the account services "
            "team.\n\n"
            "AUDIT RULES:\n"
            "1. Were ALL customer issues credited, cancelled, or given a concrete tracking ticket ID?\n"
            "2. If any charge was left unresolved without a guarantee or ticket, mark passed false.\n")},
        "closing": {"task": (
            "DEMO DATA, not a real audit.\n"
            "Etiquette & Closing - transcript excerpt:\n"
            "Agent: Just to summarize: I cancelled the Premium Sports Pass and credited sixty-four dollars, and I opened "
            "ticket TKT-44018 for the billing date change. Is there anything else I can help you with today?\n"
            "Customer: No, that's everything. Thank you, Anna.\n"
            "Agent: You're welcome. Thank you for calling Horizon Telecom, have a great day.\n\n"
            "AUDIT RULES:\n"
            "1. The agent asks whether the customer needs anything else before ending the call, in any wording.\n"
            "2. The agent MUST NOT end the call while the customer is still speaking.\n")},
    }

    async def async_invoke(self, args: dict[str, Any], sly_data: dict[str, Any]) -> str:
        """Looks up the task for ``check_key``.

        :param args: ``{"check_key": "<key>"}``
        :param sly_data: the request's bulletin board; holds ``checks`` when the audit worker made the request
        :return: the task text, or a message listing the valid keys when the key is unknown
        """
        if not sly_data.get("checks"):
            logger.warning("load_check: no checks in sly_data, so the DEMO sample is being used")
            sly_data["checks"] = {key: dict(value) for key, value in self.DEMO_CHECKS.items()}
            sly_data["demo"] = True

        check_key: str = str(args.get("check_key") or "").strip()
        checks: dict[str, Any] = sly_data.get("checks") or {}
        task: str | None = (checks.get(check_key) or {}).get("task")
        if not task:
            logger.warning("load_check: unknown check_key %r; valid keys are %s", check_key, sorted(checks))
            return f"There is no check called '{check_key}'. Valid check keys: {', '.join(sorted(checks)) or '(none)'}."
        logger.info("load_check: delivered the task for %s (%d characters)", check_key, len(task))
        return task
