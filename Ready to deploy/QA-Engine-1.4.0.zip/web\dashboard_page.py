"""HTML shell and styling of the QA Platform dashboard. Behavior lives in dashboard_js_core / dashboard_js_admin."""

from dashboard_js_admin import JS_ADMIN
from dashboard_js_core import JS_CORE
from dashboard_js_workflow import JS_WORKFLOW
from pages import SUPABASE_JS

STYLE = r"""
<style>
  :root {
    --bg:#f3f5f9; --surface:#ffffff; --surface2:#f7f8fb; --ink:#0f172a; --ink2:#475467; --muted:#667085;
    --line:#e6e9f0; --accent:#2a78d6; --accent2:#6250d6; --good:#0ca30c; --serious:#ec835a; --critical:#d03b3b;
    --shadow:0 1px 2px rgba(16,24,40,.04), 0 10px 28px -14px rgba(16,24,40,.16); --radius:16px; color-scheme:light;
  }
  @media (prefers-color-scheme: dark) {
    :root:not([data-theme="light"]) {
      --bg:#0a0e15; --surface:#121824; --surface2:#0e131d; --ink:#eef1f6; --ink2:#c3c8d2; --muted:#98a2b3;
      --line:#222a39; --accent:#3987e5; --accent2:#9085e9; --shadow:0 1px 2px rgba(0,0,0,.4), 0 12px 30px -14px rgba(0,0,0,.7);
      color-scheme:dark;
    }
  }
  :root[data-theme="dark"] {
    --bg:#0a0e15; --surface:#121824; --surface2:#0e131d; --ink:#eef1f6; --ink2:#c3c8d2; --muted:#98a2b3;
    --line:#222a39; --accent:#3987e5; --accent2:#9085e9; --shadow:0 1px 2px rgba(0,0,0,.4), 0 12px 30px -14px rgba(0,0,0,.7);
    color-scheme:dark;
  }
  * { box-sizing:border-box; }
  [hidden] { display:none !important; }  /* rules like #tip{display:flex} would otherwise beat the hidden attribute */
  html, body { margin:0; }
  body { background:var(--bg); color:var(--ink); font:15px/1.5 Inter, system-ui, -apple-system, "Segoe UI", sans-serif; }
  button, input, select, textarea { font:inherit; color:inherit; }
  .small { font-size:.82rem; } .muted { color:var(--muted); } .ico { display:inline-flex; vertical-align:middle; }

  .app { display:grid; grid-template-columns:248px 1fr; min-height:100vh; }
  .side { position:sticky; top:0; height:100vh; padding:20px 14px; display:flex; flex-direction:column; gap:18px;
          background:var(--surface); border-right:1px solid var(--line); }
  .brand { display:flex; align-items:center; gap:10px; font-weight:700; font-size:1.05rem; padding:0 8px; }
  .logo { width:30px; height:30px; border-radius:9px; background:linear-gradient(135deg,var(--accent),var(--accent2));
          box-shadow:0 6px 16px -6px var(--accent); }
  .tenant { display:flex; gap:10px; align-items:center; padding:10px 12px; border:1px solid var(--line);
            border-radius:12px; background:var(--surface2); }
  .tenant-dot { width:9px; height:9px; border-radius:50%; background:var(--good); flex:none; }
  .tenant-name { font-weight:600; line-height:1.2; }
  nav { display:flex; flex-direction:column; gap:3px; }
  .nav-label { font-size:.72rem; text-transform:uppercase; letter-spacing:.08em; color:var(--muted); padding:12px 12px 4px; }
  .nav-item { display:flex; align-items:center; gap:10px; padding:9px 12px; border-radius:10px; border:0; background:none;
              color:var(--ink2); cursor:pointer; text-align:left; width:100%; }
  .nav-item:hover { background:var(--surface2); color:var(--ink); }
  .nav-item[aria-current="page"] { background:color-mix(in srgb, var(--accent) 12%, transparent); color:var(--ink); font-weight:600; }
  .nav-item[aria-current="page"] .ico { color:var(--accent); }
  .side-foot { margin-top:auto; display:flex; flex-direction:column; gap:4px; }

  .main { padding:28px clamp(16px, 3vw, 40px) 64px; min-width:0; max-width:1280px; width:100%; }
  .topbar { display:flex; justify-content:space-between; align-items:flex-end; gap:16px; flex-wrap:wrap; margin-bottom:18px; }
  h1 { font-size:1.65rem; line-height:1.2; margin:0; letter-spacing:-.01em; }
  h2 { font-size:1rem; margin:0; } h3 { font-size:.95rem; margin:0; }
  .filters { display:flex; gap:10px; flex-wrap:wrap; align-items:center; margin-bottom:18px; }
  .seg { display:inline-flex; padding:3px; background:var(--surface); border:1px solid var(--line); border-radius:11px; }
  .seg button { border:0; background:none; padding:6px 13px; border-radius:8px; color:var(--ink2); cursor:pointer; }
  .seg button[aria-pressed="true"] { background:var(--accent); color:#fff; }
  .chip { border:1px solid var(--line); background:var(--surface); color:var(--ink2); padding:5px 12px; border-radius:999px; cursor:pointer; font-size:.88rem; }
  .chip[aria-pressed="true"] { border-color:var(--accent); color:var(--ink); background:color-mix(in srgb, var(--accent) 12%, transparent); }
  .input, .select, .textarea { width:100%; padding:9px 12px; border:1px solid var(--line); border-radius:10px; background:var(--surface); outline:none; }
  .input:focus, .select:focus, .textarea:focus, button:focus-visible { outline:2px solid var(--accent); outline-offset:1px; }
  .filters .input { width:auto; min-width:220px; } .filters .select { width:auto; }
  .textarea { min-height:190px; resize:vertical; font-family:ui-monospace, Menlo, Consolas, monospace; font-size:.88rem; }

  .btn { display:inline-flex; align-items:center; gap:8px; padding:9px 15px; border-radius:10px; border:1px solid var(--line);
         background:var(--surface); cursor:pointer; white-space:nowrap; }
  .btn:hover { border-color:var(--muted); }
  .btn.primary { background:linear-gradient(135deg,var(--accent),var(--accent2)); border-color:transparent; color:#fff;
                 box-shadow:0 8px 20px -10px var(--accent); }
  .btn.danger { color:var(--critical); } .btn.danger:hover { border-color:var(--critical); }
  .btn.ghost { border-color:transparent; background:none; } .btn.ghost:hover { background:var(--surface2); }
  .btn.sm { padding:5px 9px; border-radius:8px; font-size:.86rem; }
  .btn:disabled { opacity:.55; cursor:default; }
  .icon-btn { padding:6px; border-radius:8px; border:0; background:none; color:var(--ink2); cursor:pointer; }
  .icon-btn:hover { background:var(--surface2); color:var(--ink); } .icon-btn.danger:hover { color:var(--critical); }

  .grid { display:grid; gap:16px; } .kpis { grid-template-columns:repeat(auto-fit, minmax(190px, 1fr)); margin-bottom:16px; }
  .cols { grid-template-columns:repeat(12, 1fr); } .span-8 { grid-column:span 8; } .span-4 { grid-column:span 4; }
  .span-6 { grid-column:span 6; } .span-12 { grid-column:span 12; }
  .card { background:var(--surface); border:1px solid var(--line); border-radius:var(--radius); padding:20px; box-shadow:var(--shadow); min-width:0; }
  .card-head { display:flex; justify-content:space-between; align-items:baseline; gap:10px; margin-bottom:14px; }
  .fade { animation:rise .5s both; } @keyframes rise { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:none; } }
  @media (prefers-reduced-motion: reduce) { .fade { animation:none; } }

  .hero { position:relative; overflow:hidden; border-radius:var(--radius); padding:26px 28px; margin-bottom:16px; color:#fff;
          background:radial-gradient(900px 300px at 100% 0%, rgba(255,255,255,.18), transparent 60%),
                     linear-gradient(120deg,#1d4fa8,#2a78d6 45%,#6250d6); box-shadow:var(--shadow); }
  .hero h2 { font-size:1.35rem; margin-bottom:4px; } .hero p { margin:0; opacity:.9; max-width:46rem; }
  .hero .btn { margin-top:16px; background:rgba(255,255,255,.16); border-color:rgba(255,255,255,.3); color:#fff; }
  .hero .btn:hover { background:rgba(255,255,255,.26); }

  .kpi .label { color:var(--muted); font-size:.85rem; }
  .kpi .value { font-size:2rem; font-weight:700; letter-spacing:-.02em; line-height:1.15; margin:4px 0 2px; }
  .kpi .sub { color:var(--muted); font-size:.82rem; } .kpi svg { margin-top:8px; display:block; }

  .badge { --c:var(--muted); display:inline-flex; align-items:center; gap:6px; padding:3px 10px 3px 8px; border-radius:999px;
           font-size:.82rem; font-weight:500; background:color-mix(in srgb, var(--c) 14%, transparent); border:1px solid color-mix(in srgb, var(--c) 35%, transparent); }
  .badge .ico { color:var(--c); }
  .tag { font-size:.72rem; padding:1px 8px; border-radius:999px; background:var(--surface2); border:1px solid var(--line); color:var(--ink2); }
  .tag.crit { border-color:color-mix(in srgb, var(--critical) 45%, transparent); color:var(--ink); }

  table { width:100%; border-collapse:collapse; } th { text-align:left; font-weight:500; color:var(--muted); font-size:.82rem; padding:0 10px 10px; white-space:nowrap; }
  td { padding:11px 10px; border-top:1px solid var(--line); vertical-align:middle; }
  tbody tr:hover td { background:var(--surface2); } td.actions { text-align:right; white-space:nowrap; }
  .table-wrap { overflow-x:auto; }
  .who { display:flex; align-items:center; gap:10px; }
  .avatar { width:34px; height:34px; border-radius:50%; display:grid; place-items:center; font-weight:600; font-size:.8rem; flex:none;
            background:color-mix(in srgb, var(--accent) 16%, transparent); color:var(--ink); }
  .score { display:flex; align-items:center; gap:10px; min-width:130px; }
  .score b { min-width:2.4rem; } .bar { flex:1; height:6px; border-radius:99px; background:var(--line); overflow:hidden; }
  .bar > i { display:block; height:100%; border-radius:99px; background:var(--accent); }
  .pager { display:flex; justify-content:space-between; align-items:center; margin-top:14px; gap:10px; flex-wrap:wrap; }
  .bulk { display:flex; gap:10px; align-items:center; padding:10px 14px; margin-bottom:12px; border-radius:12px;
          background:color-mix(in srgb, var(--accent) 10%, transparent); border:1px solid color-mix(in srgb, var(--accent) 30%, transparent); }

  .rows { display:flex; flex-direction:column; gap:12px; }
  .hrow { display:grid; grid-template-columns:minmax(80px, 150px) 1fr 52px; gap:12px; align-items:center; font-size:.9rem; cursor:default; }
  .hrow .name { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; color:var(--ink2); }
  .hrow .track { height:10px; border-radius:99px; background:var(--line); overflow:hidden; }
  .hrow .fill { height:100%; border-radius:0 5px 5px 0; background:var(--accent); transition:width .5s; }
  .hrow:hover .fill { filter:brightness(1.15); } .hrow .val { text-align:right; font-weight:600; }
  .stack { display:flex; gap:2px; height:16px; border-radius:8px; overflow:hidden; margin-bottom:14px; }
  .stack i { display:block; height:100%; } .legend { display:flex; flex-direction:column; gap:8px; }
  .legend div { display:flex; align-items:center; justify-content:space-between; gap:10px; }
  .legend span.l { display:flex; align-items:center; gap:8px; color:var(--ink2); }
  .empty { color:var(--muted); text-align:center; padding:28px 12px; }
  .empty h3 { color:var(--ink); margin-bottom:4px; }
  svg text { font-family:inherit; }

  .drop { border:2px dashed var(--line); border-radius:14px; padding:26px; text-align:center; cursor:pointer; background:var(--surface2); }
  .drop:hover, .drop.over { border-color:var(--accent); background:color-mix(in srgb, var(--accent) 7%, transparent); }
  .field { display:flex; flex-direction:column; gap:6px; margin-bottom:14px; } .field > label { font-size:.86rem; color:var(--ink2); }
  .form-row { display:grid; grid-template-columns:repeat(auto-fit, minmax(210px, 1fr)); gap:14px; }
  .alert { padding:12px 16px; border-radius:12px; margin-bottom:16px; border:1px solid color-mix(in srgb, var(--critical) 40%, transparent);
           background:color-mix(in srgb, var(--critical) 9%, transparent); }
  .callout { padding:14px 16px; border-radius:12px; border:1px solid color-mix(in srgb, var(--good) 40%, transparent);
             background:color-mix(in srgb, var(--good) 9%, transparent); margin-top:14px; }
  .mono { font-family:ui-monospace, Menlo, Consolas, monospace; font-size:.88rem; }

  #backdrop { position:fixed; inset:0; background:rgba(8,12,20,.5); opacity:0; pointer-events:none; transition:opacity .2s; z-index:40; }
  #backdrop.open { opacity:1; pointer-events:auto; }
  #drawer { position:fixed; top:0; right:0; height:100%; width:min(640px, 100%); background:var(--bg); z-index:50; transform:translateX(104%);
            transition:transform .25s; box-shadow:-20px 0 50px -20px rgba(0,0,0,.4); display:flex; flex-direction:column; }
  #drawer.open { transform:none; }
  .drawer-head { display:flex; justify-content:space-between; align-items:center; padding:14px 18px; border-bottom:1px solid var(--line); background:var(--surface); }
  #drawer-body { padding:18px; overflow-y:auto; flex:1; display:flex; flex-direction:column; gap:14px; }
  .dhero { display:flex; gap:18px; align-items:center; }
  .check { display:grid; grid-template-columns:28px 1fr; gap:12px; padding:12px 0; border-top:1px solid var(--line); }
  .check:first-child { border-top:0; } .check p { margin:2px 0 0; color:var(--ink2); font-size:.9rem; }
  .pf { width:26px; height:26px; border-radius:50%; display:grid; place-items:center; color:#fff; }
  .seg2 { display:inline-flex; border:1px solid var(--line); border-radius:9px; overflow:hidden; }
  .seg2 button { border:0; background:var(--surface); padding:4px 12px; cursor:pointer; }
  .seg2 button[aria-pressed="true"].p { background:var(--good); color:#fff; } .seg2 button[aria-pressed="true"].f { background:var(--critical); color:#fff; }
  details summary { cursor:pointer; color:var(--ink2); } pre.transcript { white-space:pre-wrap; word-break:break-word; margin:10px 0 0; font:inherit; font-size:.9rem; color:var(--ink2); max-height:340px; overflow:auto; }

  dialog { border:1px solid var(--line); border-radius:16px; background:var(--surface); color:var(--ink); padding:22px; width:min(440px, 92vw); box-shadow:var(--shadow); }
  dialog::backdrop { background:rgba(8,12,20,.55); } dialog h3 { margin-bottom:6px; } dialog p { color:var(--ink2); margin:0 0 18px; }
  dialog .row { display:flex; gap:10px; justify-content:flex-end; }

  #tip { position:fixed; left:0; top:0; z-index:90; pointer-events:none; background:var(--surface); border:1px solid var(--line);
         border-radius:10px; padding:8px 11px; box-shadow:var(--shadow); display:flex; flex-direction:column; font-size:.84rem; max-width:260px; }
  #tip strong { font-size:1rem; } #tip span { color:var(--ink2); } #tip .tip-detail { color:var(--muted); }
  #toasts { position:fixed; right:18px; bottom:18px; display:flex; flex-direction:column; gap:10px; z-index:100; }
  .toast { background:var(--surface); border:1px solid var(--line); border-left:4px solid var(--accent); border-radius:10px; padding:11px 15px;
           box-shadow:var(--shadow); max-width:380px; animation:rise .3s both; transition:opacity .4s; }
  .toast.ok { border-left-color:var(--good); } .toast.error { border-left-color:var(--critical); } .toast.out { opacity:0; }
  .sk { border-radius:8px; background:linear-gradient(90deg,var(--line),var(--surface2),var(--line)); background-size:200% 100%; animation:sh 1.2s infinite; height:14px; }
  @keyframes sh { to { background-position:-200% 0; } }

  .count { margin-left:auto; min-width:20px; padding:0 6px; border-radius:99px; background:var(--critical); color:#fff; font-size:.75rem; text-align:center; }
  .chat { display:flex; flex-direction:column; gap:10px; max-height:55vh; overflow-y:auto; padding:4px 2px; }
  .bubble { max-width:80%; padding:10px 14px; border-radius:14px; border:1px solid var(--line); background:var(--surface2); white-space:pre-wrap; word-break:break-word; }
  .bubble.user { align-self:flex-end; background:color-mix(in srgb, var(--accent) 14%, transparent); border-color:color-mix(in srgb, var(--accent) 35%, transparent); }
  .bubble.err { border-color:var(--critical); }
  details > summary { cursor:pointer; list-style:none; } details > summary::-webkit-details-marker { display:none; }
  @media (max-width: 1000px) { .span-8, .span-4, .span-6 { grid-column:span 12; } }
  @media (max-width: 860px) {
    .app { grid-template-columns:1fr; }
    .side { position:static; height:auto; flex-direction:row; flex-wrap:wrap; align-items:center; padding:12px 14px; gap:10px; border-right:0; border-bottom:1px solid var(--line); }
    .tenant, .nav-label { display:none; } nav { flex-direction:row; overflow-x:auto; order:3; width:100%; }
    .nav-item { width:auto; white-space:nowrap; } .side-foot { margin:0 0 0 auto; flex-direction:row; }
    .side-foot .btn span.t { display:none; } .hrow { grid-template-columns:90px 1fr 46px; }
  }
</style>
"""

BODY = r"""
<div class="app">
  <aside class="side">
    <div class="brand"><span class="logo"></span><span>QA Platform</span></div>
    <div class="tenant"><span class="tenant-dot"></span>
      <div><div class="tenant-name" id="tenant-name">Loading...</div><div class="muted small" id="tenant-role"></div></div></div>
    <nav id="nav" aria-label="Main"></nav>
    <div class="side-foot">
      <button class="nav-item" id="theme-btn" type="button"></button>
      <button class="nav-item" id="signout-btn" type="button"></button>
    </div>
  </aside>
  <main class="main">
    <div class="topbar">
      <div><h1 id="title">Overview</h1><div class="muted" id="subtitle"></div></div>
      <div id="top-actions"></div>
    </div>
    <div class="alert" id="alert" role="alert" hidden></div>
    <div class="filters" id="filters"></div>
    <section class="view" id="view-overview"></section>
    <section class="view" id="view-audits" hidden></section>
    <section class="view" id="view-new" hidden></section>
    <section class="view" id="view-reviews" hidden></section>
    <section class="view" id="view-reports" hidden></section>
    <section class="view" id="view-learning" hidden></section>
    <section class="view" id="view-assistant" hidden></section>
    <section class="view" id="view-rubric" hidden></section>
    <section class="view" id="view-users" hidden></section>
    <section class="view" id="view-knowledge" hidden></section>
    <section class="view" id="view-data" hidden></section>
  </main>
</div>
<div id="backdrop"></div>
<aside id="drawer" role="dialog" aria-modal="true" aria-label="Audit details" aria-hidden="true">
  <div class="drawer-head"><strong id="drawer-title">Audit</strong><button class="icon-btn" id="drawer-close" type="button" aria-label="Close"></button></div>
  <div id="drawer-body"></div>
</aside>
<div id="tip" role="tooltip" hidden></div>
<div id="toasts" aria-live="polite"></div>
"""

DASHBOARD_PAGE = (
    "<!doctype html><html lang='en'><head><meta charset='utf-8'>"
    "<meta name='viewport' content='width=device-width,initial-scale=1'>"
    "<title>QA Platform</title>" + STYLE +
    "<script>try{var t=localStorage.getItem('qa-theme');if(t)document.documentElement.setAttribute('data-theme',t);}catch(e){}</script>"
    "<script src='/config.js'></script>"
    f"<script src='{SUPABASE_JS}'></script></head><body>"
    + BODY + "<script>" + JS_CORE + JS_WORKFLOW + JS_ADMIN + "</script></body></html>"
)
