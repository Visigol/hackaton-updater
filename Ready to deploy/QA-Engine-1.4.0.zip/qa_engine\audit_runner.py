"""Runs a tenant's rubric against one transcript, through the Neuro SAN audit network or directly through the bridge."""

import logging
import re

from preprocessor import DeterministicSanitizer
from qa_engine.bridge_client import BridgeClient
from qa_engine.bridge_error import BridgeError
from qa_engine.critical_guard import CriticalGuard
from qa_engine.gemini_client import GeminiClient
from qa_engine.identity_order import IdentityOrder
from qa_engine.learned_examples import LearnedExamples
from qa_engine.neuro_san_client import NeuroSanClient
from qa_engine.score_calculator import ScoreCalculator
from qa_engine.verdict_parser import VerdictParser

logger = logging.getLogger(__name__)


class AuditRunner:
    """Builds one task per rubric check, collects the verdicts and hands them to the ScoreCalculator.

    With a ``NeuroSanClient`` the checks are judged by the qa_audit agent network: an orchestrator delegates every check
    to an auditor agent (see registries/qa_audit.hocon). Without one, each check is a single prompt to the bridge,
    which is the older path and is kept as an explicit fallback (``AUDIT_BACKEND=bridge``). Either way the score is
    computed here, in code, never by a model.
    """

    PROMPT_TEMPLATE: str = (
        "{label} - transcript excerpt:\n{excerpt}\n{context}\n"
        "AUDIT RULES:\n{rules}\n{examples}\n"
        "Evaluate strictly. If ANY rule is violated, passed MUST be false.\n"
        'Respond ONLY with this JSON structure:\n{{"passed": false, "reason": "exact violation citation"}}'
    )

    # What an auditor agent reads through the load_check coded tool. Its instructions already say how to answer.
    TASK_TEMPLATE: str = "{label} - transcript excerpt:\n{excerpt}\n{context}\nAUDIT RULES:\n{rules}\n{examples}"

    # Markers a transcript tool writes when the line drops or someone hangs up, e.g. "[call disconnected]".
    DISCONNECT_MARKER: re.Pattern[str] = re.compile(
        r"\[[^\]\n]*(?:disconnect|dropped|hung up|hang[- ]?up|connection lost|line dead)[^\]\n]*\]", re.IGNORECASE)
    DISCONNECT_LINES_CHECKED: int = 3

    # How many times the agent network is asked in one audit; rounds after the first ask only for the missing checks.
    AGENT_ROUNDS: int = 3

    def __init__(self, client: BridgeClient | GeminiClient, neuro_san: NeuroSanClient | None = None) -> None:
        """:param client: model client used for the summary (and for every check when no Neuro SAN client is given)
        :param neuro_san: when given, the checks are judged by this agent network instead of by single prompts
        """
        self._client: BridgeClient | GeminiClient = client
        self._neuro_san: NeuroSanClient | None = neuro_san

    def run(self, transcript_text: str, rubric: dict, examples: dict[str, list[dict]] | None = None) -> dict:
        """Audits a transcript.

        :param transcript_text: sanitized transcript (it is masked again here as defense in depth)
        :param rubric: rubric parameters (checks, weights, threshold)
        :param examples: reviewer-corrected examples per check key (see LearnedExamples); optional
        :return: {"scores": {...}, "flags": [...], "overall_score", "passed", "critical_fail"}
        :raises BridgeError: when the model or the agent network cannot deliver a verdict for every check; the job
            then fails and is retried, and nothing is scored from an incomplete audit
        """
        sanitized: str = DeterministicSanitizer.mask_pii(transcript_text)
        slices: dict[str, str] = DeterministicSanitizer.slice_transcript(sanitized)
        summary: str = self._client.summarize(sanitized)
        excerpts: dict[str, str] = {"opening": slices["opening"], "closing": slices["closing"], "summary": summary}
        context: str = self._call_context(sanitized)

        order: dict | None = IdentityOrder.analyze(sanitized)
        checks: list[dict] = []
        for check in rubric.get("checks", []):
            facts: str = IdentityOrder.facts_text(order) if IdentityOrder.applies_to(check.get("key"), check.get("label")) else ""
            checks.append({
                "key": check.get("key"), "label": check.get("label"), "context": context + facts,
                "excerpt": excerpts.get(check.get("source"), slices["full_clean"]),
                "rules": "\n".join(f"{number}. {rule}" for number, rule in enumerate(check.get("rules", []), 1)),
                "examples": LearnedExamples.format((examples or {}).get(check.get("key"))),
            })

        if self._neuro_san is not None:
            verdicts: dict[str, dict] = self._verdicts_from_agents(checks, context)
            engine: dict = {"name": "neuro_san", "network": self._neuro_san.network}
        else:
            verdicts = self._verdicts_from_prompts(checks, context)
            engine = {"name": "bridge"}
        engine["examples"] = sum(len(items) for items in (examples or {}).values())

        verdicts = self._apply_code_checks(rubric, order, verdicts)
        CriticalGuard.apply(rubric, verdicts, sanitized)
        result: dict = ScoreCalculator.calculate(rubric, verdicts)
        result["scores"] = {"summary": summary, "_engine": engine, **verdicts}
        return result

    @staticmethod
    def _apply_code_checks(rubric: dict, order: dict | None, verdicts: dict[str, dict]) -> dict[str, dict]:
        """Lets the computed identity-order facts decide the identity check, whatever the model said.

        Code can compare the order of two lines; a small model cannot. The verdict is replaced only when the code found
        the lines (outcome ok or a violation); with outcome unknown the model's verdict stands.
        """
        if not order or order["outcome"] == "unknown":
            return verdicts
        for check in rubric.get("checks", []):
            key: str = check.get("key")
            if key in verdicts and IdentityOrder.applies_to(key, check.get("label")):
                verdicts[key] = {"passed": order["outcome"] == "ok", "reason": IdentityOrder.reason(order), "computed": True}
        return verdicts

    def _verdicts_from_prompts(self, checks: list[dict], context: str) -> dict[str, dict]:
        """The older path: one prompt per check straight to the bridge."""
        verdicts: dict[str, dict] = {}
        for check in checks:
            logger.info("Running check %s", check["key"])
            prompt: str = self.PROMPT_TEMPLATE.format(
                label=check["label"], excerpt=check["excerpt"], context=check.get("context", context), rules=check["rules"], examples=check["examples"])
            verdicts[check["key"]] = VerdictParser.parse(self._client.complete(prompt))
        return verdicts

    def _verdicts_from_agents(self, checks: list[dict], context: str) -> dict[str, dict]:
        """Has the qa_audit agent network judge every check; the tasks travel in sly_data, hidden from the models."""
        if not checks:
            return {}
        keys: list[str] = [check["key"] for check in checks]
        tasks: dict[str, dict] = {
            check["key"]: {"task": self.TASK_TEMPLATE.format(
                label=check["label"], excerpt=check["excerpt"], context=check.get("context", context), rules=check["rules"], examples=check["examples"])}
            for check in checks}

        # The network can stop early or an auditor can skip recording. Instead of failing the whole job (and re-running
        # every check, minutes of work), ask again for just the checks that have no verdict yet.
        recorded: dict[str, dict] = {}
        last_text: str = ""
        pending: list[str] = list(keys)
        for attempt in range(1, self.AGENT_ROUNDS + 1):
            logger.info("Asking the Neuro SAN network '%s' to run checks (round %d of %d): %s",
                        self._neuro_san.network, attempt, self.AGENT_ROUNDS, ", ".join(pending))
            returned: dict = self._neuro_san.run("Checks to run: " + ", ".join(pending),
                                                 {"checks": {key: tasks[key] for key in pending}})
            last_text = str(returned.get("text", ""))
            answered: dict = (returned.get("sly_data") or {}).get("verdicts") or {}
            demo: list[str] = [key for key in pending if isinstance(answered.get(key), dict) and answered[key].get("demo")]
            if demo:
                raise BridgeError(f"The Neuro SAN network returned DEMO verdicts for: {', '.join(demo)}. "
                                  "The request did not carry the real checks, so nothing was scored.")
            recorded.update({key: answered[key] for key in pending if key in answered})
            pending = [key for key in keys if key not in recorded]
            if not pending:
                break
            logger.warning("No verdict yet for: %s", ", ".join(pending))

        if pending:
            raise BridgeError(f"The Neuro SAN network did not record a verdict for: {', '.join(pending)} after "
                              f"{self.AGENT_ROUNDS} rounds. Its final answer was: {last_text[:200]!r}")
        return {key: VerdictParser.from_record(recorded[key]) for key in keys}

    @staticmethod
    def _call_context(sanitized: str) -> str:
        """Explains an abrupt ending, so a dropped call is not blamed on the agent.

        Small models read "[call disconnected]" as the agent hanging up and ignore a rule that says otherwise, so the
        fact is stated in the prompt itself, right before the rules. Only the last lines are examined: a marker in
        the middle of a call does not mean the call ended there.

        :param sanitized: the masked transcript
        :return: a context paragraph ending in a newline, or an empty string when the call did not end in a disconnect
        """
        for line in reversed(sanitized.strip().splitlines()[-AuditRunner.DISCONNECT_LINES_CHECKED:]):
            marker = AuditRunner.DISCONNECT_MARKER.search(line)
            if marker:
                logger.info("Transcript ends with a disconnect marker: %s", marker.group(0))
                return (f'CALL CONTEXT: this transcript ends with the marker "{marker.group(0)}". That marker means '
                        "the line dropped or someone hung up. It does NOT mean the agent ended the call. Do not "
                        "mark a rule as broken only because the transcript stops abruptly or mid-sentence.\n")
        return ""
