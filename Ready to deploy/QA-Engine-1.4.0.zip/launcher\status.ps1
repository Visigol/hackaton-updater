# Shows whether the QA engine is healthy: the services, the model, the secrets and the latest log lines.
. "$PSScriptRoot\common.ps1"

Write-Step 'QA engine status'
$version = if (Test-Path (Join-Path $script:Root 'current.txt')) { (Get-Content (Join-Path $script:Root 'current.txt') -Raw).Trim() } else { '(not installed)' }
Write-Info "Installed version: $version"

$supervisorPid = Join-Path $script:RunDir 'supervisor.pid'
$supervisorAlive = $false
if (Test-Path $supervisorPid) { $supervisorAlive = [bool](Get-Process -Id ([int](Get-Content $supervisorPid -Raw)) -ErrorAction SilentlyContinue) }
if ($supervisorAlive) { Write-Ok 'Supervisor is running' } else { Write-Fail 'Supervisor is NOT running (use Start)' }

$provider = 'nano'
$statusPath = Join-Path $script:RunDir 'status.json'
if (Test-Path $statusPath) { $saved = Get-Content $statusPath -Raw | ConvertFrom-Json; if ($saved.provider) { $provider = $saved.provider } }
Write-Info "AI provider: $provider"
$entries = @(@('Neuro SAN server', 8080), @('Studio (agent network page)', 4173))
if ($provider -eq 'nano') { $entries = @(@('Chrome (Gemini Nano)', 9222), @('Bridge', 8000), @('Neuro SAN server', 8080), @('Studio (agent network page)', 4173)) }
foreach ($entry in $entries) {
    if (Test-PortOpen $entry[1]) { Write-Ok ("{0} answers on port {1}" -f $entry[0], $entry[1]) } else { Write-Fail ("{0} is not answering on port {1}" -f $entry[0], $entry[1]) }
}
$health = if ($provider -eq 'nano') { Get-Json 'http://127.0.0.1:8000/health' } else { $null }
if ($provider -eq 'gemini') { Write-Ok 'Cloud Gemini in use: no local model to load' }
elseif ($health -and $health.model_ready) { Write-Ok 'Gemini Nano model is loaded' }
elseif ($health) { Write-Warn 'Bridge is up but the model is not ready yet (first load takes minutes; see Installation guide, Part 4)' }

$names = @{ watcher = 'File watcher'; worker = 'Audit worker' }
$statusFile = Join-Path $script:RunDir 'status.json'
if (Test-Path $statusFile) {
    $status = Get-Content $statusFile -Raw | ConvertFrom-Json
    foreach ($key in $names.Keys) {
        $id = $status.pids.$key
        if ($id -and (Get-Process -Id $id -ErrorAction SilentlyContinue)) { Write-Ok ($names[$key] + ' is running') } else { Write-Fail ($names[$key] + ' is not running') }
    }
}
if (Test-Path $script:EncryptedEnvPath) { Write-Ok 'Secrets installed (encrypted for this Windows user)' }
elseif (Test-Path $script:PlainEnvPath) { Write-Warn 'Secrets installed as a plain file (restricted to this user)' }
else { Write-Fail 'No secrets installed (use Update secrets)' }

foreach ($name in 'worker', 'bridge', 'neurosan') {
    $log = Join-Path $script:LogDir ($name + '.log')
    if (Test-Path $log) { Write-Host ''; Write-Host ("-- last lines of $name.log") -ForegroundColor DarkGray; Get-Content $log -Tail 4 }
}
