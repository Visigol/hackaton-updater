"""Coded tool of the qa_assistant network: looks facts up in the data pack the worker prepared."""

import logging
from typing import Any

from neuro_san.interfaces.coded_tool import CodedTool

logger = logging.getLogger(__name__)


class LookupData(CodedTool):
    """Answers ``topic`` questions from ``sly_data["pack"]`` and nothing else.

    The assistant has no database access and cannot write queries. Whatever it says is limited to this pack, which the
    audit worker built under the asking tenant's scope (qa_engine/assistant_pack.py).

    Demo mode: without a pack (for example from the Neuro SAN Studio chat) a built-in sample is used and
    ``sly_data["demo"]`` is set, which the audit worker refuses.
    """

    TOPICS: str = "overview, agents, agent (needs name), check (needs name), critical_fails"

    DEMO_PACK: dict[str, Any] = {
        "period": "last 30 days",
        "overview": {"audits": 12, "average_score": 78.3, "pass_rate": 67, "critical_fails": 2, "agents": 3,
                     "trend": {"direction": "declining", "change": -6.5}},
        "agents": {
            "Anna (demo)": {"agent_name": "Anna (demo)", "audits": 5, "average_score": 72.0, "pass_rate": 60, "critical_fails": 1,
                            "trend": {"direction": "declining", "change": -9.0}, "checks": [
                                {"key": "compliance", "label": "Compliance & Authentication", "audited": 5, "failed": 1, "pass_rate": 80, "failure_reasons": ["Charges stated before verification."]},
                                {"key": "closing", "label": "Etiquette & Closing", "audited": 5, "failed": 2, "pass_rate": 60, "failure_reasons": ["No closing question."]}]},
            "Marcus (demo)": {"agent_name": "Marcus (demo)", "audits": 7, "average_score": 82.9, "pass_rate": 71, "critical_fails": 1,
                              "trend": {"direction": "steady", "change": 0.5}, "checks": []},
        },
        "checks": {
            "compliance": {"key": "compliance", "label": "Compliance & Authentication", "audited": 12, "failed": 2, "pass_rate": 83, "failure_reasons": ["Charges stated before verification."]},
            "closing": {"key": "closing", "label": "Etiquette & Closing", "audited": 12, "failed": 3, "pass_rate": 75, "failure_reasons": ["No closing question."]},
        },
        "critical_fails": [{"agent_name": "Anna (demo)", "scored_at": "2026-10-18", "cause": "compliance: charges stated before verification"}],
    }

    async def async_invoke(self, args: dict[str, Any], sly_data: dict[str, Any]) -> str:
        """Looks something up.

        :param args: ``topic`` (one of the TOPICS) and, for agent and check, ``name``
        :param sly_data: the request's bulletin board; holds ``pack`` when the audit worker made the request
        :return: the facts as text, or a message saying what can be asked
        """
        if not sly_data.get("pack"):
            logger.warning("lookup_data: no pack in sly_data, so the DEMO sample is being used")
            sly_data["pack"] = self.DEMO_PACK
            sly_data["demo"] = True
        pack: dict[str, Any] = sly_data["pack"]
        topic: str = str(args.get("topic") or "").strip().lower()
        name: str = str(args.get("name") or "").strip()
        prefix: str = "DEMO DATA, not real. " if sly_data.get("demo") else ""

        if topic == "overview":
            overview = pack.get("overview") or {}
            trend = overview.get("trend") or {}
            return (prefix + f"Period: {pack.get('period')}. Audits: {overview.get('audits')}. Average score: {overview.get('average_score')}. "
                    f"Pass rate: {overview.get('pass_rate')}%. Critical fails: {overview.get('critical_fails')}. Agents audited: {overview.get('agents')}. "
                    f"Trend: {trend.get('direction')}.")
        if topic == "agents":
            return prefix + "Agents: " + "; ".join(f"{agent} ({stats.get('audits')} audits, average {stats.get('average_score')})"
                                                  for agent, stats in (pack.get("agents") or {}).items())
        if topic == "agent":
            agent, stats = self._find(pack.get("agents") or {}, name, "agent_name")
            if stats is None:
                return f"There is no agent matching '{name}'. Known agents: {', '.join(pack.get('agents') or {})}."
            return prefix + self._describe_agent(agent, stats)
        if topic == "check":
            _, stats = self._find(pack.get("checks") or {}, name, "label")
            if stats is None:
                return f"There is no check matching '{name}'. Known checks: {', '.join((c.get('label') or k) for k, c in (pack.get('checks') or {}).items())}."
            return prefix + self._describe_check(stats)
        if topic == "critical_fails":
            rows = pack.get("critical_fails") or []
            return prefix + ("Recent critical fails: " + "; ".join(f"{row.get('agent_name')} on {row.get('scored_at')} ({row.get('cause')})" for row in rows)
                             if rows else "There were no critical fails in the period.")
        return f"Unknown topic '{topic}'. Valid topics: {self.TOPICS}."

    @staticmethod
    def _find(items: dict[str, Any], name: str, label_field: str) -> tuple[str, dict | None]:
        """The entry whose key or label contains ``name``, ignoring case."""
        needle: str = name.lower()
        for key, value in items.items():
            if needle and (needle in key.lower() or needle in str(value.get(label_field) or "").lower()):
                return key, value
        return name, None

    @staticmethod
    def _describe_agent(agent: str, stats: dict[str, Any]) -> str:
        """One agent's results in a few sentences."""
        trend = stats.get("trend") or {}
        parts = [f"{agent}: {stats.get('audits')} audits, average score {stats.get('average_score')}, pass rate {stats.get('pass_rate')}%, "
                 f"critical fails {stats.get('critical_fails')}, trend {trend.get('direction')}."]
        parts += [f"{check.get('label')}: passed {check.get('pass_rate')}%." for check in stats.get("checks") or []]
        return " ".join(parts)

    @staticmethod
    def _describe_check(stats: dict[str, Any]) -> str:
        """One check's results across all agents."""
        reasons = stats.get("failure_reasons") or []
        return (f"{stats.get('label')}: passed {stats.get('pass_rate')}% ({stats.get('failed')} failed of {stats.get('audited')})."
                + (" Typical reasons it failed: " + " | ".join(reasons) if reasons else ""))
