# Replaces the stored secrets with a new .env file (for example after the passwords were rotated).
param([string]$EnvFile, [switch]$PlainFile)

$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\common.ps1"

if (-not $EnvFile) { $EnvFile = Select-EnvFile 'Choose the new .env file you were sent' }
if (-not $EnvFile -or -not (Test-Path $EnvFile)) { Write-Fail 'No file chosen. Nothing was changed.'; exit 1 }

$text = Get-Content $EnvFile -Raw
$missing = Get-MissingSecrets (ConvertFrom-EnvText $text)
if ($missing.Count -gt 0) { Write-Fail ('That file is missing: ' + ($missing -join ', ') + '. Nothing was changed.'); exit 1 }

$where = Save-SecretsText $text (-not $PlainFile)
Write-Ok "Secrets stored in $where"
Write-Info 'Delete the .env file you were sent (and empty the Recycle Bin). Restart the engine to use the new values.'
