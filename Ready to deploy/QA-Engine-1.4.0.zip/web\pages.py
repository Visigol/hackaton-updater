"""HTML for the QA Platform login page (the dashboard lives in dashboard_page.py)."""

SUPABASE_JS = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.min.js"

LOGIN_STYLE = """
<style>
  :root { --bg:#f3f5f9; --card:#fff; --text:#0f172a; --muted:#667085; --line:#e6e9f0; --accent:#2a78d6; --accent2:#6250d6; --bad:#b42318; color-scheme:light; }
  @media (prefers-color-scheme: dark) {
    :root:not([data-theme="light"]) { --bg:#0a0e15; --card:#121824; --text:#eef1f6; --muted:#98a2b3; --line:#222a39; --accent:#3987e5; --accent2:#9085e9; --bad:#f97066; color-scheme:dark; }
  }
  :root[data-theme="dark"] { --bg:#0a0e15; --card:#121824; --text:#eef1f6; --muted:#98a2b3; --line:#222a39; --accent:#3987e5; --accent2:#9085e9; --bad:#f97066; color-scheme:dark; }
  * { box-sizing:border-box; }
  body { margin:0; min-height:100vh; display:grid; place-items:center; padding:24px; color:var(--text);
         font:15px/1.5 Inter, system-ui, -apple-system, "Segoe UI", sans-serif;
         background:radial-gradient(700px 400px at 15% 0%, color-mix(in srgb, var(--accent) 22%, transparent), transparent 70%),
                    radial-gradient(600px 400px at 100% 100%, color-mix(in srgb, var(--accent2) 22%, transparent), transparent 70%), var(--bg); }
  .card { width:min(400px, 100%); background:var(--card); border:1px solid var(--line); border-radius:18px; padding:30px;
          box-shadow:0 1px 2px rgba(16,24,40,.05), 0 24px 48px -24px rgba(16,24,40,.25); }
  .logo { width:40px; height:40px; border-radius:12px; background:linear-gradient(135deg,var(--accent),var(--accent2)); margin-bottom:16px; }
  h1 { font-size:1.5rem; margin:0 0 4px; letter-spacing:-.01em; } .muted { color:var(--muted); margin:0 0 18px; }
  label { display:block; margin:14px 0 6px; font-size:.88rem; color:var(--muted); }
  input { width:100%; padding:11px 13px; border:1px solid var(--line); border-radius:10px; background:var(--bg); color:inherit; font:inherit; }
  input:focus, button:focus-visible { outline:2px solid var(--accent); outline-offset:1px; }
  button { width:100%; margin-top:20px; padding:12px; border:0; border-radius:10px; color:#fff; font:inherit; font-weight:600; cursor:pointer;
           background:linear-gradient(135deg,var(--accent),var(--accent2)); box-shadow:0 10px 24px -12px var(--accent); }
  button:disabled { opacity:.6; cursor:default; }
  .error { color:var(--bad); min-height:1.5rem; margin-top:12px; font-size:.9rem; }
</style>
"""

HEAD = (
    "<!doctype html><html lang='en'><head><meta charset='utf-8'>"
    "<meta name='viewport' content='width=device-width,initial-scale=1'>"
    "<title>QA Platform</title>" + LOGIN_STYLE +
    "<script>try{var t=localStorage.getItem('qa-theme');if(t)document.documentElement.setAttribute('data-theme',t);}catch(e){}</script>"
    "<script src='/config.js'></script>"
    f"<script src='{SUPABASE_JS}'></script></head><body>"
)

LOGIN_PAGE = HEAD + """
<main class="card">
  <div class="logo"></div>
  <h1>QA Platform</h1>
  <p class="muted">Sign in to your organization.</p>
  <form id="form">
    <label for="email">Email</label>
    <input id="email" type="email" autocomplete="username" required>
    <label for="password">Password</label>
    <input id="password" type="password" autocomplete="current-password" required>
    <button type="submit" id="submit">Sign in</button>
    <div class="error" id="error" role="alert"></div>
  </form>
</main>
<script>
  const db = supabase.createClient(window.APP_CONFIG.supabaseUrl, window.APP_CONFIG.supabaseAnonKey);
  const errorBox = document.getElementById('error');

  async function goToDashboard() {
    // Ask for the signed-in user's OWN row: the policies let a user see every user of the company, so an unfiltered
    // query returns several rows as soon as the company has two users.
    const { data: auth } = await db.auth.getUser();
    const uid = auth && auth.user ? auth.user.id : null;
    const { data, error } = uid ? await db.from('users').select('role, tenants(slug)').eq('id', uid).single()
                                : { data: null, error: new Error('no user') };
    if (error || !data || !data.tenants) {
      errorBox.textContent = 'Your account is not linked to an organization yet. Contact your admin.';
      await db.auth.signOut();
      return;
    }
    window.location.href = '/t/' + encodeURIComponent(data.tenants.slug) + '/dashboard';
  }

  document.getElementById('form').addEventListener('submit', async (event) => {
    event.preventDefault();
    errorBox.textContent = '';
    const button = document.getElementById('submit');
    button.disabled = true;
    const { error } = await db.auth.signInWithPassword({
      email: document.getElementById('email').value,
      password: document.getElementById('password').value,
    });
    button.disabled = false;
    if (error) { errorBox.textContent = error.message; return; }
    await goToDashboard();
  });

  db.auth.getSession().then(({ data }) => { if (data.session) goToDashboard(); });
</script>
</body></html>
"""
