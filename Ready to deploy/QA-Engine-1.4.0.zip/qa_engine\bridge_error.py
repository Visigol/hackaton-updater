"""Error raised when the local Chrome Gemini Nano bridge cannot produce a usable answer."""


class BridgeError(RuntimeError):
    """The bridge was unreachable, returned an HTTP error, or returned an unexpected payload."""
