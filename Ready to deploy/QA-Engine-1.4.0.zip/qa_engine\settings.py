"""Environment-based configuration. Secrets come from .env (git-ignored), never from code."""

import os

from dotenv import load_dotenv


class Settings:
    """Reads configuration from environment variables and fails loudly when a required one is missing."""

    def __init__(self) -> None:
        """Loads the .env file, if present, into the process environment."""
        load_dotenv()

    @staticmethod
    def require(name: str) -> str:
        """Returns the value of a required variable.

        :param name: environment variable name
        :return: its non-empty value
        :raises RuntimeError: when the variable is missing or empty
        """
        value: str | None = os.environ.get(name)
        if not value:
            raise RuntimeError(f"Missing required environment variable {name}. Add it to .env (see ROADMAP.md).")
        return value

    @staticmethod
    def get(name: str, default: str) -> str:
        """Returns an optional variable, or the default when it is unset."""
        return os.environ.get(name, default)
