"""Coded tool of the qa_audit network: records an auditor agent's verdict for one rubric check."""

import logging
from typing import Any

from neuro_san.interfaces.coded_tool import CodedTool

logger = logging.getLogger(__name__)


class RecordVerdict(CodedTool):
    """Stores ``{passed, reason}`` under ``sly_data["verdicts"][check_key]``.

    ``verdicts`` is the key the front man is allowed to return to the caller (``allow.to_upstream.sly_data`` in
    qa_audit.hocon), so this is how structured results leave the network. The caller computes the score from them.
    """

    TRUE_WORDS: frozenset[str] = frozenset({"true", "yes", "pass", "passed"})
    FALSE_WORDS: frozenset[str] = frozenset({"false", "no", "fail", "failed"})

    async def async_invoke(self, args: dict[str, Any], sly_data: dict[str, Any]) -> str:
        """Validates and records one verdict.

        :param args: ``{"check_key": ..., "passed": ..., "reason": ...}``
        :param sly_data: the request's bulletin board; must hold ``checks``
        :return: a confirmation, or a message that tells the auditor what to fix so it can call again
        """
        check_key: str = str(args.get("check_key") or "").strip()
        checks: dict[str, Any] = sly_data.get("checks") or {}
        if check_key not in checks:
            logger.warning("record_verdict: unknown check_key %r", check_key)
            return f"There is no check called '{check_key}'. Valid check keys: {', '.join(sorted(checks)) or '(none)'}."

        passed: bool | None = self._as_bool(args.get("passed"))
        if passed is None:
            return "The value of passed must be true or false. Call record_verdict again."

        reason: str = str(args.get("reason") or "").strip()
        verdicts: dict[str, Any] = sly_data.setdefault("verdicts", {})
        verdicts[check_key] = {"passed": passed, "reason": reason}
        if sly_data.get("demo"):
            verdicts[check_key]["demo"] = True  # the audit worker refuses demo verdicts, so they can never be scored
        logger.info("record_verdict: %s -> passed=%s", check_key, passed)
        return f"Recorded the verdict for {check_key}."

    @staticmethod
    def _as_bool(value: Any) -> bool | None:
        """Reads a real boolean, or a word a small model may write instead; None when it is neither."""
        if isinstance(value, bool):
            return value
        word: str = str(value).strip().lower()
        if word in RecordVerdict.TRUE_WORDS:
            return True
        if word in RecordVerdict.FALSE_WORDS:
            return False
        return None
