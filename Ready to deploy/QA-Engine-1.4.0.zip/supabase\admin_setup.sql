-- One-time setup so admins can edit, delete and manage everything from the web app.
-- Run once in Supabase -> SQL Editor. Safe to re-run.
-- Uses the helper functions your database already has: current_tenant() and current_user_role().

-- Staff (admin, supervisor, team_lead) can edit and delete transcripts, audits and queued jobs in their own tenant.
do $$
declare
    table_name text;
begin
    foreach table_name in array array['transcripts', 'audit_scores', 'jobs']
    loop
        execute format('drop policy if exists staff_delete on public.%I', table_name);
        execute format(
            'create policy staff_delete on public.%I for delete to authenticated
             using (tenant_id = (select current_tenant())
                    and (select current_user_role()) in (''admin'', ''supervisor'', ''team_lead''))',
            table_name);
    end loop;

    foreach table_name in array array['transcripts', 'audit_scores']
    loop
        execute format('drop policy if exists staff_update on public.%I', table_name);
        execute format(
            'create policy staff_update on public.%I for update to authenticated
             using (tenant_id = (select current_tenant())
                    and (select current_user_role()) in (''admin'', ''supervisor'', ''team_lead''))
             with check (tenant_id = (select current_tenant()))',
            table_name);
    end loop;
end $$;

-- Admins can rename their own organization.
drop policy if exists admin_update on public.tenants;
create policy admin_update on public.tenants for update to authenticated
    using (id = (select current_tenant()) and (select current_user_role()) = 'admin')
    with check (id = (select current_tenant()));

-- Audit trail: who did what, per tenant. Users can add entries about themselves and read their tenant's log, but
-- there is no update or delete policy, so entries cannot be changed or removed from the app.
create table if not exists public.audit_trail (
    id          bigint generated always as identity primary key,
    tenant_id   uuid not null default current_tenant() references public.tenants (id),
    actor_id    uuid default auth.uid(),
    actor_email text,
    action      text not null,
    detail      jsonb not null default '{}'::jsonb,
    created_at  timestamptz not null default now()
);
create index if not exists audit_trail_tenant_time on public.audit_trail (tenant_id, created_at desc);
alter table public.audit_trail enable row level security;

drop policy if exists log_select on public.audit_trail;
create policy log_select on public.audit_trail for select to authenticated
    using (tenant_id = (select current_tenant()) and (select current_user_role()) = 'admin');

drop policy if exists log_insert on public.audit_trail;
create policy log_insert on public.audit_trail for insert to authenticated
    with check (tenant_id = (select current_tenant()) and actor_id = auth.uid());

-- Rubric changes always create a NEW version and switch it on atomically; history is never overwritten.
-- Admin only, enforced here in the database (not just hidden in the UI). Every change is logged with its actor.
create or replace function public.save_rubric(p_parameters jsonb) returns int
language plpgsql security definer set search_path = public as $$
declare
    v_tenant uuid := current_tenant();
    v_next   int;
begin
    if current_user_role() is distinct from 'admin' then
        raise exception 'Only admins can change the rubric' using errcode = '42501';
    end if;
    if jsonb_typeof(p_parameters -> 'checks') is distinct from 'array' then
        raise exception 'The rubric needs a checks array' using errcode = '22023';
    end if;

    select coalesce(max(version), 0) + 1 into v_next from public.rubrics where tenant_id = v_tenant;
    update public.rubrics set is_active = false where tenant_id = v_tenant and is_active;
    insert into public.rubrics (tenant_id, version, is_active, parameters)
    values (v_tenant, v_next, true, p_parameters);

    insert into public.audit_trail (tenant_id, actor_id, actor_email, action, detail)
    values (v_tenant, auth.uid(), (select email from public.users where id = auth.uid()), 'rubric.saved',
            jsonb_build_object('version', v_next, 'checks', jsonb_array_length(p_parameters -> 'checks')));
    return v_next;
end $$;

revoke all on function public.save_rubric(jsonb) from public, anon;
grant execute on function public.save_rubric(jsonb) to authenticated;
