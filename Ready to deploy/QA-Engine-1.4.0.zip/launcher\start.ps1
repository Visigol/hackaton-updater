# Starts the whole QA engine (Chrome + Gemini Nano, bridge, Neuro SAN, watcher, worker) and keeps it running.
# Same stack and ports as start_all.bat on the developer's machine, but with hidden windows, log files,
# automatic restarts and a "keep the PC awake" request while it runs.
param([switch]$NoBrowser)

$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\common.ps1"

New-Item -ItemType Directory -Force -Path $script:RunDir, $script:LogDir, (Join-Path $script:DataDir 'inbox'), (Join-Path $script:DataDir 'processed'), (Join-Path $script:DataDir 'failed') | Out-Null
$pidFile = Join-Path $script:RunDir 'supervisor.pid'
$stopFile = Join-Path $script:RunDir 'stop.flag'
$statusFile = Join-Path $script:RunDir 'status.json'

# Only one engine per computer.
if (Test-Path $pidFile) {
    $other = Get-Process -Id ([int](Get-Content $pidFile -Raw)) -ErrorAction SilentlyContinue
    if ($other -and $other.Id -ne $PID) { Write-Warn "The engine is already running (process $($other.Id)). Use Stop first if you want to restart it."; exit 0 }
}
Set-Content -Path $pidFile -Value $PID
Remove-Item $stopFile -Force -ErrorAction SilentlyContinue

$app = Get-AppDir
$python = Get-VenvPython
$version = (Get-Content (Join-Path $script:Root 'current.txt') -Raw).Trim()
Import-Secrets | Out-Null
$env:OPENAI_API_KEY = 'local-nano'          # Neuro SAN needs a value; the bridge answers instead of OpenAI (nano mode)
$provider = 'nano'
if ($env:AI_PROVIDER) { $provider = $env:AI_PROVIDER.Trim().ToLower() }
if ($provider -notin 'nano', 'gemini') { Write-Fail "AI_PROVIDER must be nano or gemini, not '$provider' (see .env)."; exit 1 }
$env:PYTHONUNBUFFERED = '1'
$env:PYTHONIOENCODING = 'utf-8'
# The agents' conversation, for the "Show logs" window. Kept small: a big old file is dropped at start.
$env:QA_AGENT_TRACE_FILE = Join-Path $script:LogDir 'agents.log'
if ((Test-Path $env:QA_AGENT_TRACE_FILE) -and (Get-Item $env:QA_AGENT_TRACE_FILE).Length -gt 2MB) { Remove-Item $env:QA_AGENT_TRACE_FILE -Force -ErrorAction SilentlyContinue }

Write-Step "QA engine $version  (AI: $provider)"

# Point every agent network at the chosen model (Gemini Nano in Chrome, or cloud Gemini). Safe to repeat.
Push-Location $app
try { & $python (Join-Path $app 'switch_llm.py'); $switched = $LASTEXITCODE } finally { Pop-Location }
if ($switched -ne 0) { Write-Fail 'Could not set the AI provider in the agent networks.'; exit 1 }

# ---- keep Windows awake while the engine runs (released automatically when this process ends)
Add-Type -Namespace Win32 -Name Power -MemberDefinition '[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint flags);' -ErrorAction SilentlyContinue
function Request-KeepAwake { [Win32.Power]::SetThreadExecutionState([uint32]2147483649) | Out-Null }   # ES_CONTINUOUS (0x80000000) + ES_SYSTEM_REQUIRED (0x1); 5.1 reads a hex literal this big as a negative Int32

# ---- the processes to run
$chrome = Find-Chrome
if ($provider -eq 'nano' -and -not $chrome) { Write-Fail 'Google Chrome was not found. Install Chrome and run Start again.'; exit 1 }
$chromeProfile = 'C:\ChromeNanoSession'
$services = @(
    @{ Name = 'chrome';   Exe = $chrome; Cwd = $app; Port = 9222; Log = $false
       Args = @('--remote-debugging-port=9222', '--enable-features=PromptAPIForGeminiNano,OptimizationGuideOnDeviceModel,SummarizationAPIForGeminiNano',
                '--enable-blink-features=AISummarizationAPI', "--user-data-dir=$chromeProfile", '--no-first-run', '--no-default-browser-check') },
    @{ Name = 'bridge';   Exe = $python; Cwd = $app; Port = 8000; Log = $true; Args = @('bridge.py') },
    @{ Name = 'neurosan'; Exe = $python; Cwd = $app; Port = 8080; Log = $true
       Args = @('-m', 'neuro_san_studio', 'run', '--server-only', '--server-host', '127.0.0.1', '--server-http-port', '8080') },
    @{ Name = 'studio';   Exe = $python; Cwd = $app; Port = 4173; Log = $true
       Args = @('-m', 'neuro_san_studio', 'run', '--client-only', '--nsflow-port', '4173') },
    @{ Name = 'watcher';  Exe = $python; Cwd = $script:DataDir; Port = 0; Log = $true; Args = @((Join-Path $app 'watcher.py')); After = 'ready' },
    @{ Name = 'worker';   Exe = $python; Cwd = $app; Port = 0; Log = $true; Args = @('worker.py'); After = 'ready' }
)
if ($provider -eq 'gemini') { $services = @($services | Where-Object { $_.Name -notin 'chrome', 'bridge' }) }   # cloud mode: no Chrome, no bridge
$running = @{}

function Start-Service1($Service) {
    if ($Service.Port -gt 0 -and (Test-PortOpen $Service.Port)) {
        if ($Service.Name -eq 'chrome') { Write-Info 'Chrome is already running on port 9222, reusing it.'; return $null }
        # A leftover process from an earlier run holds the port: free it.
        Get-NetTCPConnection -LocalPort $Service.Port -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
        Start-Sleep -Seconds 1
    }
    if ($Service.Log) {
        # One log file per service with BOTH normal output and errors (Python's logging writes to stderr).
        $log = Join-Path $script:LogDir ($Service.Name + '.log')
        $quoted = @($Service.Args | ForEach-Object { if ($_ -match '\s') { '"' + $_ + '"' } else { $_ } }) -join ' '
        $params = @{ FilePath = $env:ComSpec; ArgumentList = ('/c ""{0}" {1} > "{2}" 2>&1"' -f $Service.Exe, $quoted, $log)
                     WorkingDirectory = $Service.Cwd; PassThru = $true; WindowStyle = 'Hidden' }
    } else {
        $params = @{ FilePath = $Service.Exe; ArgumentList = $Service.Args; WorkingDirectory = $Service.Cwd; PassThru = $true; WindowStyle = 'Minimized' }
    }
    $proc = Start-Process @params
    Write-Ok ("started {0} (process {1})" -f $Service.Name, $proc.Id)
    return $proc
}

function Save-Status([string]$State, [string]$Detail) {
    $pids = @{}
    foreach ($key in $running.Keys) { if ($running[$key]) { $pids[$key] = $running[$key].Id } }
    @{ state = $State; detail = $Detail; version = $version; provider = $provider; updated = (Get-Date).ToString('s'); supervisor = $PID; pids = $pids } |
        ConvertTo-Json | Set-Content -Path $statusFile -Encoding UTF8
}

function Test-StackReady {
    $list = Get-Json 'http://127.0.0.1:8080/api/v1/list'
    if ($provider -eq 'gemini') { return [bool]$list }              # the cloud model needs no warm-up
    $health = Get-Json 'http://127.0.0.1:8000/health'
    return [bool]($health -and $health.model_ready -and $list)
}

try {
    Request-KeepAwake
    Save-Status 'starting' 'Starting Chrome, bridge and Neuro SAN'
    foreach ($service in ($services | Where-Object { -not $_.After })) {
        $running[$service.Name] = Start-Service1 $service
        Start-Sleep -Seconds 3
    }

    # The worker retries a failed audit only a few times, so it must not start while the model is still loading
    # (the very first start downloads and loads Gemini Nano: it can take several minutes).
    Write-Step 'Waiting for the model and the Neuro SAN server (nano: first start can take several minutes)'
    $ready = $false
    for ($i = 0; $i -lt 180 -and -not $ready; $i++) {
        if (Test-Path $stopFile) { break }
        Request-KeepAwake
        if (Test-StackReady) { $ready = $true } else { Start-Sleep -Seconds 5 }
    }
    if ($ready -and $provider -eq 'gemini') { Write-Ok 'Neuro SAN is up (cloud Gemini needs no model loading).' }
    elseif ($ready) { Write-Ok 'Model loaded and Neuro SAN is up.' }
    else { Write-Warn 'The model was not ready after 15 minutes; starting the worker anyway. Run Status to see what is wrong.' }

    foreach ($service in ($services | Where-Object { $_.After })) { $running[$service.Name] = Start-Service1 $service }
    Save-Status 'running' 'Engine running'
    Write-Step 'The engine is running. Leave this window open (or minimised). Close it or run Stop to shut everything down.'
    if (-not $NoBrowser) { Start-Process 'http://127.0.0.1:4173' | Out-Null }

    # ---- supervise: restart anything that died, keep the machine awake
    $restarts = @{}
    while (-not (Test-Path $stopFile)) {
        Start-Sleep -Seconds 15
        Request-KeepAwake
        foreach ($service in $services) {
            $proc = $running[$service.Name]
            $alive = $false
            if ($proc) { $alive = -not $proc.HasExited }
            elseif ($service.Name -eq 'chrome') { $alive = Test-PortOpen 9222 }
            if ($alive) { continue }
            $count = 1 + [int]$restarts[$service.Name]
            $restarts[$service.Name] = $count
            Write-Warn ("{0} stopped, restarting (attempt {1})" -f $service.Name, $count)
            Add-Content -Path (Join-Path $script:LogDir 'supervisor.log') -Value ("{0}  restarted {1} (attempt {2})" -f (Get-Date -Format s), $service.Name, $count)
            Start-Sleep -Seconds ([Math]::Min(60, 5 * $count))
            $running[$service.Name] = Start-Service1 $service
        }
        Save-Status 'running' 'Engine running'
    }
} finally {
    Save-Status 'stopping' 'Shutting down'
    & (Join-Path $PSScriptRoot 'stop.ps1') -FromSupervisor
    Remove-Item $pidFile, $stopFile -Force -ErrorAction SilentlyContinue
    Save-Status 'stopped' 'Engine stopped'
}
