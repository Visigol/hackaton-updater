"""Deterministic statistics for a performance report. Numbers come from code; an agent only turns them into words."""


class PerformanceStats:
    """Computes an agent's results over a period from their audits."""

    TREND_MIN_AUDITS: int = 4
    TREND_THRESHOLD: float = 3.0
    EXAMPLES_PER_CHECK: int = 2
    EXAMPLE_LENGTH: int = 160

    @staticmethod
    def compute(audits: list[dict], checks: list[dict], agent_name: str, period: str) -> dict:
        """Summarizes the audits.

        :param audits: audit_scores rows for one agent: overall_score, passed, critical_fail, scored_at, scores
        :param checks: the rubric's checks ({"key", "label"}), used to name and order the per-check results
        :param agent_name: the agent being reported on
        :param period: a label such as "last 30 days"
        :return: counts, average, pass rate, trend and, per check, the pass rate with a few failure reasons
        """
        ordered: list[dict] = sorted(audits, key=lambda audit: str(audit.get("scored_at")))
        scores: list[float] = [float(audit.get("overall_score") or 0) for audit in ordered]
        count: int = len(ordered)
        return {
            "agent_name": agent_name,
            "period": period,
            "audits": count,
            "average_score": round(sum(scores) / count, 1) if count else 0.0,
            "pass_rate": round(100 * sum(1 for audit in ordered if audit.get("passed")) / count) if count else 0,
            "critical_fails": sum(1 for audit in ordered if audit.get("critical_fail")),
            "best_score": max(scores) if scores else None,
            "worst_score": min(scores) if scores else None,
            "trend": PerformanceStats._trend(scores),
            "checks": [PerformanceStats._check(check, ordered) for check in checks],
        }

    @staticmethod
    def _trend(scores: list[float]) -> dict:
        """Compares the average of the first half of the period with the second half."""
        if len(scores) < PerformanceStats.TREND_MIN_AUDITS:
            return {"direction": "not enough audits to tell", "change": None}
        half: int = len(scores) // 2
        first, second = scores[:half], scores[half:]
        change: float = round(sum(second) / len(second) - sum(first) / len(first), 1)
        if change >= PerformanceStats.TREND_THRESHOLD:
            direction = "improving"
        elif change <= -PerformanceStats.TREND_THRESHOLD:
            direction = "declining"
        else:
            direction = "steady"
        return {"direction": direction, "change": change}

    @staticmethod
    def _check(check: dict, audits: list[dict]) -> dict:
        """How often one check was passed, and what the reasons for failing it were."""
        key: str = check["key"]
        verdicts: list[dict] = [audit["scores"][key] for audit in audits
                                if isinstance((audit.get("scores") or {}).get(key), dict)]
        failed: list[dict] = [verdict for verdict in verdicts if not verdict.get("passed")]
        reasons: list[str] = [str(verdict.get("reason") or "").strip()[:PerformanceStats.EXAMPLE_LENGTH]
                              for verdict in failed if str(verdict.get("reason") or "").strip()]
        return {
            "key": key,
            "label": check.get("label") or key,
            "audited": len(verdicts),
            "failed": len(failed),
            "pass_rate": round(100 * (len(verdicts) - len(failed)) / len(verdicts)) if verdicts else None,
            "failure_reasons": reasons[:PerformanceStats.EXAMPLES_PER_CHECK],
        }
