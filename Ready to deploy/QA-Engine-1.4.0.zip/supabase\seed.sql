-- Create the first tenant and link your login to it as admin.
-- 1. In Supabase: Authentication -> Users -> Add user -> Create new user
--    (tick "Auto Confirm User"). Use the email below.
-- 2. Edit the two values below, then run this in the SQL Editor.

select public.create_tenant('Acme BPO', 'acme-bpo');

insert into public.users (id, tenant_id, email, role)
select u.id, t.id, u.email, 'admin'
from auth.users u
join public.tenants t on t.slug = 'acme-bpo'
where u.email = 'YOUR_EMAIL_HERE';

-- Optional: one fake transcript + audit so the dashboard has something to show.
insert into public.transcripts (tenant_id, agent_name, channel, raw_text)
select id, 'Maria Silva', 'voice', 'Sample call transcript...' from public.tenants where slug = 'acme-bpo';

insert into public.audit_scores (tenant_id, transcript_id, rubric_version, scores, flags, overall_score)
select t.tenant_id, t.id, 1,
       '{"greeting": 9, "empathy": 16, "resolution": 34, "compliance": 18, "closing": 9}'::jsonb,
       '[]'::jsonb, 86
from public.transcripts t
where t.agent_name = 'Maria Silva'
limit 1;
