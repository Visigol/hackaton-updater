"""Builds, for each rubric check, the findings the research agent works from: corrections and policy excerpts."""

import re


class FindingsBuilder:
    """Pure functions (no database, no model) that turn reviewer corrections and policy documents into findings."""

    MAX_CORRECTIONS_PER_CHECK: int = 6
    EXCERPT_LENGTH: int = 300
    SNIPPETS_PER_CHECK: int = 2
    SNIPPET_LENGTH: int = 450
    MIN_SHARED_WORDS: int = 2
    MIN_PARAGRAPH: int = 60
    WORD: re.Pattern[str] = re.compile(r"[a-zA-Z]{5,}")  # words of five or more letters carry the meaning

    @staticmethod
    def build(checks: list[dict], feedback: list[dict], documents: list[dict], min_corrections: int) -> dict[str, dict]:
        """Returns ``{check_key: {label, rules, corrections, policy_snippets}}`` for the checks worth working on.

        A check is included when reviewers corrected the AI on it at least ``min_corrections`` times, or when a policy
        document says something relevant to it.

        :param checks: the rubric's checks ({"key", "label", "rules"})
        :param feedback: rule_feedback rows, newest first ({"check_key", "ai_passed", "human_passed", "ai_reason",
            "human_reason", "raw_text"}); rows where the human agreed with the AI are ignored
        :param documents: knowledge-base documents ({"title", "content"})
        :param min_corrections: how many corrections make a check worth working on
        """
        findings: dict[str, dict] = {}
        for check in checks:
            key: str = check.get("key")
            corrections: list[dict] = [
                {"ai_passed": bool(row.get("ai_passed")), "human_passed": bool(row.get("human_passed")),
                 "ai_reason": (row.get("ai_reason") or "")[:300], "human_reason": (row.get("human_reason") or "")[:300],
                 "excerpt": FindingsBuilder._excerpt(row.get("raw_text") or "")}
                for row in feedback
                if row.get("check_key") == key and bool(row.get("ai_passed")) != bool(row.get("human_passed"))
            ][:FindingsBuilder.MAX_CORRECTIONS_PER_CHECK]
            snippets: list[dict] = FindingsBuilder._snippets(check, documents)
            if len(corrections) >= min_corrections or snippets:
                findings[key] = {"label": check.get("label") or key, "rules": list(check.get("rules") or []),
                                 "corrections": corrections, "policy_snippets": snippets}
        return findings

    @staticmethod
    def _excerpt(text: str) -> str:
        """The start of the transcript, on one line, as context for a correction."""
        flat: str = " / ".join(line.strip() for line in text.splitlines() if line.strip())
        return flat[:FindingsBuilder.EXCERPT_LENGTH] + ("..." if len(flat) > FindingsBuilder.EXCERPT_LENGTH else "")

    @staticmethod
    def _snippets(check: dict, documents: list[dict]) -> list[dict]:
        """The paragraphs of the documents that share the most meaningful words with the check's label and rules."""
        wanted: set[str] = {word.lower() for word in FindingsBuilder.WORD.findall(
            " ".join([str(check.get("label") or "")] + [str(rule) for rule in check.get("rules") or []]))}
        scored: list[tuple[int, dict]] = []
        for document in documents:
            for paragraph in re.split(r"\n\s*\n", str(document.get("content") or "")):
                text: str = " ".join(paragraph.split())
                if len(text) < FindingsBuilder.MIN_PARAGRAPH:
                    continue
                shared: int = len(wanted & {word.lower() for word in FindingsBuilder.WORD.findall(text)})
                if shared >= FindingsBuilder.MIN_SHARED_WORDS:
                    scored.append((shared, {"title": document.get("title") or "Document",
                                            "text": text[:FindingsBuilder.SNIPPET_LENGTH]}))
        scored.sort(key=lambda item: item[0], reverse=True)
        return [snippet for _, snippet in scored[:FindingsBuilder.SNIPPETS_PER_CHECK]]
