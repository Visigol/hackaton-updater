"""Dashboard JavaScript, part 2 of 3: reviews and contests, reports, learning, assistant chat, knowledge base and
rubric proposals. Continues the function scope opened in dashboard_js_core.py (the three strings are concatenated).
"""

JS_WORKFLOW = r"""
// ---- shared helpers for the agent features
const SETUP_HELP = 'This feature needs the one-time database setup: run supabase/platform_setup.sql in the Supabase SQL Editor.';
const isMissing = (error) => !!error && ['42P01', '42703', 'PGRST205', 'PGRST204', '42501'].includes(error.code);
const friendly = (error) => (isMissing(error) ? SETUP_HELP : error.message);
const staffEmail = () => (state.me ? state.me.email : null);

async function queueJob(kind, payload) {
  const { error } = await db.from('jobs').insert({ tenant_id: state.tenant.id, kind, payload });
  if (error) { toast('Could not queue the job: ' + friendly(error), 'error'); return false; }
  return true;
}

function formDialog(title, intro, fields, confirmLabel, validate) {
  // Opens a dialog with the given field elements; resolves with true when confirmed and valid, false otherwise.
  return new Promise((resolve) => {
    const problem = h('div', { class: 'error', role: 'alert' });
    const dialog = h('dialog', {}, h('h3', { text: title }), h('p', { text: intro }), fields, problem,
      h('div', { class: 'row', style: 'margin-top:14px' },
        h('button', { class: 'btn', type: 'button', onclick: () => dialog.close('cancel'), text: 'Cancel' }),
        h('button', { class: 'btn primary', type: 'button', onclick: () => { const message = validate(); if (message) problem.textContent = message; else dialog.close('ok'); }, text: confirmLabel })));
    dialog.addEventListener('close', () => { resolve(dialog.returnValue === 'ok'); dialog.remove(); });
    document.body.append(dialog);
    dialog.showModal();
  });
}

const statusTag = (status) => h('span', { class: 'tag' + (status === 'rejected' ? ' crit' : ''), text: nice(status) });
const rowByTranscript = (id) => state.rows.find((r) => r.id === id);

// ---- review requests: an agent contests a result or asks for a new audit; staff resolve it
async function updateReviewBadge() {
  const badge = $('#nav-reviews-count');
  if (!badge) return;
  try {
    const { count, error } = await db.from('review_requests').select('id', { count: 'exact', head: true }).eq('status', 'pending');
    if (error) return;
    const total = (count || 0) + state.rows.filter((r) => r.needsReview).length; // agent requests + audits the AI flagged
    badge.textContent = String(total);
    badge.hidden = !total;
  } catch (error) { /* the badge is a convenience */ }
}

async function openRequestDialog(row, kind) {
  const audit = row.audit;
  const checks = checkList(row);
  const boxes = checks.map((c) => {
    const failed = !((audit.scores || {})[c.key] || {}).passed;
    return h('label', { style: 'display:flex;gap:8px;align-items:center;margin:4px 0' },
      h('input', { type: 'checkbox', value: c.key, checked: failed }), c.label + (failed ? ' (failed)' : ' (passed)'));
  });
  const comment = h('textarea', { class: 'textarea', style: 'min-height:110px;font-family:inherit', maxlength: '1000',
    placeholder: kind === 'contest' ? 'Explain what the AI got wrong, and quote the part of the call that shows it.' : 'Why should this call be audited again?' });
  const fields = [kind === 'contest' ? h('div', { class: 'field' }, h('label', { text: 'Which checks do you contest?' }), boxes) : null,
    h('div', { class: 'field' }, h('label', { text: 'Your explanation (at least 10 characters)' }), comment)];
  const picked = () => boxes.map((b) => b.querySelector('input')).filter((i) => i.checked).map((i) => i.value);
  const confirmed = await formDialog(kind === 'contest' ? 'Contest this result' : 'Ask for a new audit',
    'A supervisor will review your request. You will see the answer under My requests.', fields, 'Send request',
    () => (comment.value.trim().length < 10 ? 'Please write at least 10 characters.' : kind === 'contest' && !picked().length ? 'Pick at least one check.' : ''));
  if (!confirmed) return;
  const { error } = await db.from('review_requests').insert({ audit_id: audit.id, transcript_id: row.id, kind, check_keys: kind === 'contest' ? picked() : [],
    comment: comment.value.trim(), requested_by_email: staffEmail() });
  if (error) { toast(error.code === '23505' ? 'You already have a pending request of this kind for this audit.' : 'Could not send the request: ' + friendly(error), 'error'); return; }
  toast('Request sent. A supervisor will look at it.', 'ok');
  logActivity('review.requested', { kind, transcript_id: row.id, agent: row.agent_name, checks: picked() });
}

async function paintRequestsCard(row, body) {
  const { data, error } = await db.from('review_requests').select('*').eq('audit_id', row.audit.id).eq('status', 'pending').order('created_at');
  if (error || !data || !data.length) return;
  const card = h('div', { class: 'card', style: 'border-color:var(--accent)' }, h('h3', { text: 'Requests from the agent' }));
  for (const request of data) {
    card.append(h('div', { style: 'margin-top:10px' },
      h('div', {}, h('span', { class: 'tag', text: request.kind === 'contest' ? 'Contest' : 'New audit requested' }), ' ', h('span', { class: 'muted small', text: request.requested_by_email + ' - ' + ago(request.created_at) })),
      request.check_keys && request.check_keys.length ? h('div', { class: 'muted small', text: 'Checks: ' + request.check_keys.map(nice).join(', ') }) : null,
      h('p', { style: 'margin:6px 0', text: request.comment }),
      h('div', { style: 'display:flex;gap:8px;flex-wrap:wrap' },
        h('button', { class: 'btn sm', type: 'button', onclick: () => answerRequest(request, 'accepted', true) }, icon('redo', 15), 'Accept and re-audit'),
        h('button', { class: 'btn sm danger', type: 'button', onclick: () => answerRequest(request, 'rejected', false) }, icon('x', 15), 'Reject'),
        request.kind === 'contest' ? h('span', { class: 'muted small', style: 'align-self:center', text: 'Or use Review & edit score: the request closes by itself.' }) : null)));
  }
  // Right under the score summary, where a supervisor looks first, not below the buttons.
  if (body.children.length > 1) body.children[0].after(card); else body.append(card);
}

async function answerRequest(request, status, reauditNow) {
  const note = h('textarea', { class: 'textarea', style: 'min-height:90px;font-family:inherit', maxlength: '500', placeholder: 'A short note the agent will see.' });
  const confirmed = await formDialog(status === 'accepted' ? 'Accept this request' : 'Reject this request',
    status === 'accepted' ? 'The call will be audited again, and the agent is told.' : 'The agent sees your note. If you disagree with the contest, say why.',
    [h('div', { class: 'field' }, h('label', { text: 'Note for the agent' }), note)], status === 'accepted' ? 'Accept' : 'Reject',
    () => (note.value.trim().length < 5 ? 'Please write a short note.' : ''));
  if (!confirmed) return;
  const resolved = await resolveRequest(request, status, note.value.trim());
  if (!resolved) return;
  if (reauditNow) { const row = rowByTranscript(request.transcript_id); if (row) await reaudit([row]); }
  toast('Request ' + status + '.', 'ok');
  if (state.view === 'reviews') renderReviews();
  if (state.drawerId) { const row = rowByTranscript(state.drawerId); if (row) paintDrawer(row, 'view'); }
}

async function resolveRequest(request, status, note) {
  const { data, error } = await db.from('review_requests').update({ status, resolution: note, resolved_by_email: staffEmail(), resolved_at: new Date().toISOString() })
    .eq('id', request.id).eq('status', 'pending').select('id');
  if (error || !data.length) { toast('Could not update the request: ' + (error ? friendly(error) : 'it was already resolved or you lack permission'), 'error'); return false; }
  logActivity('review.' + status, { request_id: request.id, kind: request.kind, transcript_id: request.transcript_id });
  if (status === 'rejected' && request.kind === 'contest') {
    // The reviewer confirmed the AI: that is learning data too (agreement), not only the corrections.
    const row = rowByTranscript(request.transcript_id);
    if (row && row.audit) {
      const same = {};
      for (const key of request.check_keys || []) { const v = (row.audit.scores || {})[key] || {}; same[key] = { passed: !!v.passed, reason: v.reason || '' }; }
      await captureFeedback(row, same, same, 'contest', note);
    }
  }
  updateReviewBadge();
  return true;
}

async function resolvePendingContests(row, note) {
  // A reviewer who corrects an audit has, in effect, accepted any contest of it.
  try {
    const { data, error } = await db.from('review_requests').update({ status: 'accepted', resolution: note, resolved_by_email: staffEmail(), resolved_at: new Date().toISOString() })
      .eq('audit_id', row.audit.id).eq('kind', 'contest').eq('status', 'pending').select('id');
    if (error || !data.length) return false;
    updateReviewBadge();
    return true;
  } catch (error) { return false; }
}

async function captureFeedback(row, original, verdicts, source, humanNote) {
  // One row per check: what the AI said and what the human decided. This is the learning data.
  const rows = Object.keys(verdicts).filter((key) => original[key]).map((key) => ({
    audit_id: row.audit.id, transcript_id: row.id, check_key: key, rubric_version: row.audit.rubric_version,
    ai_passed: !!original[key].passed, ai_reason: original[key].reason || null,
    human_passed: !!verdicts[key].passed, human_reason: (humanNote || verdicts[key].reason || '').slice(0, 500) || null,
    source, created_by_email: staffEmail(),
  }));
  if (!rows.length) return;
  const { error } = await db.from('rule_feedback').insert(rows);
  if (error && !state.feedbackWarned) { state.feedbackWarned = true; toast('The correction was saved, but the learning data was not: ' + friendly(error), 'error'); }
}

// Two switches on the Reviews screen: where the review comes from (agents or the AI) and pending/resolved.
function reviewSwitches(tab, source) {
  const aiCount = state.rows.filter((r) => r.needsReview).length;
  const pick = (options, current, apply) => h('div', { class: 'seg', role: 'group' }, options.map(([value, label]) =>
    h('button', { type: 'button', 'aria-pressed': String(current === value), text: label, onclick: () => { apply(value); renderReviews(); } })));
  return h('div', { style: 'display:flex;gap:14px;flex-wrap:wrap;margin-bottom:14px;align-items:center' },
    pick([['agents', 'Requested by agents'], ['ai', 'Flagged by the AI' + (aiCount ? ' (' + aiCount + ')' : '')]], source, (value) => { state.reviewSource = value; }),
    pick([['pending', 'Pending'], ['resolved', 'Resolved']], tab, (value) => { state.reviewTab = value; }));
}

// Audits the AI itself flagged: pending ones carry a NEEDS_REVIEW flag, resolved ones were reviewed after being flagged.
function renderAiFlagged(root, tab) {
  const rows = state.rows.filter((r) => (tab === 'pending' ? r.needsReview : !!(r.audit && r.audit.scores && r.audit.scores._review && r.audit.scores._review.ai_flagged)));
  if (!rows.length) {
    root.append(emptyState(tab === 'pending' ? 'Nothing flagged by the AI' : 'Nothing resolved yet',
      tab === 'pending' ? 'When the AI marks a critical fail it cannot back up with a quote, the audit is listed here for a person to decide.' : 'Audits you review after the AI flagged them appear here.'));
    return;
  }
  const head = h('tr', {}, h('th', { text: 'Scored' }), h('th', { text: 'Agent' }), h('th', { text: 'Flagged check' }), h('th', { text: 'Why it was flagged' }), h('th', { text: 'Score' }), h('th'));
  const body = h('tbody', {}, rows.map((row) => {
    const flags = tab === 'pending' ? reviewFlags(row.audit) : (row.audit.scores._review.flags || []);
    const reasons = flags.map(reviewReason);
    return h('tr', {},
      h('td', { class: 'muted', title: fmtDateTime(row.audit.scored_at), text: ago(row.audit.scored_at) }),
      h('td', { text: row.agent_name }),
      h('td', {}, reasons.map((r) => h('div', {}, h('span', { class: 'tag crit', text: r.label })))),
      h('td', { class: 'muted small', style: 'max-width:380px' }, reasons.map((r) => h('div', { text: r.text }))),
      h('td', {}, badge(row.status), tab === 'resolved' ? h('div', { class: 'muted small', text: 'Reviewed by ' + row.audit.scores._review.by }) : null),
      h('td', { class: 'actions' },
        h('button', { class: 'btn sm primary', type: 'button', onclick: () => { openDrawer(row.id); setTimeout(() => { const fresh = rowByTranscript(row.id); if (fresh && state.drawerId === row.id) paintDrawer(fresh, 'review'); }, 400); } },
          tab === 'pending' ? 'Review & edit score' : 'Open')));
  }));
  root.append(h('div', { class: 'card fade' }, h('div', { class: 'table-wrap' }, h('table', {}, h('thead', {}, head), body))));
}

async function renderReviews() {
  const root = $('#view-reviews');
  const staff = canWrite();
  const source = staff ? (state.reviewSource || 'agents') : 'agents';
  const tab = state.reviewTab || 'pending';
  if (source === 'ai') {
    root.replaceChildren(reviewSwitches(tab, source));
    renderAiFlagged(root, tab);
    return;
  }
  root.replaceChildren(h('div', { class: 'card' }, h('div', { class: 'sk' }), h('div', { class: 'sk', style: 'width:60%;margin-top:10px' })));
  const { data, error } = await db.from('review_requests').select('*').order('created_at', { ascending: false }).limit(200);
  root.replaceChildren();
  if (error) { root.append(emptyState('Not available yet', friendly(error))); return; }
  const requests = staff ? data.filter((r) => (tab === 'pending') === (r.status === 'pending')) : data;
  if (staff) root.append(reviewSwitches(tab, source));
  if (!requests.length) {
    root.append(emptyState(staff ? (tab === 'pending' ? 'Nothing waiting' : 'Nothing resolved yet') : 'No requests yet',
      staff ? 'When an agent contests a result or asks for a new audit, it appears here.' : 'Open one of your audits and choose Contest this result, or Ask for a new audit.'));
    return;
  }
  const head = h('tr', {}, h('th', { text: 'When' }), staff ? h('th', { text: 'Agent' }) : null, h('th', { text: 'Type' }), h('th', { text: 'Checks' }), h('th', { text: 'Explanation' }),
    staff ? h('th', { text: 'From' }) : null, h('th', { text: 'Status' }), h('th'));
  const body = h('tbody', {}, requests.map((r) => {
    const row = rowByTranscript(r.transcript_id);
    return h('tr', {},
      h('td', { class: 'muted', title: fmtDateTime(r.created_at), text: ago(r.created_at) }),
      staff ? h('td', { text: row ? row.agent_name : '-' }) : null,
      h('td', {}, h('span', { class: 'tag', text: r.kind === 'contest' ? 'Contest' : 'New audit' })),
      h('td', { class: 'muted small', text: (r.check_keys || []).map(nice).join(', ') || '-' }),
      h('td', { style: 'max-width:340px', text: r.comment }),
      staff ? h('td', { class: 'muted small', text: r.requested_by_email || '-' }) : null,
      h('td', {}, statusTag(r.status), r.resolution ? h('div', { class: 'muted small', style: 'max-width:260px', text: r.resolved_by_email + ': ' + r.resolution }) : null),
      h('td', { class: 'actions' }, row ? h('button', { class: 'icon-btn', type: 'button', title: 'Open the audit', 'aria-label': 'Open the audit', onclick: () => openDrawer(row.id) }, icon('eye')) : null,
        staff && r.status === 'pending' ? h('button', { class: 'btn sm', type: 'button', onclick: () => answerRequest(r, 'accepted', true) }, 'Accept') : null,
        staff && r.status === 'pending' ? h('button', { class: 'btn sm danger', type: 'button', onclick: () => answerRequest(r, 'rejected', false) }, 'Reject') : null));
  }));
  root.append(h('div', { class: 'card fade' }, h('div', { class: 'table-wrap' }, h('table', {}, h('thead', {}, head), body))));
}

// ---- reports (performance agent)
async function renderReports() {
  const root = $('#view-reports');
  const [reports, jobs] = await Promise.all([
    db.from('performance_reports').select('*').order('generated_at', { ascending: false }).limit(30),
    canWrite() ? db.from('jobs').select('*').eq('kind', 'report') : Promise.resolve({ data: [] }),
  ]);
  if (state.view !== 'reports') return;
  root.replaceChildren();
  if (reports.error) { root.append(emptyState('Not available yet', friendly(reports.error))); return; }
  const recent = (jobs.data || []).filter((j) => j.status !== 'done');
  const running = recent.filter((j) => j.status !== 'failed');
  const failed = recent.filter((j) => j.status === 'failed').slice(-3);

  if (canWrite()) {
    const agents = [...new Set(state.rows.filter((r) => r.audit).map((r) => r.agent_name))].sort();
    const agent = h('select', { class: 'select', 'aria-label': 'Agent' }, agents.map((a) => h('option', { value: a, text: a })));
    const period = h('select', { class: 'select', 'aria-label': 'Period' }, [['7', 'Last 7 days'], ['30', 'Last 30 days'], ['90', 'Last 90 days']].map(([v, l]) => h('option', { value: v, text: l, selected: v === '30' })));
    root.append(h('div', { class: 'card fade', style: 'margin-bottom:16px' },
      h('div', { class: 'card-head' }, h('h2', { text: 'Write a coaching report' }), h('span', { class: 'muted small', text: 'The numbers are calculated; the agent only writes the advice' })),
      agents.length ? h('div', { style: 'display:flex;gap:10px;flex-wrap:wrap;align-items:center' }, agent, period,
        h('button', { class: 'btn primary', type: 'button', onclick: async (event) => {
          event.target.disabled = true;
          if (await queueJob('report', { agent_name: agent.value, period_days: Number(period.value) })) { toast('Report requested. It takes a few minutes.', 'ok'); renderReports(); }
          event.target.disabled = false;
        } }, icon('chart', 16), 'Generate')) : h('p', { class: 'muted', text: 'No agent has a scored audit yet.' }),
      running.map((j) => h('div', { class: 'badge', style: 'margin-top:10px;--c:var(--accent)' }, icon('redo', 14), 'Writing the report for ' + (j.payload || {}).agent_name + '...')),
      failed.map((j) => h('div', { class: 'small', style: 'margin-top:8px;color:var(--critical)', text: 'A report for ' + (j.payload || {}).agent_name + ' failed: ' + (j.error || 'unknown error') }))));
  }

  if (!reports.data.length) { root.append(emptyState('No reports yet', canWrite() ? 'Choose an agent and press Generate.' : 'Your supervisor can generate a coaching report for you.')); }
  for (const [index, report] of reports.data.entries()) {
    const stats = report.trends || {};
    const advice = report.recommendations || {};
    const list = (title, items) => (items && items.length ? h('div', { style: 'margin-top:10px' }, h('b', { text: title }), h('ul', { style: 'margin:4px 0 0;padding-left:18px' }, items.map((i) => h('li', { text: i })))) : null);
    root.append(h('details', { class: 'card fade', style: 'margin-bottom:12px', open: index === 0 },
      h('summary', {}, h('b', { text: report.agent_name }), ' ', h('span', { class: 'muted', text: report.period + ' - ' + fmtDateTime(report.generated_at) })),
      h('div', { style: 'display:flex;gap:18px;flex-wrap:wrap;margin:12px 0' },
        [['Audits', stats.audits], ['Average', stats.average_score], ['Pass rate', stats.pass_rate === undefined ? '-' : stats.pass_rate + '%'], ['Critical fails', stats.critical_fails],
          ['Trend', (stats.trend || {}).direction || '-']].map(([label, value]) => h('div', {}, h('div', { class: 'muted small', text: label }), h('b', { text: String(value ?? '-') })))),
      advice.summary ? h('p', { style: 'margin:6px 0', text: advice.summary }) : null,
      list('Doing well', advice.strengths), list('To improve', advice.improvements), list('Next steps', advice.actions),
      (stats.checks || []).length ? h('div', { class: 'table-wrap', style: 'margin-top:12px' }, h('table', {}, h('thead', {}, h('tr', {}, h('th', { text: 'Check' }), h('th', { text: 'Passed' }), h('th', { text: 'Failed' }))),
        h('tbody', {}, stats.checks.map((c) => h('tr', {}, h('td', { text: c.label }), h('td', { text: c.pass_rate === null ? '-' : c.pass_rate + '%' }), h('td', { text: c.failed + ' of ' + c.audited })))))) : null));
  }
  if (running.length) setTimeout(() => { if (state.view === 'reports') renderReports(); }, 6000);
}

// ---- learning: where reviewers corrected the AI
async function renderLearning() {
  const root = $('#view-learning');
  root.replaceChildren(h('div', { class: 'card' }, h('div', { class: 'sk' }), h('div', { class: 'sk', style: 'width:60%;margin-top:10px' })));
  const [feedback, jobs] = await Promise.all([
    db.from('rule_feedback').select('check_key, changed, ai_passed, human_passed, ai_reason, human_reason, source, created_at, created_by_email').order('created_at', { ascending: false }).limit(1000),
    db.from('jobs').select('*').eq('kind', 'research'),
  ]);
  if (state.view !== 'learning') return;
  root.replaceChildren();
  if (feedback.error) { root.append(emptyState('Not available yet', friendly(feedback.error))); return; }

  const checks = ((activeRubric() || {}).parameters || {}).checks || [];
  const labels = new Map(checks.map((c) => [c.key, c.label || nice(c.key)]));
  const stats = new Map();
  for (const f of feedback.data) { const e = stats.get(f.check_key) || { reviewed: 0, corrected: 0 }; e.reviewed += 1; if (f.changed) e.corrected += 1; stats.set(f.check_key, e); }
  const bars = h('div');
  hbars(bars, [...stats.entries()].map(([key, e]) => ({ name: labels.get(key) || nice(key), value: pct(e.reviewed - e.corrected, e.reviewed), text: pct(e.reviewed - e.corrected, e.reviewed) + '%',
    detail: e.corrected + ' corrected of ' + e.reviewed + ' reviewed' })).sort((a, b) => a.value - b.value), 'Nothing has been reviewed yet. Open an audit and use Review & edit score.');

  const jobList = (jobs.data || []).slice().sort((a, b) => String(b.created_at || b.finished_at || '').localeCompare(String(a.created_at || a.finished_at || '')));
  const last = jobList[0];
  const lastLine = last ? (last.status === 'done' ? 'The last analysis finished. New proposals are under Rubric.' : last.status === 'failed' ? 'The last analysis failed: ' + (last.error || 'unknown error') : 'An analysis is running...') : 'No analysis has been run yet.';

  root.append(h('div', { class: 'grid cols' },
    h('div', { class: 'card span-6 fade' }, h('div', { class: 'card-head' }, h('h2', { text: 'How often the AI was right' }), h('span', { class: 'muted small', text: 'per check, from reviewer decisions' })), bars),
    h('div', { class: 'card span-6 fade' }, h('div', { class: 'card-head' }, h('h2', { text: 'How the AI learns' })),
      h('ol', { style: 'margin:0;padding-left:18px' },
        h('li', { text: 'Every Review & edit score, and every contest you answer, is saved as a labelled example.' }),
        h('li', { text: 'The audit shows the AI a few of the latest corrections for each check, so it follows the reasoning of the reviewers.' }),
        h('li', { text: 'The research agent reads the corrections (and your policy documents) and proposes clearer rules. An admin approves or rejects every proposal.' })),
      isAdmin() ? h('div', { style: 'margin-top:14px' },
        h('button', { class: 'btn primary', type: 'button', onclick: async (event) => {
          event.target.disabled = true;
          if (await queueJob('research', {})) { toast('Analysis requested. The proposals appear under Rubric in a few minutes.', 'ok'); renderLearning(); }
          event.target.disabled = false;
        } }, icon('spark', 16), 'Analyse corrections and propose rule changes'),
        h('div', { class: 'muted small', style: 'margin-top:8px', text: lastLine })) : h('p', { class: 'muted small', style: 'margin-top:12px', text: 'An admin can run the analysis.' }))));

  const changes = feedback.data.filter((f) => f.changed).slice(0, 10);
  root.append(h('div', { class: 'card fade', style: 'margin-top:16px' }, h('div', { class: 'card-head' }, h('h2', { text: 'Recent corrections' })),
    changes.length ? h('div', { class: 'table-wrap' }, h('table', {}, h('thead', {}, h('tr', {}, h('th', { text: 'When' }), h('th', { text: 'Check' }), h('th', { text: 'The AI said' }), h('th', { text: 'The reviewer said' }))),
      h('tbody', {}, changes.map((f) => h('tr', {}, h('td', { class: 'muted', text: ago(f.created_at) }), h('td', { text: labels.get(f.check_key) || nice(f.check_key) }),
        h('td', {}, badge(f.ai_passed ? 'pass' : 'fail'), h('div', { class: 'muted small', style: 'max-width:260px', text: f.ai_reason || '' })),
        h('td', {}, badge(f.human_passed ? 'pass' : 'fail'), h('div', { class: 'muted small', style: 'max-width:260px', text: (f.created_by_email || '') + (f.human_reason ? ': ' + f.human_reason : '') }))))))) :
      h('p', { class: 'muted', text: 'No corrections yet.' })));
}

// ---- assistant chat
async function renderAssistant() {
  const root = $('#view-assistant');
  const { data, error } = await db.from('chat_messages').select('*').order('created_at').limit(60);
  if (state.view !== 'assistant') return;
  root.replaceChildren();
  if (error) { root.append(emptyState('Not available yet', friendly(error))); return; }
  const waiting = data.length && data[data.length - 1].role === 'user' && data[data.length - 1].status === 'pending';

  const log = h('div', { class: 'chat', 'aria-live': 'polite' });
  if (!data.length) log.append(h('div', { class: 'muted', style: 'text-align:center;padding:24px' }, 'Ask about your results, for example: "How is Anna doing?", "Which check fails the most?" or "Were there any critical fails recently?"'));
  for (const message of data) {
    log.append(h('div', { class: 'bubble ' + message.role + (message.status === 'error' ? ' err' : '') }, h('div', { text: message.content }),
      h('div', { class: 'muted small', text: message.role === 'user' ? 'You - ' + ago(message.created_at) : 'Assistant - ' + ago(message.created_at) })));
  }
  if (waiting) log.append(h('div', { class: 'bubble assistant' }, h('div', {}, icon('redo', 14), ' Looking at your data... this takes about a minute.')));

  const input = h('textarea', { class: 'textarea', style: 'min-height:70px;font-family:inherit', maxlength: '1000', placeholder: 'Ask a question about your audits...', disabled: !!waiting });
  const send = async () => {
    const text = input.value.trim();
    if (!text || waiting) return;
    input.disabled = true;
    const { data: saved, error: saveError } = await db.from('chat_messages').insert({ role: 'user', content: text, status: 'pending' }).select('id').single();
    if (saveError) { toast('Could not send: ' + friendly(saveError), 'error'); input.disabled = false; return; }
    if (!(await queueJob('chat', { message_id: saved.id }))) { await db.from('chat_messages').update({ status: 'error' }).eq('id', saved.id); }
    renderAssistant();
  };
  input.addEventListener('keydown', (event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); send(); } });
  root.append(h('div', { class: 'card fade', style: 'max-width:860px' }, log,
    h('div', { style: 'display:flex;gap:10px;align-items:flex-end;margin-top:12px' }, input,
      h('button', { class: 'btn primary', type: 'button', disabled: !!waiting, onclick: send }, icon('chat', 16), 'Send')),
    h('div', { style: 'display:flex;justify-content:space-between;margin-top:10px;gap:10px;flex-wrap:wrap' },
      h('span', { class: 'muted small', text: 'Answers use only your last 30 days of audits. The assistant cannot see other organizations or change anything.' }),
      data.length ? h('button', { class: 'btn sm ghost', type: 'button', onclick: async () => {
        if (!(await confirmDialog('Clear this conversation?', 'Your messages and the answers are deleted.', 'Clear', true))) return;
        await db.from('chat_messages').delete().eq('user_id', state.me.id);
        renderAssistant();
      } }, icon('trash', 15), 'Clear') : null)));
  log.scrollTop = log.scrollHeight;
  if (waiting) setTimeout(() => { if (state.view === 'assistant') renderAssistant(); }, 4000);
}

// ---- knowledge base (admin): policy documents the research agent reads
async function renderKnowledge() {
  const root = $('#view-knowledge');
  const { data, error } = await db.from('knowledge_base_docs').select('id, title, content, uploaded_at').order('uploaded_at', { ascending: false });
  if (state.view !== 'knowledge') return;
  root.replaceChildren();
  if (error) { root.append(emptyState('Not available yet', friendly(error))); return; }

  const fileInput = h('input', { type: 'file', multiple: true, accept: '.txt,.md,text/plain,text/markdown', hidden: true });
  const upload = async (files) => {
    let saved = 0;
    for (const file of files) {
      if (file.size > 200000) { toast(file.name + ' is larger than 200 KB; split it into smaller documents.', 'error'); continue; }
      const { error: insertError } = await db.from('knowledge_base_docs').insert({ title: file.name.replace(/\.[^.]+$/, ''), content: maskPii(await file.text()) });
      if (insertError) { toast('Could not save ' + file.name + ': ' + friendly(insertError), 'error'); continue; }
      saved += 1;
    }
    if (saved) { toast(saved + ' document' + (saved === 1 ? '' : 's') + ' saved.', 'ok'); logActivity('knowledge.uploaded', { count: saved }); }
    renderKnowledge();
  };
  const drop = h('div', { class: 'drop', tabindex: '0', role: 'button', 'aria-label': 'Choose policy documents' }, icon('upload', 28),
    h('div', { style: 'margin-top:6px', text: 'Drop policy documents (.txt or .md) here, or click to browse' }),
    h('div', { class: 'muted small', text: 'Card numbers, emails and phone numbers are masked before saving. Up to 200 KB each.' }));
  drop.addEventListener('click', () => fileInput.click());
  drop.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); fileInput.click(); } });
  drop.addEventListener('dragover', (event) => { event.preventDefault(); drop.classList.add('over'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('over'));
  drop.addEventListener('drop', (event) => { event.preventDefault(); drop.classList.remove('over'); upload([...event.dataTransfer.files]); });
  fileInput.addEventListener('change', () => upload([...fileInput.files]));

  root.append(h('div', { class: 'card fade', style: 'max-width:820px;margin-bottom:16px' }, drop, fileInput));
  root.append(h('div', { class: 'card fade' }, h('div', { class: 'card-head' }, h('h2', { text: 'Documents' }), h('span', { class: 'muted small', text: data.length + ' saved' })),
    data.length ? h('div', { class: 'table-wrap' }, h('table', {}, h('thead', {}, h('tr', {}, h('th', { text: 'Title' }), h('th', { text: 'Size' }), h('th', { text: 'Added' }), h('th'))),
      h('tbody', {}, data.map((doc) => h('tr', {}, h('td', { text: doc.title }), h('td', { class: 'muted', text: Math.round((doc.content || '').length / 100) / 10 + ' KB' }), h('td', { class: 'muted', text: ago(doc.uploaded_at) }),
        h('td', { class: 'actions' }, h('button', { class: 'icon-btn danger', type: 'button', title: 'Delete', 'aria-label': 'Delete ' + doc.title, onclick: async () => {
          if (!(await confirmDialog('Delete "' + doc.title + '"?', 'The research agent will no longer read it.', 'Delete', true))) return;
          const { error: removeError } = await db.from('knowledge_base_docs').delete().eq('id', doc.id);
          if (removeError) toast('Could not delete: ' + friendly(removeError), 'error'); else { logActivity('knowledge.deleted', { title: doc.title }); renderKnowledge(); }
        } }, icon('trash')))))))) : h('p', { class: 'muted', text: 'No documents yet. Add your recording-disclosure, identity-verification or refund policies, and the research agent will use them.' })));
}

// ---- rubric proposals (admin): the research agent proposes, a person decides
async function renderProposals(root) {
  const { data, error } = await db.from('rubric_change_requests').select('*').order('created_at', { ascending: false }).limit(20);
  if (error) { if (!isMissing(error)) root.append(h('div', { class: 'alert', text: 'Could not load proposals: ' + error.message })); return; }
  const pending = data.filter((r) => r.status === 'pending');
  const resolved = data.filter((r) => r.status !== 'pending').slice(0, 5);
  const card = h('div', { class: 'card fade', style: 'margin-top:16px' },
    h('div', { class: 'card-head' }, h('h2', { text: 'Proposed changes' }), h('span', { class: 'muted small', text: 'Written by the research agent. Nothing changes until you approve it.' })));
  if (!pending.length) card.append(h('p', { class: 'muted', text: 'No proposals waiting. Run the analysis from the Learning page after reviewers have corrected some audits.' }));
  for (const request of pending) {
    const diff = request.diff || {};
    const rules = (title, items, tone) => h('div', { style: 'flex:1;min-width:240px' }, h('div', { class: 'muted small', text: title }),
      h('ol', { style: 'margin:4px 0 0;padding-left:18px;' + (tone ? 'border-left:3px solid ' + tone + ';padding-left:22px' : '') }, (items || []).map((r) => h('li', { style: 'margin-bottom:4px', text: r }))));
    card.append(h('div', { style: 'border-top:1px solid var(--line);padding-top:14px;margin-top:14px' },
      h('div', {}, h('b', { text: diff.check_label || nice(diff.check_key) }), ' ', h('span', { class: 'tag', text: (diff.corrections_used || 0) + ' corrections used' }),
        diff.rubric_version !== undefined ? h('span', { class: 'tag', style: 'margin-left:6px', text: 'based on v' + diff.rubric_version }) : null,
        h('span', { class: 'muted small', style: 'margin-left:8px', text: ago(request.created_at) })),
      h('p', { style: 'margin:8px 0', text: diff.rationale || '' }),
      h('div', { style: 'display:flex;gap:18px;flex-wrap:wrap' }, rules('Current rules', diff.old_rules, ''), rules('Proposed rules', diff.new_rules, 'var(--accent)')),
      h('div', { style: 'display:flex;gap:8px;margin-top:12px' },
        h('button', { class: 'btn primary sm', type: 'button', onclick: () => approveProposal(request) }, icon('check', 15), 'Approve and save as a new version'),
        h('button', { class: 'btn sm danger', type: 'button', onclick: () => rejectProposal(request) }, icon('x', 15), 'Reject'))));
  }
  if (resolved.length) card.append(h('div', { class: 'muted small', style: 'margin-top:16px', text: 'Recently decided: ' + resolved.map((r) => ((r.diff || {}).check_label || '?') + ' (' + r.status + ')').join(', ') }));
  root.append(card);
}

async function approveProposal(request) {
  const diff = request.diff || {};
  const active = activeRubric();
  if (!active) { toast('There is no active rubric.', 'error'); return; }
  const stale = diff.rubric_version !== undefined && diff.rubric_version !== active.version;
  if (!(await confirmDialog('Approve this change?', (stale ? 'The rubric has changed since this was proposed (it was based on v' + diff.rubric_version + ', the active one is v' + active.version + '). ' : '')
    + 'The rules of "' + (diff.check_label || diff.check_key) + '" are replaced and the result is saved as a new version. Old audits keep their version.', 'Approve'))) return;
  const parameters = JSON.parse(JSON.stringify(active.parameters || {}));
  const check = (parameters.checks || []).find((c) => c.key === diff.check_key);
  if (!check) { toast('That check no longer exists in the active rubric.', 'error'); return; }
  check.rules = diff.new_rules;
  if (!(await saveRubric(parameters, 'Proposal for ' + (diff.check_label || diff.check_key)))) return;
  const { error } = await db.from('rubric_change_requests').update({ status: 'approved', resolved_by_email: staffEmail(), resolved_at: new Date().toISOString() }).eq('id', request.id);
  if (error) toast('The rubric was saved, but the proposal could not be marked approved: ' + friendly(error), 'error');
  logActivity('proposal.approved', { check: diff.check_key });
  renderRubric();
}

async function rejectProposal(request) {
  const note = h('textarea', { class: 'textarea', style: 'min-height:80px;font-family:inherit', maxlength: '500', placeholder: 'Why not? (helps you remember)' });
  if (!(await formDialog('Reject this proposal', 'The rubric stays as it is.', [h('div', { class: 'field' }, h('label', { text: 'Reason' }), note)], 'Reject', () => ''))) return;
  const { error } = await db.from('rubric_change_requests').update({ status: 'rejected', note: note.value.trim() || null, resolved_by_email: staffEmail(), resolved_at: new Date().toISOString() }).eq('id', request.id);
  if (error) { toast('Could not reject: ' + friendly(error), 'error'); return; }
  logActivity('proposal.rejected', { check: (request.diff || {}).check_key });
  renderRubric();
}
"""
