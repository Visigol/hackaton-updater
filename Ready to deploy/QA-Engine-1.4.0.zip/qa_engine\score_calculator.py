"""Deterministic scoring and regulatory auto-fail. The model proposes verdicts; this class decides the score."""


class ScoreCalculator:
    """Applies the rubric's weights, critical-check auto-fail and pass threshold to per-check verdicts."""

    @staticmethod
    def calculate(rubric: dict, verdicts: dict[str, dict]) -> dict:
        """Computes the final result.

        If any check marked critical fails, the call is an automatic fail with score 0. A critical fail marked
        ``unverified`` (no evidence) does not do that: it adds a NEEDS_REVIEW flag and the call cannot pass. Otherwise the score is the
        weighted sum of passed checks (each worth weight * 100) and the call passes at or above pass_threshold.

        :param rubric: rubric parameters: {"pass_threshold": number, "checks": [{key, label, weight, critical}]}
        :param verdicts: check key -> {"passed": bool, "reason": str}
        :return: {"overall_score": float, "passed": bool, "critical_fail": bool, "flags": [str]}
        """
        flags: list[str] = []
        score: float = 0.0
        critical_fail: bool = False
        needs_review: bool = False
        for check in rubric.get("checks", []):
            verdict: dict = verdicts.get(check.get("key"), {"passed": False, "reason": "check was not run"})
            passed: bool = bool(verdict.get("passed"))
            if passed:
                score += check.get("weight", 0.0) * 100.0
            elif check.get("critical") and verdict.get("unverified"):
                # A critical fail with no evidence (see CriticalGuard) is not trusted to zero the call: it needs a person.
                flags.append(f"NEEDS_REVIEW: {check.get('label')}: critical fail not supported by a quote of the agent: "
                             f"{verdict.get('reason', '')}")
                needs_review = True
            elif check.get("critical"):
                flags.append(f"REGULATORY_AUTO_FAIL: {check.get('label')}: {verdict.get('reason', '')}")
                critical_fail = True

        if critical_fail:
            return {"overall_score": 0.0, "passed": False, "critical_fail": True, "flags": flags}

        overall: float = round(score, 2)
        passed_overall: bool = overall >= rubric.get("pass_threshold", 80) and not needs_review
        return {"overall_score": overall, "passed": passed_overall, "critical_fail": False, "flags": flags}
