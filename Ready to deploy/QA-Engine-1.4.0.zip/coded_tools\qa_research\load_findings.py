"""Coded tool of the qa_research network: gives the advisor agent what it needs to improve one check's rules."""

import logging
from typing import Any

from neuro_san.interfaces.coded_tool import CodedTool

logger = logging.getLogger(__name__)


class LoadFindings(CodedTool):
    """Returns, for one rubric check, its current rules, the human corrections of the AI's verdicts, and policy excerpts.

    The audit worker builds ``sly_data["findings"]`` (``{check_key: {...}}``) from the corrections that reviewers made
    and the knowledge-base documents, so the model never has to remember or copy them.

    Demo mode: without ``findings`` (for example from the Neuro SAN Studio chat) a built-in sample is used. Anything
    produced that way carries ``sly_data["demo"] = True`` and the worker refuses it.
    """

    DEMO_FINDINGS: dict[str, dict[str, Any]] = {
        "compliance": {
            "label": "Compliance & Authentication",
            "rules": [
                "The agent states that the call is recorded.",
                "Before discussing account details, the agent verifies the caller's identity.",
            ],
            "corrections": [
                {"ai_passed": True, "human_passed": False,
                 "ai_reason": "The agent asked for a phone number, which counts as verification.",
                 "human_reason": "A phone number is not verification, and the charges were stated first.",
                 "excerpt": "Agent: I can see the charges you mean... Agent: Could you give me the phone number on the account?"},
                {"ai_passed": True, "human_passed": False,
                 "ai_reason": "The agent verified the caller.",
                 "human_reason": "Verification came after the balance had been read out.",
                 "excerpt": "Agent: Your balance is 212 dollars. ... Agent: For security, what is your date of birth?"},
            ],
            "policy_snippets": [
                {"title": "Identity policy (demo)", "text": "Staff must verify the caller with a PIN, a security answer, or date of birth "
                                                            "plus postcode BEFORE disclosing any account information."}],
        }
    }

    async def async_invoke(self, args: dict[str, Any], sly_data: dict[str, Any]) -> str:
        """Writes the findings of one check as text.

        :param args: ``{"check_key": "<key>"}``
        :param sly_data: the request's bulletin board; holds ``findings`` when the audit worker made the request
        :return: the findings, or a message listing the valid keys when the key is unknown
        """
        if not sly_data.get("findings"):
            logger.warning("load_findings: no findings in sly_data, so the DEMO sample is being used")
            sly_data["findings"] = {key: dict(value) for key, value in self.DEMO_FINDINGS.items()}
            sly_data["demo"] = True

        check_key: str = str(args.get("check_key") or "").strip()
        findings: dict[str, Any] = sly_data["findings"]
        finding: dict[str, Any] | None = findings.get(check_key)
        if not finding:
            return f"There is no check called '{check_key}'. Valid check keys: {', '.join(sorted(findings))}."

        lines: list[str] = [("DEMO DATA, not real. " if sly_data.get("demo") else "") + f"Check: {finding.get('label')} (key {check_key}).",
                            "CURRENT RULES:"]
        lines += [f"{number}. {rule}" for number, rule in enumerate(finding.get("rules") or [], 1)]
        corrections: list[dict[str, Any]] = finding.get("corrections") or []
        if corrections:
            lines.append("CORRECTIONS BY HUMAN REVIEWERS (the AI got these wrong):")
            for number, item in enumerate(corrections, 1):
                lines.append(f"Correction {number}: the AI said {'PASS' if item.get('ai_passed') else 'FAIL'} ({item.get('ai_reason') or 'no reason'}); "
                             f"the reviewer said {'PASS' if item.get('human_passed') else 'FAIL'} ({item.get('human_reason') or 'no reason'}). "
                             f"Excerpt: {item.get('excerpt') or '(none)'}")
        snippets: list[dict[str, Any]] = finding.get("policy_snippets") or []
        if snippets:
            lines.append("POLICY EXCERPTS:")
            lines += [f"- {snippet.get('title')}: {snippet.get('text')}" for snippet in snippets]
        logger.info("load_findings: delivered the findings for %s", check_key)
        return "\n".join(lines)
