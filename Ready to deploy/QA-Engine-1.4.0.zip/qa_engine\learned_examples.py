"""Memory for the audit: reviewer-corrected calls, shown to the auditors as examples of how a human judged them."""

import logging

import psycopg

from preprocessor import DeterministicSanitizer
from qa_engine.tenant_database import TenantDatabase

logger = logging.getLogger(__name__)


class LearnedExamples:
    """Loads and formats the corrections that reviewers made, per rubric check.

    Only the calling tenant's own corrections are ever read (the database session is pinned to the tenant), and the
    transcripts were masked when they were stored. No model is trained: the examples are simply put in front of the
    auditor, so the effect disappears the moment the setting is turned off (AUDIT_EXAMPLES_PER_CHECK=0).
    """

    EXCERPT_LENGTH: int = 500
    CANDIDATES_PER_SLOT: int = 4

    @staticmethod
    def load(database: TenantDatabase, tenant_id: str, rubric: dict, exclude_transcript_id: str, per_check: int) -> dict[str, list[dict]]:
        """The most recent corrections for each check.

        :param database: tenant-scoped database access
        :param rubric: the rubric parameters (used for each check's key and which part of the call it reads)
        :param exclude_transcript_id: the call being audited, which must never be its own example
        :param per_check: how many examples per check (0 turns the feature off)
        :return: ``{check_key: [{"excerpt", "human_passed", "human_reason"}]}``; empty if the table is not there yet
        """
        checks: list[dict] = rubric.get("checks", [])
        if per_check <= 0 or not checks:
            return {}
        try:
            with database.session(tenant_id) as connection:
                rows: list[dict] = connection.execute(
                    """select f.check_key, f.human_passed, f.human_reason, t.raw_text
                       from public.rule_feedback f join public.transcripts t on t.id = f.transcript_id
                       where f.changed and f.transcript_id <> %s
                       order by f.created_at desc limit %s""",
                    (exclude_transcript_id, per_check * len(checks) * LearnedExamples.CANDIDATES_PER_SLOT)).fetchall()
        except (psycopg.errors.UndefinedTable, psycopg.errors.UndefinedColumn, psycopg.errors.InsufficientPrivilege):
            logger.warning("rule_feedback is not available yet; auditing without learned examples")
            return {}
        return LearnedExamples.group(rows, checks, per_check)

    @staticmethod
    def group(rows: list[dict], checks: list[dict], per_check: int) -> dict[str, list[dict]]:
        """Keeps the first ``per_check`` rows of each check, with the excerpt that check reads."""
        sources: dict[str, str] = {check.get("key"): check.get("source") or "full_clean" for check in checks}
        grouped: dict[str, list[dict]] = {}
        for row in rows:
            key: str = row.get("check_key")
            if key not in sources or len(grouped.setdefault(key, [])) >= per_check:
                continue
            slices: dict[str, str] = DeterministicSanitizer.slice_transcript(DeterministicSanitizer.mask_pii(row.get("raw_text") or ""))
            excerpt: str = slices.get(sources[key], slices["full_clean"])  # "summary" is model-made, so it falls back to the call
            grouped[key].append({"excerpt": excerpt[:LearnedExamples.EXCERPT_LENGTH],
                                 "human_passed": bool(row.get("human_passed")), "human_reason": (row.get("human_reason") or "")[:300]})
        return {key: value for key, value in grouped.items() if value}

    @staticmethod
    def format(examples: list[dict] | None) -> str:
        """The block added to a check's task; empty when there are no examples."""
        if not examples:
            return ""
        lines: list[str] = ["HOW A HUMAN REVIEWER JUDGED SIMILAR CALLS (apply the same reasoning):"]
        for number, example in enumerate(examples, 1):
            reason: str = f" because: {example['human_reason']}" if example.get("human_reason") else ""
            lines.append(f'Example {number}. Excerpt: "{example["excerpt"]}" Reviewer verdict: '
                         f'{"PASS" if example["human_passed"] else "FAIL"}{reason}')
        return "\n".join(lines) + "\n"
