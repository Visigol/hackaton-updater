"""Dashboard JavaScript, part 2: new audit, rubric editor, user management, data export, settings and startup.

Continues the function scope opened in dashboard_js_core.py and closes it.
"""

JS_ADMIN = r"""
// ---- new audit
let pendingFiles = [];
const CHANNELS = ['voice', 'chat', 'email'];

async function queueTranscript(job) {
  if (job.text.length > 200000) throw new Error('Transcript is longer than 200,000 characters.');
  const { data: saved, error } = await db.from('transcripts').insert({
    agent_name: job.agent, channel: job.channel, raw_text: maskPii(job.text),
  }).select('id, tenant_id').single();
  if (error) throw new Error(error.message);
  const { error: jobError } = await db.from('jobs').insert({ tenant_id: saved.tenant_id, kind: 'audit', payload: { transcript_id: saved.id } });
  if (jobError) throw new Error('Saved, but it could not be queued: ' + jobError.message);
  logActivity('transcript.uploaded', { transcript_id: saved.id, agent: job.agent, channel: job.channel });
}

function renderNew() {
  const root = $('#view-new');
  root.replaceChildren();
  if (!canWrite()) { root.append(emptyState('Not available', 'Your role cannot upload transcripts.')); return; }
  pendingFiles = [];
  const agent = h('input', { class: 'input', id: 'n-agent', maxlength: '120', placeholder: 'e.g. AGT-0042' });
  const channel = h('select', { class: 'select', id: 'n-channel' }, CHANNELS.map((c) => h('option', { value: c, text: nice(c) })));
  const text = h('textarea', { class: 'textarea', id: 'n-text', placeholder: 'Paste the call or chat transcript here...' });
  const fileList = h('div', { class: 'muted small', style: 'margin-top:10px' });
  const results = h('div', { class: 'rows', style: 'margin-top:16px' });
  const fileInput = h('input', { type: 'file', multiple: true, accept: '.txt,.json,text/plain,application/json', hidden: true });

  const addFiles = async (files) => {
    for (const file of files) pendingFiles.push({ name: file.name, text: await file.text() });
    fileList.textContent = pendingFiles.length ? pendingFiles.length + ' file(s) ready: ' + pendingFiles.map((f) => f.name).join(', ') : '';
  };
  const drop = h('div', { class: 'drop', tabindex: '0', role: 'button', 'aria-label': 'Choose transcript files' }, icon('upload', 28),
    h('div', { style: 'margin-top:6px', text: 'Drop .txt or .json files here, or click to browse' }),
    h('div', { class: 'muted small', text: 'JSON files may hold {"agent_id", "raw_transcript"}, as one record or a list, like the folder watcher uses.' }));
  drop.addEventListener('click', () => fileInput.click());
  drop.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); fileInput.click(); } });
  drop.addEventListener('dragover', (event) => { event.preventDefault(); drop.classList.add('over'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('over'));
  drop.addEventListener('drop', (event) => { event.preventDefault(); drop.classList.remove('over'); addFiles(event.dataTransfer.files); });
  fileInput.addEventListener('change', () => addFiles(fileInput.files));

  const addResult = (label, ok, message) => results.append(h('div', { class: 'badge', style: 'justify-content:flex-start' },
    icon(ok ? 'check' : 'alert', 14), label + ': ' + message));
  const submit = async (event) => {
    const button = event.target;
    button.disabled = true;
    results.replaceChildren();
    const jobs = [];
    for (const file of pendingFiles) {
      const fallbackAgent = agent.value.trim() || file.name.replace(/\.[^.]+$/, '');
      if (/\.json$/i.test(file.name)) {
        let parsed;
        try { parsed = JSON.parse(file.text); } catch (error) { addResult(file.name, false, 'not valid JSON'); continue; }
        for (const record of Array.isArray(parsed) ? parsed : [parsed]) {
          const body = record && (record.raw_transcript ?? record.raw_text ?? record.transcript);
          if (typeof body !== 'string' || !body.trim()) { addResult(file.name, false, 'no raw_transcript field'); continue; }
          jobs.push({ label: file.name, agent: String(record.agent_id || record.agent_name || fallbackAgent), channel: CHANNELS.includes(record.channel) ? record.channel : channel.value, text: body });
        }
      } else {
        jobs.push({ label: file.name, agent: fallbackAgent, channel: channel.value, text: file.text });
      }
    }
    if (text.value.trim()) {
      if (!agent.value.trim()) { toast('Enter an agent name for the pasted transcript.', 'error'); button.disabled = false; return; }
      jobs.push({ label: 'Pasted text', agent: agent.value.trim(), channel: channel.value, text: text.value });
    }
    if (!jobs.length) { if (!results.children.length) toast('Add a file or paste a transcript first.', 'error'); button.disabled = false; return; }
    let done = 0;
    for (const job of jobs) {
      try { await queueTranscript(job); done += 1; addResult(job.label, true, 'saved and queued for ' + job.agent); } catch (error) { addResult(job.label, false, error.message); }
    }
    button.disabled = false;
    if (done) {
      toast(done + ' transcript' + (done === 1 ? '' : 's') + ' queued for audit.', 'ok');
      text.value = ''; pendingFiles = []; fileList.textContent = ''; fileInput.value = '';
      await refresh(true);
    }
  };

  root.append(h('div', { class: 'card fade', style: 'max-width:820px' },
    h('div', { class: 'form-row' },
      h('div', { class: 'field' }, h('label', { for: 'n-agent', text: 'Agent name or ID' }), agent),
      h('div', { class: 'field' }, h('label', { for: 'n-channel', text: 'Channel' }), channel)),
    drop, fileInput, fileList,
    h('div', { class: 'field', style: 'margin-top:16px' }, h('label', { for: 'n-text', text: 'Or paste a transcript' }), text),
    h('div', { class: 'muted small', text: 'Card numbers, SSNs, emails and phone numbers are masked in your browser before anything is saved.' }),
    h('div', { style: 'margin-top:16px' }, h('button', { class: 'btn primary', type: 'button', onclick: submit }, icon('upload', 16), 'Save & queue audit')),
    results));
}

// ---- rubric editor (admin)
let draft = null;
const SOURCES = [['opening', 'Opening of the call'], ['closing', 'Closing of the call'], ['summary', 'AI summary'], ['full_clean', 'Whole transcript']];

function rubricProblem() {
  const mark = Number(draft.pass_threshold);
  if (!(mark >= 0 && mark <= 100)) return 'The pass mark must be between 0 and 100.';
  if (!draft.checks.length) return 'Add at least one check.';
  const keys = new Set();
  let total = 0;
  for (const check of draft.checks) {
    if (!/^[a-z][a-z0-9_]*$/.test(check.key || '')) return 'Check key "' + (check.key || '') + '" must be lowercase letters, digits or underscores, starting with a letter.';
    if (keys.has(check.key)) return 'Two checks share the key "' + check.key + '".';
    keys.add(check.key);
    if (!(check.label || '').trim()) return 'Every check needs a label.';
    if (!Array.isArray(check.rules) || !check.rules.length) return 'Check "' + check.label + '" needs at least one rule.';
    total += Number(check.weight) || 0;
  }
  if (Math.abs(total - 1) > 0.005) return 'Weights must add up to 100% (currently ' + Math.round(total * 1000) / 10 + '%).';
  return null;
}

async function saveRubric(parameters, label) {
  const { data, error } = await db.rpc('save_rubric', { p_parameters: parameters });
  if (error) {
    toast(error.code === 'PGRST202' ? PERM_HELP : 'Could not save the rubric: ' + error.message, 'error');
    return false;
  }
  toast(label + ' saved as version ' + data + ' and is now active.', 'ok');
  await refresh();
  return true;
}

function renderRubric() {
  const root = $('#view-rubric');
  root.replaceChildren();
  const active = activeRubric();
  if (!active) { root.append(emptyState('No active rubric', 'This organization has no rubric yet. Ask the platform owner to seed one.')); return; }
  draft = JSON.parse(JSON.stringify(active.parameters || {}));
  draft.checks = draft.checks || [];
  if (draft.pass_threshold === undefined) draft.pass_threshold = 80;

  const checksBox = h('div');
  const totalBox = h('span', { class: 'badge' });
  const problemBox = h('div', { class: 'small', style: 'color:var(--critical);min-height:1.4em;margin-top:8px' });
  const refreshTotals = () => {
    const total = draft.checks.reduce((sum, c) => sum + (Number(c.weight) || 0), 0);
    const ok = Math.abs(total - 1) <= 0.005;
    totalBox.replaceChildren(icon(ok ? 'check' : 'alert', 14), 'Weights total ' + Math.round(total * 1000) / 10 + '%');
    totalBox.style.setProperty('--c', ok ? 'var(--good)' : 'var(--serious)');
  };
  const drawChecks = () => {
    checksBox.replaceChildren();
    draft.checks.forEach((check, index) => {
      const move = (delta) => { const to = index + delta; if (to < 0 || to >= draft.checks.length) return; [draft.checks[index], draft.checks[to]] = [draft.checks[to], draft.checks[index]]; drawChecks(); };
      checksBox.append(h('div', { class: 'card', style: 'margin-bottom:12px;background:var(--surface2)' },
        h('div', { class: 'form-row' },
          h('div', { class: 'field' }, h('label', { text: 'Key (never shown to agents)' }), h('input', { class: 'input mono', value: check.key || '', oninput: (e) => { check.key = e.target.value.trim(); } })),
          h('div', { class: 'field' }, h('label', { text: 'Label' }), h('input', { class: 'input', value: check.label || '', oninput: (e) => { check.label = e.target.value; } })),
          h('div', { class: 'field' }, h('label', { text: 'Weight (%)' }), h('input', { class: 'input', type: 'number', min: '0', max: '100', step: '1', value: String(Math.round((Number(check.weight) || 0) * 1000) / 10), oninput: (e) => { check.weight = (Number(e.target.value) || 0) / 100; refreshTotals(); } })),
          h('div', { class: 'field' }, h('label', { text: 'Reads' }), h('select', { class: 'select', onchange: (e) => { check.source = e.target.value; } },
            SOURCES.map(([value, label]) => h('option', { value, text: label, selected: (check.source || 'full_clean') === value }))))),
        h('div', { class: 'field' }, h('label', { text: 'Rules (one per line; the call fails the check if ANY is broken)' }),
          h('textarea', { class: 'textarea', style: 'min-height:96px;font-family:inherit', oninput: (e) => { check.rules = e.target.value.split('\n').map((l) => l.trim()).filter(Boolean); } }, (check.rules || []).join('\n'))),
        h('div', { style: 'display:flex;gap:12px;align-items:center;flex-wrap:wrap' },
          h('label', { style: 'display:flex;gap:8px;align-items:center' }, h('input', { type: 'checkbox', checked: !!check.critical, onchange: (e) => { check.critical = e.target.checked; } }), 'Critical (failing it fails the whole call with score 0)'),
          h('span', { style: 'margin-left:auto;display:flex;gap:4px' },
            h('button', { class: 'icon-btn', type: 'button', title: 'Move up', 'aria-label': 'Move up', onclick: () => move(-1) }, icon('up')),
            h('button', { class: 'icon-btn', type: 'button', title: 'Move down', 'aria-label': 'Move down', onclick: () => move(1) }, icon('down')),
            h('button', { class: 'icon-btn danger', type: 'button', title: 'Remove check', 'aria-label': 'Remove check', onclick: () => { draft.checks.splice(index, 1); drawChecks(); } }, icon('trash'))))));
    });
    refreshTotals();
  };
  drawChecks();

  const history = h('tbody', {}, state.rubrics.map((r) => h('tr', {},
    h('td', {}, h('b', { text: 'v' + r.version })),
    h('td', { class: 'muted', text: r.created_at ? fmtDateTime(r.created_at) : '-' }),
    h('td', { class: 'muted', text: (((r.parameters || {}).checks || []).length) + ' checks, pass mark ' + ((r.parameters || {}).pass_threshold ?? 80) }),
    h('td', {}, r.is_active ? h('span', { class: 'tag', text: 'active' }) : null),
    h('td', { class: 'actions' }, r.is_active ? null : h('button', { class: 'btn sm', type: 'button', onclick: async () => {
      if (await confirmDialog('Restore v' + r.version + '?', 'This creates a new version with the same content and makes it active. Old audits keep their original version.', 'Restore')) await saveRubric(r.parameters, 'Restored v' + r.version);
    }, text: 'Restore' })))));

  root.append(h('div', { class: 'grid cols' },
    h('div', { class: 'card span-8 fade' },
      h('div', { class: 'card-head' }, h('h2', { text: 'Active rubric (v' + active.version + ')' }), totalBox),
      h('div', { class: 'field', style: 'max-width:220px' }, h('label', { text: 'Pass mark (0-100)' }),
        h('input', { class: 'input', type: 'number', min: '0', max: '100', value: String(draft.pass_threshold), oninput: (e) => { draft.pass_threshold = Number(e.target.value); } })),
      checksBox,
      h('div', { style: 'display:flex;gap:10px;flex-wrap:wrap' },
        h('button', { class: 'btn', type: 'button', onclick: () => { draft.checks.push({ key: '', label: '', weight: 0, critical: false, source: 'full_clean', rules: [] }); drawChecks(); } }, icon('plus', 16), 'Add check'),
        h('button', { class: 'btn primary', type: 'button', onclick: async (event) => {
          const problem = rubricProblem();
          problemBox.textContent = problem || '';
          if (problem) return;
          if (!(await confirmDialog('Save as v' + (Math.max(...state.rubrics.map((r) => r.version)) + 1) + '?', 'A new version becomes active for all new audits. Existing audits keep the version they were scored with.', 'Save'))) return;
          event.target.disabled = true;
          await saveRubric(draft, 'Rubric');
          event.target.disabled = false;
        } }, 'Save as new version')),
      problemBox),
    h('div', { class: 'card span-4 fade' }, h('div', { class: 'card-head' }, h('h2', { text: 'Version history' })),
      h('div', { class: 'table-wrap' }, h('table', {}, h('thead', {}, h('tr', {}, h('th', { text: 'Version' }), h('th', { text: 'Created' }), h('th', { text: 'Content' }), h('th'), h('th'))), history)))));
  renderProposals(root); // the research agent's proposals, below the editor
}

// ---- users & roles (admin; uses the server-side admin API)
const ROLE_INFO = {
  admin: 'Everything, including users and the rubric',
  supervisor: 'Upload, review, edit and delete audits',
  team_lead: 'Upload, review, edit and delete audits',
  agent: 'Sees only their own results',
};
function generatePassword() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  const bytes = crypto.getRandomValues(new Uint32Array(14));
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join('');
}
async function copyText(value) {
  try { await navigator.clipboard.writeText(value); toast('Copied.', 'ok'); } catch (error) { toast('Copy failed. Select the text manually.', 'error'); }
}

function passwordDialog(email) {
  return new Promise((resolve) => {
    const input = h('input', { class: 'input mono', value: generatePassword(), 'aria-label': 'New password' });
    const dialog = h('dialog', {}, h('form', { method: 'dialog' }, h('h3', { text: 'Reset password' }), h('p', { text: 'Set a new password for ' + email + '. Share it with them securely; they should change it after signing in.' }),
      input, h('div', { class: 'row', style: 'margin-top:16px' },
        h('button', { class: 'btn', type: 'button', onclick: () => { input.value = generatePassword(); }, text: 'Generate' }),
        h('button', { class: 'btn', value: 'cancel', text: 'Cancel' }),
        h('button', { class: 'btn primary', value: 'ok', text: 'Set password' }))));
    dialog.addEventListener('close', () => { resolve(dialog.returnValue === 'ok' ? input.value : null); dialog.remove(); });
    document.body.append(dialog);
    dialog.showModal();
  });
}

async function renderUsers() {
  const root = $('#view-users');
  root.replaceChildren(h('div', { class: 'card' }, h('div', { class: 'sk' }), h('div', { class: 'sk', style: 'width:60%;margin-top:10px' })));
  const { data: users, error } = await db.from('users').select('*').order('email');
  root.replaceChildren();
  if (error) { root.append(emptyState('Could not load users', error.message)); return; }

  const email = h('input', { class: 'input', id: 'u-email', type: 'email', placeholder: 'name@company.com', autocomplete: 'off' });
  const role = h('select', { class: 'select', id: 'u-role' }, Object.keys(ROLE_INFO).map((r) => h('option', { value: r, text: nice(r) + ' - ' + ROLE_INFO[r], selected: r === 'supervisor' })));
  const agentName = h('input', { class: 'input', id: 'u-agent', placeholder: 'Only if this person is an agent', maxlength: '120' });
  const password = h('input', { class: 'input mono', id: 'u-pass', value: generatePassword() });
  const created = h('div');
  root.append(h('div', { class: 'card fade', style: 'margin-bottom:16px' },
    h('div', { class: 'card-head' }, h('h2', { text: 'Add a user' }), h('span', { class: 'muted small', text: 'They can sign in immediately with the temporary password' })),
    h('div', { class: 'form-row' },
      h('div', { class: 'field' }, h('label', { for: 'u-email', text: 'Email' }), email),
      h('div', { class: 'field' }, h('label', { for: 'u-role', text: 'Role' }), role),
      h('div', { class: 'field' }, h('label', { for: 'u-agent', text: 'Agent name (optional)' }), agentName),
      h('div', { class: 'field' }, h('label', { for: 'u-pass', text: 'Temporary password' }),
        h('div', { style: 'display:flex;gap:6px' }, password, h('button', { class: 'btn', type: 'button', onclick: () => { password.value = generatePassword(); }, text: 'New' })))),
    h('button', { class: 'btn primary', type: 'button', onclick: async (event) => {
      event.target.disabled = true;
      try {
        const result = await api('POST', '/api/admin/users', { email: email.value, password: password.value, role: role.value, agent_name: agentName.value.trim() || null });
        const shared = 'Email: ' + result.email + '\nPassword: ' + password.value;
        created.replaceChildren(h('div', { class: 'callout' }, h('b', { text: 'User created.' }), h('pre', { class: 'mono', style: 'margin:8px 0', text: shared }),
          h('button', { class: 'btn sm', type: 'button', onclick: () => copyText(shared) }, 'Copy credentials'), ' ',
          h('span', { class: 'muted small', text: 'This password is not shown again.' })));
        toast('User created.', 'ok');
        const listing = await db.from('users').select('*').order('email');
        if (!listing.error) { fillTable(listing.data); }
        email.value = ''; agentName.value = ''; password.value = generatePassword();
      } catch (err) { toast(err.message, 'error'); }
      event.target.disabled = false;
    } }, icon('plus', 16), 'Create user'),
    created));

  const tbody = h('tbody');
  const hasAgentName = users.some((u) => 'agent_name' in u);
  const fillTable = (list) => {
    tbody.replaceChildren(...list.map((u) => {
      const self = u.id === state.me.id;
      const select = h('select', { class: 'select', 'aria-label': 'Role for ' + u.email, disabled: self, style: 'max-width:170px' },
        Object.keys(ROLE_INFO).map((r) => h('option', { value: r, text: nice(r), selected: u.role === r })));
      select.addEventListener('change', async () => {
        const previous = u.role;
        try { await api('PATCH', '/api/admin/users/' + u.id, { role: select.value }); u.role = select.value; toast(u.email + ' is now ' + nice(u.role) + '.', 'ok'); }
        catch (err) { select.value = previous; toast(err.message, 'error'); }
      });
      return h('tr', {},
        h('td', {}, h('div', { class: 'who' }, h('span', { class: 'avatar', text: initials(u.email.split('@')[0]) }), h('div', {}, h('div', { text: u.email }), self ? h('span', { class: 'tag', text: 'You' }) : null))),
        h('td', {}, select),
        hasAgentName ? h('td', { class: 'muted', text: u.agent_name || '-' }) : null,
        h('td', { class: 'muted', text: u.created_at ? fmtDate(u.created_at) : '-' }),
        h('td', { class: 'actions' },
          h('button', { class: 'icon-btn', type: 'button', title: 'Reset password', 'aria-label': 'Reset password for ' + u.email, onclick: async () => {
            const value = await passwordDialog(u.email);
            if (!value) return;
            try { await api('POST', '/api/admin/users/' + u.id + '/password', { password: value }); await copyText(value); toast('Password updated and copied.', 'ok'); } catch (err) { toast(err.message, 'error'); }
          } }, icon('key')),
          self ? null : h('button', { class: 'icon-btn danger', type: 'button', title: 'Delete user', 'aria-label': 'Delete ' + u.email, onclick: async () => {
            if (!(await confirmDialog('Delete ' + u.email + '?', 'They lose access immediately and the login is removed. Audits they uploaded are kept.', 'Delete user', true))) return;
            try { await api('DELETE', '/api/admin/users/' + u.id); toast('User deleted.', 'ok'); renderUsers(); } catch (err) { toast(err.message, 'error'); }
          } }, icon('trash'))));
    }));
  };
  fillTable(users);
  root.append(h('div', { class: 'card fade' }, h('div', { class: 'card-head' }, h('h2', { text: 'People in ' + state.tenant.name }), h('span', { class: 'muted small', text: users.length + ' user' + (users.length === 1 ? '' : 's') })),
    h('div', { class: 'table-wrap' }, h('table', {}, h('thead', {}, h('tr', {}, h('th', { text: 'User' }), h('th', { text: 'Role' }), hasAgentName ? h('th', { text: 'Agent name' }) : null, h('th', { text: 'Added' }), h('th'))), tbody)),
    h('div', { class: 'muted small', style: 'margin-top:12px' }, Object.entries(ROLE_INFO).map(([r, d]) => nice(r) + ': ' + d).join('  |  '))));
}

// ---- data export + organization settings
function csvCell(value) {
  let s = value === null || value === undefined ? '' : (typeof value === 'object' ? JSON.stringify(value) : String(value));
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // neutralize spreadsheet formula injection
  return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
function toCsv(columns, rows) {
  return '﻿' + [columns.join(','), ...rows.map((row) => columns.map((c) => csvCell(row[c])).join(','))].join('\r\n');
}
function download(name, mime, content) {
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const link = h('a', { href: url, download: name });
  document.body.append(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
async function fetchAll(makeQuery) {
  const all = [];
  for (let from = 0; ; from += 1000) {
    const { data, error } = await makeQuery().range(from, from + 999);
    if (error) throw error;
    all.push(...data);
    if (data.length < 1000) return all;
  }
}
const stamp = () => new Date().toISOString().slice(0, 10);
const withAudits = () => db.from('transcripts').select('id, agent_name, channel, uploaded_at, raw_text, audit_scores(id, overall_score, passed, critical_fail, rubric_version, scored_at, scores, flags)').order('uploaded_at');

const EXPORTS = [
  { title: 'Audits (CSV)', text: 'One row per transcript with result, score, flags and a pass/fail column for every check.', run: async () => {
    const data = await fetchAll(withAudits);
    const keys = new Set();
    const rows = data.map((t) => {
      const a = (t.audit_scores || []).slice().sort((x, y) => new Date(y.scored_at) - new Date(x.scored_at))[0];
      const row = { transcript_id: t.id, agent: t.agent_name, channel: t.channel, uploaded_at: t.uploaded_at, result: a ? (a.critical_fail ? 'critical' : a.passed ? 'pass' : 'fail') : 'not scored',
        overall_score: a ? a.overall_score : '', rubric_version: a ? a.rubric_version : '', scored_at: a ? a.scored_at : '', flags: a ? (a.flags || []).join(' | ') : '', summary: a && a.scores ? a.scores.summary : '' };
      for (const [k, v] of Object.entries((a && a.scores) || {})) if (k !== 'summary' && !k.startsWith('_') && v && typeof v === 'object') { row['check_' + k] = v.passed ? 'pass' : 'fail'; row['reason_' + k] = v.reason; keys.add(k); }
      return row;
    });
    const columns = ['transcript_id', 'agent', 'channel', 'uploaded_at', 'result', 'overall_score', 'rubric_version', 'scored_at', 'flags', 'summary', ...[...keys].flatMap((k) => ['check_' + k, 'reason_' + k])];
    download('audits-' + stamp() + '.csv', 'text/csv;charset=utf-8', toCsv(columns, rows));
  } },
  { title: 'Transcripts (CSV)', text: 'Every transcript with its (already masked) text.', run: async () => {
    const data = await fetchAll(() => db.from('transcripts').select('id, agent_name, channel, uploaded_at, raw_text').order('uploaded_at'));
    download('transcripts-' + stamp() + '.csv', 'text/csv;charset=utf-8', toCsv(['id', 'agent_name', 'channel', 'uploaded_at', 'raw_text'], data));
  } },
  { title: 'Rubric (JSON)', text: 'All rubric versions with their checks, weights and rules.', run: async () => {
    download('rubric-' + stamp() + '.json', 'application/json', JSON.stringify(state.rubrics, null, 2));
  } },
  { title: 'Users (CSV)', text: 'Everyone in your organization with their role.', admin: true, run: async () => {
    const { data, error } = await db.from('users').select('*').order('email');
    if (error) throw error;
    download('users-' + stamp() + '.csv', 'text/csv;charset=utf-8', toCsv(['id', 'email', 'role', 'agent_name', 'created_at'], data));
  } },
  { title: 'Full backup (JSON)', text: 'Organization, rubrics, users, transcripts and audits in one file.', admin: true, run: async () => {
    const users = await db.from('users').select('*');
    const backup = { exported_at: new Date().toISOString(), organization: state.tenant, rubrics: state.rubrics, users: users.data || [], transcripts: await fetchAll(withAudits) };
    download('backup-' + stamp() + '.json', 'application/json', JSON.stringify(backup, null, 2));
  } },
];

const ACTION_LABELS = {
  'rubric.saved': 'Rubric saved', 'user.created': 'User created', 'user.role_changed': 'Role changed', 'user.password_reset': 'Password reset',
  'user.deleted': 'User deleted', 'audit.deleted': 'Audits deleted', 'audit.requeued': 'Re-audit requested', 'audit.reviewed': 'Score reviewed', 'transcript.edited': 'Transcript edited', 'transcript.uploaded': 'Transcript uploaded',
};
function describeActivity(detail) {
  return Object.entries(detail || {}).map(([k, v]) => nice(k) + ': ' + (Array.isArray(v) ? v.join(', ') : String(v))).join(' | ');
}
async function renderActivity(root) {
  const body = h('tbody');
  const card = h('div', { class: 'card fade', style: 'margin-bottom:16px' }, h('div', { class: 'card-head' }, h('h2', { text: 'Activity log' }), h('span', { class: 'muted small', text: 'Latest 50 actions in your organization. Entries cannot be edited or deleted.' })),
    h('div', { class: 'table-wrap' }, h('table', {}, h('thead', {}, h('tr', {}, h('th', { text: 'When' }), h('th', { text: 'Who' }), h('th', { text: 'Action' }), h('th', { text: 'Detail' }))), body)));
  root.append(card);
  const { data, error } = await db.from('audit_trail').select('actor_email, action, detail, created_at').order('created_at', { ascending: false }).limit(50);
  if (error) { body.append(h('tr', {}, h('td', { colspan: '4', class: 'muted', text: 'Activity log unavailable: ' + (error.code === '42P01' || error.code === 'PGRST205' ? PERM_HELP : error.message) }))); return; }
  if (!data.length) { body.append(h('tr', {}, h('td', { colspan: '4', class: 'muted', text: 'No activity recorded yet.' }))); return; }
  for (const entry of data) {
    body.append(h('tr', {}, h('td', { class: 'muted', title: fmtDateTime(entry.created_at), text: ago(entry.created_at) }), h('td', { text: entry.actor_email || '-' }),
      h('td', {}, h('span', { class: 'tag', text: ACTION_LABELS[entry.action] || entry.action })), h('td', { class: 'muted small', text: describeActivity(entry.detail) })));
  }
}

function renderData() {
  const root = $('#view-data');
  root.replaceChildren();
  if (isAdmin()) {
    const name = h('input', { class: 'input', id: 'org-name', value: state.tenant.name, maxlength: '120' });
    root.append(h('div', { class: 'card fade', style: 'margin-bottom:16px;max-width:620px' }, h('div', { class: 'card-head' }, h('h2', { text: 'Organization' })),
      h('div', { class: 'field' }, h('label', { for: 'org-name', text: 'Display name' }), name),
      h('div', { class: 'muted small', style: 'margin-bottom:12px', text: 'Web address: /t/' + state.tenant.slug + '/dashboard' }),
      h('button', { class: 'btn primary', type: 'button', onclick: async (event) => {
        const value = name.value.trim();
        if (!value) { toast('The name cannot be empty.', 'error'); return; }
        event.target.disabled = true;
        const { data, error } = await db.from('tenants').update({ name: value }).eq('id', state.tenant.id).select('id');
        event.target.disabled = false;
        if (error || !data.length) { toast('Could not rename: ' + (error ? error.message : PERM_HELP), 'error'); return; }
        state.tenant.name = value; $('#tenant-name').textContent = value; toast('Organization renamed.', 'ok');
      }, text: 'Save name' })));
  }
  if (isAdmin()) renderActivity(root);
  root.append(h('div', { class: 'grid', style: 'grid-template-columns:repeat(auto-fit,minmax(260px,1fr));margin-top:16px' }, EXPORTS.filter((e) => !e.admin || isAdmin()).map((item) =>
    h('div', { class: 'card fade' }, h('h2', { text: item.title }), h('p', { class: 'muted small', text: item.text }),
      h('button', { class: 'btn', type: 'button', onclick: async (event) => {
        event.target.disabled = true;
        try { await item.run(); toast(item.title + ' downloaded.', 'ok'); } catch (error) { toast('Export failed: ' + error.message, 'error'); }
        event.target.disabled = false;
      } }, icon('download', 16), 'Download')))));
}

// ---- startup
async function boot() {
  const { data: sessionData } = await db.auth.getSession();
  if (!sessionData.session) { window.location.href = '/'; return; }
  state.session = sessionData.session;
  db.auth.onAuthStateChange((event, session) => { if (!session) window.location.href = '/'; });

  const { data: me, error } = await db.from('users').select('id, email, role, tenants(id, name, slug)').eq('id', state.session.user.id).single();
  if (error || !me || !me.tenants) { showAlert('Your account is not linked to an organization. Contact your admin.'); return; }
  const pathSlug = decodeURIComponent(window.location.pathname.split('/')[2] || '');
  if (me.tenants.slug !== pathSlug) { window.location.href = '/t/' + encodeURIComponent(me.tenants.slug) + '/dashboard'; return; }
  state.me = me; state.tenant = me.tenants;
  $('#tenant-name').textContent = me.tenants.name;
  $('#tenant-role').textContent = nice(me.role) + ' - ' + me.email;

  $('#theme-btn').append(icon('moon'), h('span', { class: 't', text: 'Theme' }));
  $('#theme-btn').addEventListener('click', () => {
    const root = document.documentElement;
    const current = root.getAttribute('data-theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    const next = current === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    try { localStorage.setItem('qa-theme', next); } catch (err) { /* preference is optional */ }
    renderCurrent();
  });
  $('#signout-btn').append(icon('logout'), h('span', { class: 't', text: 'Sign out' }));
  $('#signout-btn').addEventListener('click', async () => { await db.auth.signOut(); window.location.href = '/'; });
  $('#drawer-close').append(icon('x'));
  $('#drawer-close').addEventListener('click', closeDrawer);
  $('#backdrop').addEventListener('click', closeDrawer);
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && state.drawerId) closeDrawer(); });

  renderNav();
  updateReviewBadge(); // pending contests show in the menu as soon as the page opens
  try { await loadData(); } catch (err) { showAlert('Could not load data: ' + err.message); }
  updateReviewBadge(); // again now that the audits are loaded: it also counts the ones the AI flagged
  go(window.location.hash.slice(1) || 'overview');
  // The audit worker finishes jobs asynchronously, so keep the lists fresh: quickly while something is running.
  const tick = async () => {
    if (!document.hidden) await refresh(true);
    setTimeout(tick, state.rows.some((r) => r.inFlight) ? 4000 : 15000);
  };
  setTimeout(tick, 4000);
}
boot();
})();
"""
