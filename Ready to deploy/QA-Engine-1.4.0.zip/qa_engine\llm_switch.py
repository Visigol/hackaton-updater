"""Switches the language model of every QA agent network between Chrome's on-device Gemini Nano and cloud Gemini."""

import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)


class LlmSwitch:
    """Rewrites the ``llm_config`` block that sits between the BEGIN/END LLM_CONFIG markers of the qa_*.hocon files.

    The provider comes from ``AI_PROVIDER`` in .env (``nano`` or ``gemini``). Everything else in a network (agents,
    instructions, tools) is left alone, so a switch is always reversible and idempotent.
    """

    PROVIDERS: tuple[str, ...] = ("nano", "gemini")
    DEFAULT_GEMINI_MODEL: str = "gemini-2.5-flash"
    NETWORK_PATTERN: str = "qa_*.hocon"

    BEGIN: str = "# BEGIN LLM_CONFIG: written by switch_llm.py from AI_PROVIDER in .env; do not edit by hand"
    END: str = "# END LLM_CONFIG"
    BLOCK_PATTERN: re.Pattern[str] = re.compile(r"(# BEGIN LLM_CONFIG[^\n]*\n)(.*?)(\n[ \t]*# END LLM_CONFIG)", re.DOTALL)

    NANO_BLOCK: str = (
        '    # Local Chrome Gemini Nano, reached through the FastAPI bridge (bridge.py)\n'
        '    "llm_config": {\n'
        '        "class": "langchain_openai.chat_models.ChatOpenAI",\n'
        '        "model_name": "gemini-nano",\n'
        '        "openai_api_base": "http://127.0.0.1:8000/v1",\n'
        '        "openai_api_key": "local-nano",\n'
        '        "temperature": 0.0\n'
        '    },')

    GEMINI_BLOCK: str = (
        '    # Cloud Gemini. The key is read from the GOOGLE_API_KEY environment variable (.env), never from this file\n'
        '    "llm_config": {{\n'
        '        "model_name": "{model}",\n'
        '        "temperature": {temperature}\n'
        '    }},')

    @staticmethod
    def default_temperature(model: str) -> float:
        """Gemini 3 models loop at low temperatures (Neuro SAN's guide says 1.0); earlier models stay deterministic."""
        return 1.0 if model.startswith("gemini-3") else 0.0

    @staticmethod
    def block_for(provider: str, model: str = "", temperature: float | None = None) -> str:
        """The text that goes between the markers for ``provider``.

        :raises ValueError: when the provider is not one of PROVIDERS
        """
        if provider == "nano":
            return LlmSwitch.NANO_BLOCK
        if provider == "gemini":
            chosen: str = model or LlmSwitch.DEFAULT_GEMINI_MODEL
            value: float = LlmSwitch.default_temperature(chosen) if temperature is None else temperature
            return LlmSwitch.GEMINI_BLOCK.format(model=chosen, temperature=value)
        raise ValueError(f"AI_PROVIDER must be one of {', '.join(LlmSwitch.PROVIDERS)}, not '{provider}'")

    @staticmethod
    def apply(registries: Path, provider: str, model: str = "", temperature: float | None = None) -> list[str]:
        """Rewrites every qa_*.hocon in ``registries`` that has the markers.

        :return: the names of the files that actually changed
        :raises ValueError: when the provider is unknown
        :raises FileNotFoundError: when the folder has no qa_*.hocon file with markers (a wrong folder, or old files)
        """
        block: str = LlmSwitch.block_for(provider, model, temperature)
        changed: list[str] = []
        marked: int = 0
        for path in sorted(registries.glob(LlmSwitch.NETWORK_PATTERN)):
            text: str = path.read_text(encoding="utf-8")
            if not LlmSwitch.BLOCK_PATTERN.search(text):
                continue
            marked += 1
            updated: str = LlmSwitch.BLOCK_PATTERN.sub(lambda match: match.group(1) + block + match.group(3), text, count=1)
            if updated != text:
                path.write_text(updated, encoding="utf-8", newline="")
                changed.append(path.name)
        if marked == 0:
            raise FileNotFoundError(f"No qa_*.hocon with LLM_CONFIG markers found in {registries}")
        logger.info("AI provider '%s': %d network files checked, %d changed", provider, marked, len(changed))
        return changed
