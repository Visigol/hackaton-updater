"""Job handler for performance reports: statistics from code, the coaching text from the qa_report agent network."""

import logging

from psycopg.types.json import Jsonb

from qa_engine.bridge_error import BridgeError
from qa_engine.job_handler import JobHandler
from qa_engine.neuro_san_client import NeuroSanClient
from qa_engine.performance_stats import PerformanceStats
from qa_engine.tenant_database import TenantDatabase

logger = logging.getLogger(__name__)


class ReportHandler(JobHandler):
    """Handles ``report`` jobs. Payload: ``{"agent_name": "...", "period_days": 30}``."""

    kind: str = "report"
    ROUNDS: int = 2
    MIN_DAYS: int = 1
    MAX_DAYS: int = 365

    def __init__(self, neuro_san: NeuroSanClient) -> None:
        """:param neuro_san: client for the qa_report agent network"""
        self._neuro_san: NeuroSanClient = neuro_san

    def handle(self, job: dict, database: TenantDatabase) -> None:
        """Builds the statistics, has the agents write the report, and stores it in performance_reports.

        :raises LookupError: when the payload is incomplete or the agent has no audits in the period
        :raises BridgeError: when the agent network does not return a usable report
        """
        tenant_id: str = str(job["tenant_id"])
        payload: dict = job.get("payload") or {}
        agent_name: str = str(payload.get("agent_name") or "").strip()
        if not agent_name:
            raise LookupError(f"Job {job['id']} payload has no agent_name")
        days: int = max(self.MIN_DAYS, min(self.MAX_DAYS, int(payload.get("period_days") or 30)))

        with database.session(tenant_id) as connection:
            rubric_row: dict | None = connection.execute("select parameters from public.rubrics where is_active").fetchone()
            audits: list[dict] = connection.execute(
                """select a.overall_score, a.passed, a.critical_fail, a.scored_at, a.scores
                   from public.audit_scores a join public.transcripts t on t.id = a.transcript_id
                   where t.agent_name = %s and a.scored_at >= now() - make_interval(days => %s)
                   order by a.scored_at""", (agent_name, days)).fetchall()
        if not audits:
            raise LookupError(f"{agent_name} has no audits in the last {days} days, so there is nothing to report on")

        checks: list[dict] = [{"key": check.get("key"), "label": check.get("label")}
                              for check in ((rubric_row or {}).get("parameters") or {}).get("checks", [])]
        period: str = f"last {days} days"
        stats: dict = PerformanceStats.compute(audits, checks, agent_name, period)
        report: dict = self._ask_for_report(agent_name, stats)

        with database.session(tenant_id) as connection:
            connection.execute(
                """insert into public.performance_reports (tenant_id, agent_name, period, trends, recommendations)
                   values (%s, %s, %s, %s, %s)""", (tenant_id, agent_name, period, Jsonb(stats), Jsonb(report)))
        logger.info("Stored the report for %s (%s, %d audits)", agent_name, period, stats["audits"])

    def _ask_for_report(self, agent_name: str, stats: dict) -> dict:
        """Asks the qa_report network, again once if it did not record a usable report."""
        last_text: str = ""
        for attempt in range(1, self.ROUNDS + 1):
            logger.info("Asking the Neuro SAN network '%s' for the report of %s (round %d of %d)",
                        self._neuro_san.network, agent_name, attempt, self.ROUNDS)
            returned: dict = self._neuro_san.run(f"Write the coaching report for agent {agent_name}.", {"stats": stats})
            last_text = str(returned.get("text", ""))
            report: dict = (returned.get("sly_data") or {}).get("report") or {}
            if report.get("demo"):
                raise BridgeError("The Neuro SAN network returned a DEMO report; the request did not carry the real statistics")
            if str(report.get("summary") or "").strip() and (report.get("improvements") or report.get("actions")):
                return {key: report.get(key) for key in ("summary", "strengths", "improvements", "actions")}
        raise BridgeError(f"The Neuro SAN network did not record a report after {self.ROUNDS} rounds. "
                          f"Its final answer was: {last_text[:200]!r}")
