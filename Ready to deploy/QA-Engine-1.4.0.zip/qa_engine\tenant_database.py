"""Tenant-scoped database access for the worker's job handlers."""

import contextlib
from collections.abc import Iterator

import psycopg
from psycopg.rows import dict_row


class TenantDatabase:
    """Opens connections that are pinned to ONE tenant, so Row-Level Security applies to every statement.

    This is the same isolation the audit path uses (see JobWorker): the only cross-tenant statement in the worker is
    claiming a job; everything after it runs inside a transaction that first sets ``app.current_tenant``.
    """

    def __init__(self, database_url: str) -> None:
        """:param database_url: transaction-pooler URL for the restricted qa_worker role"""
        self._database_url: str = database_url

    @contextlib.contextmanager
    def session(self, tenant_id: str) -> Iterator[psycopg.Connection]:
        """Yields a connection scoped to ``tenant_id``; the transaction is committed when the block ends normally.

        Prepared statements are off because the transaction pooler cannot reuse them.
        """
        with psycopg.connect(self._database_url, row_factory=dict_row, prepare_threshold=None) as connection:
            connection.execute("select set_config('app.current_tenant', %s, true)", (str(tenant_id),))
            yield connection
