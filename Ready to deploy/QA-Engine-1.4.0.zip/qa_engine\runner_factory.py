"""Builds the AuditRunner from configuration, so the worker and the evaluation script wire it the same way."""

import logging

from qa_engine.audit_runner import AuditRunner
from qa_engine.bridge_client import BridgeClient
from qa_engine.gemini_client import GeminiClient
from qa_engine.llm_switch import LlmSwitch
from qa_engine.neuro_san_client import NeuroSanClient
from qa_engine.settings import Settings

logger = logging.getLogger(__name__)


class RunnerFactory:
    """Reads AUDIT_BACKEND, BRIDGE_URL, NEURO_SAN_URL and NEURO_SAN_NETWORK and returns a configured AuditRunner."""

    BACKENDS: tuple[str, ...] = ("neuro_san", "bridge")

    @staticmethod
    def create(settings: Settings) -> AuditRunner:
        """Creates the runner.

        AUDIT_BACKEND chooses who judges the checks: "neuro_san" (default) sends them to the qa_audit agent network on
        the Neuro SAN server; "bridge" asks the model directly, for debugging.

        :raises RuntimeError: when AUDIT_BACKEND is not one of the known values
        """
        backend: str = settings.get("AUDIT_BACKEND", "neuro_san").strip().lower()
        if backend not in RunnerFactory.BACKENDS:
            raise RuntimeError(f"AUDIT_BACKEND must be one of {', '.join(RunnerFactory.BACKENDS)}, not '{backend}'")

        client = RunnerFactory.create_client(settings)
        if backend == "bridge":
            logger.warning("AUDIT_BACKEND=bridge: checks go straight to the model, not through Neuro SAN")
            return AuditRunner(client)

        neuro_san = NeuroSanClient(settings.get("NEURO_SAN_URL", "http://127.0.0.1:8080"),
                                   settings.get("NEURO_SAN_NETWORK", "qa_audit"))
        logger.info("Checks are judged by the Neuro SAN network '%s'", neuro_san.network)
        return AuditRunner(client, neuro_san)

    @staticmethod
    def create_client(settings: Settings) -> BridgeClient | GeminiClient:
        """The model client for the call summary (and for AUDIT_BACKEND=bridge), chosen by AI_PROVIDER.

        AI_PROVIDER is "nano" (default: Chrome's on-device model through the bridge) or "gemini" (cloud; needs
        GOOGLE_API_KEY, and uses GEMINI_MODEL, default gemini-2.5-flash).

        :raises RuntimeError: when AI_PROVIDER is unknown or the Gemini key is missing
        """
        provider: str = settings.get("AI_PROVIDER", "nano").strip().lower()
        if provider == "nano":
            return BridgeClient(settings.get("BRIDGE_URL", "http://127.0.0.1:8000"))
        if provider == "gemini":
            model: str = settings.get("GEMINI_MODEL", "").strip() or LlmSwitch.DEFAULT_GEMINI_MODEL
            temperature_text: str = settings.get("GEMINI_TEMPERATURE", "").strip()
            temperature: float = float(temperature_text) if temperature_text else LlmSwitch.default_temperature(model)
            logger.info("AI provider: cloud Gemini (%s)", model)
            return GeminiClient(settings.require("GOOGLE_API_KEY"), model, temperature=temperature)
        raise RuntimeError(f"AI_PROVIDER must be one of {', '.join(LlmSwitch.PROVIDERS)}, not '{provider}'")
