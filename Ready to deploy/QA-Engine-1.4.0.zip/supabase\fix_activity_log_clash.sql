-- Run ONCE, then run the updated admin_setup.sql again.
--
-- Why: your database already had a table called public.activity_log (from earlier work). The first version of
-- admin_setup.sql tried to reuse that name and attached its own policies and index to YOUR table. The platform's
-- audit trail now lives in a separate table, public.audit_trail, so this removes only what admin_setup.sql added to
-- the old one. Your own table, its columns, its data and its original policies are not touched.

drop policy if exists log_select on public.activity_log;
drop policy if exists log_insert on public.activity_log;
drop index if exists public.activity_log_tenant_time;

-- Check the result. These should now be your ORIGINAL policies only (no log_select / log_insert).
select policyname, cmd from pg_policies where schemaname = 'public' and tablename = 'activity_log';

-- The first script also switched row-level security ON for that table. If you KNOW it was off before AND some tool of
-- yours writes to it with a normal login, that tool would now be blocked. Only in that case, switch it back with:
--   alter table public.activity_log disable row level security;
select relrowsecurity as rls_is_on from pg_class where oid = 'public.activity_log'::regclass;
