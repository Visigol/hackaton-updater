"""A readable log of what the agents say to each other and to their tools, for demos and for understanding an audit.

Neuro SAN can stream every message of a run (the "maximal" chat filter): who invoked whom with which arguments, the tool
results, and each agent's reply. This class turns those messages into one short line each and appends them to a file that
the "Show logs" window tails. It is off unless the QA_AGENT_TRACE_FILE environment variable names a file, and it never
interferes with an audit: a problem writing the file is logged once and ignored.
"""

import logging
import os
import time
from datetime import datetime

logger = logging.getLogger(__name__)


class AgentTrace:
    """Formats and writes the agent conversation."""

    ENVIRONMENT_VARIABLE: str = "QA_AGENT_TRACE_FILE"
    SHORT_TEXT: int = 150        # longest piece of text shown on a line
    SHORT_VALUE: int = 90        # longest argument value shown
    HIDE_RESULTS_LONGER_THAN: int = 60  # a long tool result is a piece of the call: only its size is shown

    def __init__(self, path: str | None) -> None:
        """:param path: the file to append to, or None to do nothing"""
        self._path: str | None = path or None
        self._warned: bool = False
        self._started: float = 0.0

    @staticmethod
    def from_environment() -> "AgentTrace":
        """The trace configured by QA_AGENT_TRACE_FILE (a no-op trace when it is not set)."""
        return AgentTrace(os.environ.get(AgentTrace.ENVIRONMENT_VARIABLE))

    @property
    def enabled(self) -> bool:
        """True when lines will be written."""
        return self._path is not None

    def begin(self, network: str, message: str) -> None:
        """Marks the start of one run of a network."""
        self._started = time.monotonic()
        self._write(f"=== {network} started: {self._short(message, self.SHORT_TEXT)}")

    def end(self, network: str) -> None:
        """Marks the end of one run of a network."""
        self._write(f"=== {network} finished in {time.monotonic() - self._started:.0f}s")

    def message(self, body: dict) -> None:
        """Writes the line for one streamed message, if it is worth showing."""
        line: str | None = AgentTrace.describe(body)
        if line:
            self._write(line)

    @staticmethod
    def describe(body: dict) -> str | None:
        """One readable line for a streamed message, or None for the messages that are only noise."""
        kind: str = str(body.get("type") or "")
        text: str = str(body.get("text") or "").strip()
        origin: list = body.get("origin") or []
        who: str = AgentTrace._name(origin[-1]) if origin else ""
        structure: dict = body.get("structure") or {}

        if kind == "HUMAN" and text:
            return f"{who:<16} is asked:  {AgentTrace._short(text, AgentTrace.SHORT_TEXT)}"
        if kind == "AGENT" and structure.get("invoking_start"):
            return f"{who:<16} ->  {AgentTrace._name_only(structure.get('invoked_agent_name')):<16} {AgentTrace._params(structure.get('params') or {})}"
        if kind == "AGENT_TOOL_RESULT":
            source: str = AgentTrace._name(body.get("tool_result_origin", [{}])[-1]) if body.get("tool_result_origin") else "?"
            shown: str = (f"({len(text):,} characters, not shown)" if len(text) > AgentTrace.HIDE_RESULTS_LONGER_THAN
                          else AgentTrace._short(text, AgentTrace.SHORT_TEXT))
            return f"{source:<16} <-  {who:<16} {shown}"
        if kind == "AI" and text:
            return f"{who:<16} says:  {AgentTrace._short(text, AgentTrace.SHORT_TEXT)}"
        return None

    @staticmethod
    def _params(params: dict) -> str:
        """The arguments of a call as key=value pairs, long values shortened."""
        return ", ".join(f"{key}={AgentTrace._value(value)}" for key, value in params.items() if key != "origin")

    @staticmethod
    def _value(value: object) -> str:
        """One argument value, quoted when it is text."""
        if isinstance(value, str):
            return '"' + AgentTrace._short(value, AgentTrace.SHORT_VALUE) + '"'
        return AgentTrace._short(str(value), AgentTrace.SHORT_VALUE)

    @staticmethod
    def _name(origin: dict) -> str:
        """The agent or tool of an origin entry, with its instance number when it is not the first."""
        name: str = AgentTrace._name_only(origin.get("tool"))
        index = origin.get("instantiation_index")
        return f"{name}#{index}" if index and int(index) > 1 else name

    @staticmethod
    def _name_only(name: object) -> str:
        """An agent name without any folder prefix."""
        return str(name or "?").split("/")[-1]

    @staticmethod
    def _short(text: str, limit: int) -> str:
        """The text on one line, cut at ``limit`` characters."""
        flat: str = " ".join(text.split())
        return flat if len(flat) <= limit else flat[:limit - 3] + "..."

    def _write(self, line: str) -> None:
        """Appends a timestamped line; a failure is reported once and then ignored."""
        if self._path is None:
            return
        try:
            with open(self._path, "a", encoding="utf-8") as handle:
                handle.write(f"{datetime.now():%H:%M:%S}  {line}\n")
        except OSError as error:
            if not self._warned:
                self._warned = True
                logger.warning("Agent trace could not write to %s: %s", self._path, error)
