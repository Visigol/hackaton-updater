"""Tool calling for a model that only returns text (Chrome's on-device Gemini Nano).

Neuro SAN delegates from one agent to another by giving the calling agent's model a list of tools (the sub-agents) and
expecting OpenAI-style ``tool_calls`` back. The model behind bridge.py cannot do that natively, so this module:

1. turns the tools and the conversation so far into one plain-text prompt plus a JSON schema for the reply, and
2. turns the model's JSON reply back into an OpenAI assistant message, with ``tool_calls`` or a final answer.

Nothing here talks to Chrome, so all of it is unit-tested (tests/test_bridge_tools.py).
"""

import json
import re
import uuid
from typing import Any


class ToolCallError(ValueError):
    """The model's reply cannot be used. The message explains why and is fed back to the model for one retry."""


class ToolCallAdapter:
    """Builds the prompt and schema for a tool-using request and parses the model's reply."""

    FENCE_PATTERN: str = r"^```json\s*|^```\s*|```$"

    PROTOCOL: str = (
        "HOW TO REPLY\n"
        "Reply with JSON only, no markdown, in exactly this shape:\n"
        '{"tool_calls": [{"name": "<tool name>", "arguments": {}}], "answer": ""}\n'
        "- To use tools, list them in tool_calls and leave answer empty. You may list several tools in one reply.\n"
        "- When you have everything you need, reply with tool_calls empty and your final answer in answer.\n"
        "- Never call a tool you already have a result for, unless that result was an error.\n"
    )

    @staticmethod
    def tool_specs(tools: list[dict]) -> list[dict]:
        """Reduces OpenAI tool definitions to name, description and argument properties."""
        specs: list[dict] = []
        for tool in tools or []:
            function: dict = tool.get("function") or {}
            if not function.get("name"):
                continue
            parameters: dict = function.get("parameters") or {}
            specs.append({
                "name": function["name"],
                "description": (function.get("description") or "").strip(),
                "properties": parameters.get("properties") or {},
                "required": parameters.get("required") or [],
            })
        return specs

    @staticmethod
    def response_schema(tools: list[dict]) -> dict:
        """JSON Schema that constrains the model's reply, so Chrome can enforce the shape."""
        names: list[str] = [spec["name"] for spec in ToolCallAdapter.tool_specs(tools)]
        return {
            "type": "object",
            "properties": {
                "tool_calls": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {"name": {"type": "string", "enum": names}, "arguments": {"type": "object"}},
                        "required": ["name", "arguments"],
                    },
                },
                "answer": {"type": "string"},
            },
            "required": ["tool_calls", "answer"],
        }

    @staticmethod
    def build_user_prompt(messages: list[dict], tools: list[dict], instructions: str = "") -> str:
        """Writes the task, the tools, what has happened so far and the reply format as one prompt.

        :param messages: the OpenAI messages (system messages are handled by the caller, not here)
        :param tools: the OpenAI tool definitions
        :param instructions: the agent's own instructions; the tools they name must be called before it may finish
        """
        names_by_call_id: dict[str, str] = {}
        task_parts: list[str] = []
        history: list[str] = []
        for message in messages:
            role: str = message.get("role")
            content: str = (message.get("content") or "").strip()
            if role == "user" and content:
                task_parts.append(content)
            elif role == "assistant":
                for call in message.get("tool_calls") or []:
                    function: dict = call.get("function") or {}
                    names_by_call_id[call.get("id", "")] = function.get("name", "?")
                    history.append(f"You called {function.get('name', '?')} with arguments {function.get('arguments') or '{}'}.")
                if content:
                    history.append(f"You said: {content}")
            elif role == "tool":
                name: str = names_by_call_id.get(message.get("tool_call_id", ""), message.get("name") or "a tool")
                history.append(f"RESULT from {name}: {content or '(empty)'}")

        specs: list[dict] = ToolCallAdapter.tool_specs(tools)
        lines: list[str] = ["TASK\n" + ("\n\n".join(task_parts) if task_parts else "(no task text was given)")]
        lines.append("TOOLS YOU CAN CALL\n" + ToolCallAdapter._describe_tools(specs))
        lines.append("WHAT HAS HAPPENED SO FAR\n" + ("\n".join(history) if history else "Nothing yet. You have not called any tool."))
        lines.append("STATUS\n" + ToolCallAdapter._status(
            specs, set(names_by_call_id.values()), ToolCallAdapter.required_tools(instructions, specs)))
        lines.append(ToolCallAdapter.PROTOCOL)
        return "\n\n".join(lines)

    @staticmethod
    def required_tools(instructions: str, specs: list[dict]) -> list[str]:
        """The tools an agent's own instructions name. Whoever wrote the steps meant each of them to be used."""
        return [spec["name"] for spec in specs if re.search(rf"\b{re.escape(spec['name'])}\b", instructions or "")]

    @staticmethod
    def called_tools(messages: list[dict]) -> set[str]:
        """Names of the tools that have already been called in this conversation."""
        return {(call.get("function") or {}).get("name", "")
                for message in messages if message.get("role") == "assistant" for call in message.get("tool_calls") or []}

    @staticmethod
    def _status(specs: list[dict], called: set[str], required: list[str] | None = None) -> str:
        """Tells the model what is left to do. Small models tend to stop after one call without this."""
        outstanding: list[str] = [name for name in (required or []) if name not in called]
        if outstanding:
            return ("Your instructions require you to call these tools before you finish: " + ", ".join(outstanding)
                    + ". Do that now. If one of them needs the result of another, call the other first and wait for its result.")
        remaining: list[str] = [spec["name"] for spec in specs if spec["name"] not in called]
        if not remaining:
            return "Every tool has been called and you have all the results. Give your final answer now, with tool_calls empty."
        return ("Tools not called yet: " + ", ".join(remaining) + ". Call the tools the task needs. If a tool needs the "
                "result of another tool, call the other one first and wait for its result. "
                "Give the final answer only after you have the results.")

    @staticmethod
    def parse_reply(text: str, tools: list[dict], messages: list[dict], instructions: str = "") -> dict:
        """Turns the model's JSON reply into an OpenAI assistant message.

        :param text: the raw model output
        :param tools: the OpenAI tool definitions, used to reject invented tool names
        :param messages: the conversation, used to reject a call that repeats one already answered
        :return: {"role": "assistant", "content": ..., "tool_calls": ...} ready to place in a chat completion
        :raises ToolCallError: when the reply is not valid; the message says what to fix
        """
        clean: str = re.sub(ToolCallAdapter.FENCE_PATTERN, "", (text or "").strip(), flags=re.MULTILINE).strip()
        try:
            data: Any = json.loads(clean)
        except json.JSONDecodeError as error:
            data = ToolCallAdapter._first_json_object(clean)  # the model sometimes adds words around a valid object
            if data is None:
                raise ToolCallError(f"The reply was not valid JSON ({error.msg}). Reply with the JSON object only.") from error
        if not isinstance(data, dict):
            raise ToolCallError("The reply must be a JSON object with tool_calls and answer.")

        specs: list[dict] = ToolCallAdapter.tool_specs(tools)
        known: set[str] = {spec["name"] for spec in specs}
        already: set[str] = ToolCallAdapter._previous_calls(messages)
        calls: list[dict] = []
        seen: set[str] = set()
        repeated: str = ""  # set when the model calls something it already has the result of; judged after the loop
        for raw in data.get("tool_calls") or []:
            if not isinstance(raw, dict) or raw.get("name") not in known:
                raise ToolCallError(f"Unknown tool {raw.get('name') if isinstance(raw, dict) else raw!r}. "
                                    f"Use only: {', '.join(sorted(known))}.")
            arguments: Any = raw.get("arguments") if raw.get("arguments") is not None else {}
            if isinstance(arguments, str):
                try:
                    arguments = json.loads(arguments or "{}")
                except json.JSONDecodeError as error:
                    raise ToolCallError(f"Arguments for {raw['name']} must be a JSON object.") from error
            if not isinstance(arguments, dict):
                raise ToolCallError(f"Arguments for {raw['name']} must be a JSON object.")
            required: list[str] = next(spec["required"] for spec in specs if spec["name"] == raw["name"])
            missing: list[str] = [name for name in required if arguments.get(name) in (None, "")]
            if missing:
                raise ToolCallError(f"{raw['name']} needs these arguments: {', '.join(missing)}. Give a value for each.")
            signature: str = ToolCallAdapter._signature(raw["name"], arguments)
            if signature in already:
                repeated = (f"You already called {raw['name']} with these arguments and have its result. "
                            "Use the result and give your final answer.")
                continue
            if signature not in seen:
                seen.add(signature)
                calls.append({"id": f"call_{uuid.uuid4().hex[:12]}", "type": "function",
                              "function": {"name": raw["name"], "arguments": json.dumps(arguments, ensure_ascii=False)}})
        if calls:
            return {"role": "assistant", "content": None, "tool_calls": calls}

        # A final answer (or an empty reply) is not allowed while the agent's own instructions still require a tool.
        outstanding: list[str] = [name for name in ToolCallAdapter.required_tools(instructions, specs)
                                  if name not in ToolCallAdapter.called_tools(messages)]
        if outstanding:
            raise ToolCallError(f"You have not called {', '.join(outstanding)} yet, and your instructions require it before "
                                "you finish. Call it now, using the results you already have.")

        answer: str = str(data.get("answer") or "").strip()
        if not answer:
            # The work is done (every required tool has a result) and the agent's instructions say exactly what to say
            # at the end, for example "reply with: Recorded." Using that sentence saves a slow retry whose only purpose
            # would be to get the model to say it.
            scripted: str = ToolCallAdapter._scripted_reply(instructions)
            if scripted and (repeated or ToolCallAdapter.called_tools(messages)):
                return {"role": "assistant", "content": scripted}
            if repeated:
                raise ToolCallError(repeated)
            raise ToolCallError("The reply has no tool_calls and an empty answer. Either call a tool or give the answer.")
        return {"role": "assistant", "content": answer}

    @staticmethod
    def _scripted_reply(instructions: str) -> str:
        """The sentence an agent's instructions tell it to finish with ("reply with: Recorded."), or an empty string."""
        found = re.search(r"reply with:?\s*[\"“]?([^\"”\n]+?)[\"”]?\s*$", instructions or "", flags=re.IGNORECASE | re.MULTILINE)
        return found.group(1).strip() if found else ""

    @staticmethod
    def _first_json_object(text: str) -> Any:
        """The first complete JSON object found in ``text``, ignoring anything around it, or None."""
        start: int = text.find("{")
        if start < 0:
            return None
        try:
            value, _ = json.JSONDecoder().raw_decode(text[start:])
        except json.JSONDecodeError:
            return None
        return value if isinstance(value, dict) else None

    @staticmethod
    def _describe_tools(specs: list[dict]) -> str:
        """One readable line per tool, including its arguments."""
        if not specs:
            return "(none)"
        lines: list[str] = []
        for spec in specs:
            if spec["properties"]:
                arguments = "; ".join(
                    f'"{name}" ({(prop or {}).get("type", "string")}): {(prop or {}).get("description", "").strip()}'
                    for name, prop in spec["properties"].items())
                arguments = "arguments: " + arguments
            else:
                arguments = 'arguments: none (use {})'
            lines.append(f'- {spec["name"]}: {spec["description"] or "(no description)"} [{arguments}]')
        return "\n".join(lines)

    @staticmethod
    def _signature(name: str, arguments: dict) -> str:
        """A stable identity for a call, so repeats can be recognized."""
        return name + ":" + json.dumps(arguments, sort_keys=True, ensure_ascii=False)

    @staticmethod
    def _previous_calls(messages: list[dict]) -> set[str]:
        """Signatures of the calls that already have a result in this conversation."""
        answered_ids: set[str] = {m.get("tool_call_id") for m in messages if m.get("role") == "tool"}
        signatures: set[str] = set()
        for message in messages:
            if message.get("role") != "assistant":
                continue
            for call in message.get("tool_calls") or []:
                if call.get("id") not in answered_ids:
                    continue
                function: dict = call.get("function") or {}
                try:
                    arguments: Any = json.loads(function.get("arguments") or "{}")
                except json.JSONDecodeError:
                    arguments = {}
                signatures.add(ToolCallAdapter._signature(function.get("name", ""), arguments if isinstance(arguments, dict) else {}))
        return signatures
