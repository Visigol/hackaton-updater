"""QA Platform web app on Vercel (FastAPI zero-config entrypoint): pages plus the admin user-management API."""

import json
import os
import re
import uuid

import httpx
from fastapi import FastAPI
from fastapi import Header
from fastapi import HTTPException
from fastapi.responses import HTMLResponse
from fastapi.responses import Response
from pydantic import BaseModel
from pydantic import Field

from dashboard_page import DASHBOARD_PAGE
from pages import LOGIN_PAGE

app = FastAPI(title="QA Platform")

ROLES: tuple[str, ...] = ("admin", "supervisor", "team_lead", "agent")
EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# --------------------------------------------------------------------------------------------------------------------
# Pages
# --------------------------------------------------------------------------------------------------------------------
@app.get("/config.js")
async def config_js() -> Response:
    """Expose the public Supabase URL and anon key (both safe for browsers; RLS protects the data)."""
    config = {
        "supabaseUrl": os.environ.get("SUPABASE_URL", ""),
        "supabaseAnonKey": os.environ.get("SUPABASE_ANON_KEY", ""),
    }
    return Response(
        content="window.APP_CONFIG = " + json.dumps(config) + ";",
        media_type="application/javascript",
        headers={"Cache-Control": "no-store"},
    )


@app.get("/", response_class=HTMLResponse)
async def login() -> str:
    """Login page."""
    return LOGIN_PAGE


@app.get("/t/{slug}/dashboard", response_class=HTMLResponse)
async def dashboard(slug: str) -> str:
    """Tenant dashboard shell; data is loaded in the browser under the user's own Supabase session."""
    return DASHBOARD_PAGE


@app.get("/api/health")
async def health() -> dict:
    """Liveness probe."""
    return {"status": "ok"}


# --------------------------------------------------------------------------------------------------------------------
# Admin API. The only code that holds the service-role key. Every call (1) verifies the caller's session with Supabase,
# (2) requires role 'admin' in public.users, and (3) takes the tenant from that row, never from the request body.
# --------------------------------------------------------------------------------------------------------------------
class NewUser(BaseModel):
    """Payload for creating a login inside the admin's own tenant."""

    email: str = Field(min_length=5, max_length=254)
    password: str = Field(min_length=10, max_length=72)
    role: str
    agent_name: str | None = Field(default=None, max_length=120)


class RoleChange(BaseModel):
    """Payload for changing a user's role."""

    role: str


class PasswordChange(BaseModel):
    """Payload for setting a new password."""

    password: str = Field(min_length=10, max_length=72)


def _settings() -> tuple[str, str, str]:
    """Reads the Supabase settings; a missing one is a deployment error, reported clearly."""
    url = os.environ.get("SUPABASE_URL", "").rstrip("/")
    anon = os.environ.get("SUPABASE_ANON_KEY", "")
    service = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")
    if not (url and anon and service):
        raise HTTPException(503, "Server is missing SUPABASE_URL, SUPABASE_ANON_KEY or SUPABASE_SERVICE_ROLE_KEY.")
    return url, anon, service


def _service_headers(service_key: str) -> dict[str, str]:
    """Headers for service-role calls. New-style secret keys (sb_secret_...) are not JWTs, so only legacy keys
    may also go in the Authorization header."""
    headers = {"apikey": service_key, "Content-Type": "application/json"}
    if service_key.startswith("eyJ"):
        headers["Authorization"] = f"Bearer {service_key}"
    return headers


def _error_message(response: httpx.Response) -> str:
    """Extracts a readable message from a Supabase error response."""
    try:
        body = response.json()
    except ValueError:
        return f"Supabase returned {response.status_code}"
    if isinstance(body, dict):
        return str(body.get("msg") or body.get("message") or body.get("error_description") or body.get("error")
                   or f"Supabase returned {response.status_code}")
    return f"Supabase returned {response.status_code}"


async def _require_admin(client: httpx.AsyncClient, authorization: str | None) -> dict:
    """Verifies the bearer token and returns the caller's {id, tenant_id, email}; 401/403 otherwise."""
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Missing session token.")
    token = authorization[7:].strip()
    url, anon, _ = _settings()
    user_headers = {"apikey": anon, "Authorization": f"Bearer {token}"}

    who = await client.get(f"{url}/auth/v1/user", headers=user_headers)
    if who.status_code != 200:
        raise HTTPException(401, "Your session is invalid or expired. Sign in again.")
    user_id = who.json().get("id")

    rows = await client.get(f"{url}/rest/v1/users", headers=user_headers,
                            params={"id": f"eq.{user_id}", "select": "id,tenant_id,role,email"})
    caller = rows.json()[0] if rows.status_code == 200 and rows.json() else None
    if not caller or caller.get("role") != "admin":
        raise HTTPException(403, "Only admins can manage users.")
    return caller


async def _log(client: httpx.AsyncClient, admin: dict, action: str, detail: dict) -> None:
    """Records an admin action in the tenant's activity log. Best effort: a logging failure never blocks the action."""
    url, _, service = _settings()
    try:
        await client.post(f"{url}/rest/v1/audit_trail", headers=_service_headers(service),
                          json={"tenant_id": admin["tenant_id"], "actor_id": admin["id"],
                                "actor_email": admin.get("email"), "action": action, "detail": detail})
    except httpx.HTTPError:
        pass


async def _load_target(client: httpx.AsyncClient, admin: dict, user_id: str) -> dict:
    """Returns the target user, which must belong to the admin's own tenant."""
    try:
        uuid.UUID(user_id)
    except ValueError as error:
        raise HTTPException(422, "Invalid user id.") from error
    url, _, service = _settings()
    rows = await client.get(f"{url}/rest/v1/users", headers=_service_headers(service),
                            params={"id": f"eq.{user_id}", "tenant_id": f"eq.{admin['tenant_id']}",
                                    "select": "id,role,email"})
    if rows.status_code != 200 or not rows.json():
        raise HTTPException(404, "User not found in your organization.")
    return rows.json()[0]


@app.post("/api/admin/users")
async def create_user(body: NewUser, authorization: str | None = Header(default=None)) -> dict:
    """Creates a confirmed login and links it to the admin's tenant with the chosen role."""
    email = body.email.strip().lower()
    if not EMAIL_PATTERN.match(email):
        raise HTTPException(422, "Enter a valid email address.")
    if body.role not in ROLES:
        raise HTTPException(422, "Unknown role.")
    url, _, service = _settings()
    async with httpx.AsyncClient(timeout=20) as client:
        admin = await _require_admin(client, authorization)
        created = await client.post(f"{url}/auth/v1/admin/users", headers=_service_headers(service),
                                    json={"email": email, "password": body.password, "email_confirm": True})
        if created.status_code >= 400:
            raise HTTPException(400, _error_message(created))
        new_id = created.json().get("id")

        row = {"id": new_id, "tenant_id": admin["tenant_id"], "email": email, "role": body.role}
        if body.agent_name:
            row["agent_name"] = body.agent_name.strip()
        headers = {**_service_headers(service), "Prefer": "resolution=merge-duplicates,return=representation"}
        linked = await client.post(f"{url}/rest/v1/users", headers=headers, params={"on_conflict": "id"}, json=row)
        if linked.status_code >= 400:
            await client.delete(f"{url}/auth/v1/admin/users/{new_id}", headers=_service_headers(service))
            raise HTTPException(400, "Could not link the user to your organization: " + _error_message(linked))
        await _log(client, admin, "user.created", {"email": email, "role": body.role})
    return {"id": new_id, "email": email, "role": body.role}


@app.patch("/api/admin/users/{user_id}")
async def change_role(user_id: str, body: RoleChange, authorization: str | None = Header(default=None)) -> dict:
    """Changes another user's role inside the admin's tenant."""
    if body.role not in ROLES:
        raise HTTPException(422, "Unknown role.")
    url, _, service = _settings()
    async with httpx.AsyncClient(timeout=20) as client:
        admin = await _require_admin(client, authorization)
        if user_id == admin["id"]:
            raise HTTPException(400, "You cannot change your own role. Ask another admin.")
        target = await _load_target(client, admin, user_id)
        updated = await client.patch(f"{url}/rest/v1/users", headers=_service_headers(service),
                                     params={"id": f"eq.{user_id}", "tenant_id": f"eq.{admin['tenant_id']}"},
                                     json={"role": body.role})
        if updated.status_code >= 400:
            raise HTTPException(400, _error_message(updated))
        await _log(client, admin, "user.role_changed",
                   {"email": target.get("email"), "from": target.get("role"), "to": body.role})
    return {"id": user_id, "role": body.role}


@app.post("/api/admin/users/{user_id}/password")
async def reset_password(user_id: str, body: PasswordChange,
                         authorization: str | None = Header(default=None)) -> dict:
    """Sets a new password for a user in the admin's tenant."""
    url, _, service = _settings()
    async with httpx.AsyncClient(timeout=20) as client:
        admin = await _require_admin(client, authorization)
        target = await _load_target(client, admin, user_id)
        changed = await client.put(f"{url}/auth/v1/admin/users/{user_id}", headers=_service_headers(service),
                                   json={"password": body.password})
        if changed.status_code >= 400:
            raise HTTPException(400, _error_message(changed))
        await _log(client, admin, "user.password_reset", {"email": target.get("email")})
    return {"id": user_id}


@app.delete("/api/admin/users/{user_id}")
async def delete_user(user_id: str, authorization: str | None = Header(default=None)) -> dict:
    """Removes a user's access: deletes the tenant link and then the login itself."""
    url, _, service = _settings()
    async with httpx.AsyncClient(timeout=20) as client:
        admin = await _require_admin(client, authorization)
        if user_id == admin["id"]:
            raise HTTPException(400, "You cannot delete your own account.")
        target = await _load_target(client, admin, user_id)
        unlinked = await client.delete(f"{url}/rest/v1/users", headers=_service_headers(service),
                                       params={"id": f"eq.{user_id}", "tenant_id": f"eq.{admin['tenant_id']}"})
        if unlinked.status_code >= 400:
            raise HTTPException(400, "Could not remove the user (it may still own records): "
                                + _error_message(unlinked))
        removed = await client.delete(f"{url}/auth/v1/admin/users/{user_id}", headers=_service_headers(service))
        if removed.status_code >= 400 and removed.status_code != 404:
            raise HTTPException(400, _error_message(removed))
        await _log(client, admin, "user.deleted", {"email": target.get("email"), "role": target.get("role")})
    return {"id": user_id}
