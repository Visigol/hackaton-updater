"""HTTP client for cloud Gemini. Same two methods as BridgeClient, so the audit runner works with either."""

import logging

import requests

from qa_engine.bridge_error import BridgeError

logger = logging.getLogger(__name__)


class GeminiClient:
    """Summarizes a transcript and answers single prompts through the Gemini REST API (generateContent).

    The key is sent in a header, never in the URL, so it cannot end up in a log line.
    """

    BASE_URL: str = "https://generativelanguage.googleapis.com/v1beta"
    TIMEOUT_SECONDS: int = 90
    SUMMARY_PROMPT: str = (
        "Summarize this contact-center call as 3 to 5 short bullet points that start with '* '. State who called, what "
        "the problem was, what the agent did and how the call ended. Use only what the text says.\n\nCALL:\n{text}")

    def __init__(self, api_key: str, model: str, base_url: str = BASE_URL, temperature: float = 0.0) -> None:
        """Creates a client.

        :param api_key: GOOGLE_API_KEY
        :param model: Gemini model id, for example gemini-2.5-flash
        :param base_url: API root (overridden only by tests)
        :param temperature: sampling temperature for single prompts
        """
        self._api_key: str = api_key
        self._model: str = model
        self._base_url: str = base_url.rstrip("/")
        self._temperature: float = temperature

    def summarize(self, text: str) -> str:
        """Returns a key-points summary of the sanitized transcript.

        :raises BridgeError: on any transport or payload problem
        """
        return self._generate(self.SUMMARY_PROMPT.format(text=text))

    def complete(self, user_prompt: str) -> str:
        """Returns the model's text answer to a single user prompt.

        :raises BridgeError: on any transport or payload problem
        """
        return self._generate(user_prompt)

    def _generate(self, prompt: str) -> str:
        """Calls generateContent and returns the text of the first candidate."""
        url: str = f"{self._base_url}/models/{self._model}:generateContent"
        payload: dict = {"contents": [{"role": "user", "parts": [{"text": prompt}]}],
                         "generationConfig": {"temperature": self._temperature}}
        try:
            response: requests.Response = requests.post(url, json=payload, headers={"x-goog-api-key": self._api_key},
                                                         timeout=self.TIMEOUT_SECONDS)
            response.raise_for_status()
            body: dict = response.json()
        except (requests.RequestException, ValueError) as error:
            # str(error) of an HTTP error contains the URL but never the key header.
            logger.error("Gemini call to model %s failed: %s", self._model, error)
            raise BridgeError(f"Gemini call to model {self._model} failed: {error}") from error

        parts: list = (((body.get("candidates") or [{}])[0].get("content") or {}).get("parts")) or []
        text: str = "".join(str(part.get("text") or "") for part in parts if isinstance(part, dict)).strip()
        if not text:
            raise BridgeError(f"Gemini returned no text (finish reason: "
                              f"{(body.get('candidates') or [{}])[0].get('finishReason')}): {str(body)[:200]}")
        return text
