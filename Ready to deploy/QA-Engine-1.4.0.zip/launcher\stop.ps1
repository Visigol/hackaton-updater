# Stops the QA engine: the supervisor, the Python services and the dedicated Chrome.
param([switch]$FromSupervisor)

. "$PSScriptRoot\common.ps1"
$pidFile = Join-Path $script:RunDir 'supervisor.pid'
$stopFile = Join-Path $script:RunDir 'stop.flag'

if (-not $FromSupervisor -and (Test-Path $pidFile)) {
    # Ask the supervisor to shut down in an orderly way, then wait a little.
    New-Item -ItemType Directory -Force -Path $script:RunDir | Out-Null
    Set-Content -Path $stopFile -Value 'stop'
    for ($i = 0; $i -lt 20 -and (Test-Path $pidFile); $i++) { Start-Sleep -Seconds 1 }
}

# Whatever is still alive: free the ports, then the processes started from the install folder.
foreach ($port in 8000, 8080, 8081, 4173, 9222) {
    Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue |
        ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
}
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -and $_.CommandLine -like "*$($script:Root)*" -and $_.Name -match '^python' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -like '*ChromeNanoSession*' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

if (-not $FromSupervisor) {
    if (Test-Path $pidFile) {
        $supervisor = Get-Content $pidFile -Raw
        if ($supervisor) { Stop-Process -Id ([int]$supervisor) -Force -ErrorAction SilentlyContinue }
        Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
    }
    Remove-Item $stopFile -Force -ErrorAction SilentlyContinue
    Write-Ok 'The QA engine is stopped.'
}
