"""Job handler for research: turns reviewer corrections and policy documents into pending rubric change requests."""

import logging

import psycopg
from psycopg.types.json import Jsonb

from qa_engine.bridge_error import BridgeError
from qa_engine.findings_builder import FindingsBuilder
from qa_engine.job_handler import JobHandler
from qa_engine.neuro_san_client import NeuroSanClient
from qa_engine.tenant_database import TenantDatabase

logger = logging.getLogger(__name__)


class ResearchHandler(JobHandler):
    """Handles ``research`` jobs. Payload: ``{}`` (all checks) or ``{"check_key": "compliance"}``.

    The result is a set of PENDING change requests. Nothing here edits a rubric: an admin approves or rejects each one.
    """

    kind: str = "research"
    ROUNDS: int = 2
    FEEDBACK_DAYS: int = 180
    FEEDBACK_LIMIT: int = 300

    def __init__(self, neuro_san: NeuroSanClient, min_corrections: int = 2) -> None:
        """:param neuro_san: client for the qa_research agent network
        :param min_corrections: how many reviewer corrections make a check worth working on
        """
        self._neuro_san: NeuroSanClient = neuro_san
        self._min_corrections: int = min_corrections

    def handle(self, job: dict, database: TenantDatabase) -> None:
        """Gathers the findings, asks the agents for proposals, and files them as pending change requests.

        :raises LookupError: when there is no active rubric or nothing to learn from yet
        :raises BridgeError: when the agent network does not return usable proposals
        """
        tenant_id: str = str(job["tenant_id"])
        only: str = str((job.get("payload") or {}).get("check_key") or "").strip()
        rubric, feedback = self._read_rubric_and_feedback(tenant_id, database)
        checks: list[dict] = [check for check in (rubric["parameters"] or {}).get("checks", []) if not only or check.get("key") == only]
        findings: dict[str, dict] = FindingsBuilder.build(checks, feedback, self._read_documents(tenant_id, database), self._min_corrections)
        if not findings:
            raise LookupError(f"Nothing to learn from yet: no check has {self._min_corrections} or more reviewer corrections "
                              "and no policy document matches. Review some audits first (Review and edit score).")

        proposals: dict[str, dict] = self._ask(findings)
        filed: int = 0
        with database.session(tenant_id) as connection:
            for key, proposal in proposals.items():
                old_rules: list[str] = findings[key]["rules"]
                if [rule.strip() for rule in proposal["rules"]] == [rule.strip() for rule in old_rules]:
                    logger.info("Proposal for %s repeats the current rules; not filed", key)
                    continue
                diff: dict = {"check_key": key, "check_label": findings[key]["label"], "old_rules": old_rules,
                              "new_rules": proposal["rules"], "rationale": proposal["rationale"],
                              "corrections_used": len(findings[key]["corrections"]), "rubric_version": rubric["version"]}
                connection.execute(
                    """insert into public.rubric_change_requests (tenant_id, proposed_by, diff, status)
                       values (%s, 'system', %s, 'pending')""", (tenant_id, Jsonb(diff)))
                filed += 1
        logger.info("Research filed %d change request(s) for review", filed)

    def _read_rubric_and_feedback(self, tenant_id: str, database: TenantDatabase) -> tuple[dict, list[dict]]:
        """The active rubric and the reviewer corrections, read under the tenant's scope."""
        with database.session(tenant_id) as connection:
            rubric: dict | None = connection.execute("select version, parameters from public.rubrics where is_active").fetchone()
            if rubric is None:
                raise LookupError(f"Tenant {tenant_id} has no active rubric")
            feedback: list[dict] = connection.execute(
                """select f.check_key, f.ai_passed, f.human_passed, f.ai_reason, f.human_reason, t.raw_text
                   from public.rule_feedback f left join public.transcripts t on t.id = f.transcript_id
                   where f.changed and f.created_at >= now() - make_interval(days => %s)
                   order by f.created_at desc limit %s""", (self.FEEDBACK_DAYS, self.FEEDBACK_LIMIT)).fetchall()
        return rubric, feedback

    @staticmethod
    def _read_documents(tenant_id: str, database: TenantDatabase) -> list[dict]:
        """The knowledge-base documents; none if the table or its content column has not been created yet."""
        try:
            with database.session(tenant_id) as connection:
                return connection.execute(
                    "select title, content from public.knowledge_base_docs where content is not null").fetchall()
        except (psycopg.errors.UndefinedTable, psycopg.errors.UndefinedColumn):
            logger.warning("knowledge_base_docs has no content column yet; continuing without policy documents")
            return []

    def _ask(self, findings: dict[str, dict]) -> dict[str, dict]:
        """Asks the qa_research network, again for just the missing checks if some were skipped."""
        keys: list[str] = list(findings)
        got: dict[str, dict] = {}
        pending: list[str] = list(keys)
        last_text: str = ""
        for attempt in range(1, self.ROUNDS + 1):
            logger.info("Asking the Neuro SAN network '%s' to improve checks (round %d of %d): %s",
                        self._neuro_san.network, attempt, self.ROUNDS, ", ".join(pending))
            returned: dict = self._neuro_san.run("Checks to work on: " + ", ".join(pending),
                                                 {"findings": {key: findings[key] for key in pending}})
            last_text = str(returned.get("text", ""))
            proposals: dict = (returned.get("sly_data") or {}).get("proposals") or {}
            if any(isinstance(value, dict) and value.get("demo") for value in proposals.values()):
                raise BridgeError("The Neuro SAN network returned DEMO proposals; the request did not carry the real findings")
            for key in pending:
                proposal = proposals.get(key)
                if isinstance(proposal, dict) and proposal.get("rules") and str(proposal.get("rationale") or "").strip():
                    got[key] = {"rules": [str(rule) for rule in proposal["rules"]], "rationale": str(proposal["rationale"]).strip()}
            pending = [key for key in keys if key not in got]
            if not pending:
                return got
        if got:
            logger.warning("No proposal for: %s", ", ".join(pending))
            return got
        raise BridgeError(f"The Neuro SAN network did not record any proposal after {self.ROUNDS} rounds. "
                          f"Its final answer was: {last_text[:200]!r}")
