"""Job handler for the chat assistant: builds the asker's data pack in code and lets the qa_assistant agent answer."""

import logging

from qa_engine.assistant_pack import AssistantPack
from qa_engine.bridge_error import BridgeError
from qa_engine.job_handler import JobHandler
from qa_engine.neuro_san_client import NeuroSanClient
from qa_engine.tenant_database import TenantDatabase

logger = logging.getLogger(__name__)


class ChatHandler(JobHandler):
    """Handles ``chat`` jobs. Payload: ``{"message_id": "<id of the user's chat_messages row>"}``."""

    kind: str = "chat"
    PERIOD_DAYS: int = 30
    AUDIT_LIMIT: int = 2000
    HISTORY_TURNS: int = 6
    MAX_QUESTION: int = 1000
    MAX_HISTORY_CHARS: int = 1500

    def __init__(self, neuro_san: NeuroSanClient, max_attempts: int = 3) -> None:
        """:param neuro_san: client for the qa_assistant agent network
        :param max_attempts: attempts after which the asker is told that no answer could be produced
        """
        self._neuro_san: NeuroSanClient = neuro_san
        self._max_attempts: int = max_attempts

    def handle(self, job: dict, database: TenantDatabase) -> None:
        """Answers one question and stores the answer as an assistant message.

        :raises LookupError: when the question cannot be found
        :raises BridgeError: when the agent network does not return a usable answer (the asker is told after the last attempt)
        """
        tenant_id: str = str(job["tenant_id"])
        message_id: str | None = (job.get("payload") or {}).get("message_id")
        if not message_id:
            raise LookupError(f"Job {job['id']} payload has no message_id")

        with database.session(tenant_id) as connection:
            question: dict | None = connection.execute(
                "select id, user_id, content from public.chat_messages where id = %s and role = 'user'", (message_id,)).fetchone()
            if question is None:
                raise LookupError(f"Chat message {message_id} not found for tenant {tenant_id}")
            history: list[dict] = connection.execute(
                """select role, content from public.chat_messages
                   where user_id = %s and created_at < (select created_at from public.chat_messages where id = %s)
                   order by created_at desc limit %s""", (question["user_id"], message_id, self.HISTORY_TURNS)).fetchall()
            rubric: dict | None = connection.execute("select parameters from public.rubrics where is_active").fetchone()
            audits: list[dict] = connection.execute(
                """select t.agent_name, a.overall_score, a.passed, a.critical_fail, a.scored_at, a.scores
                   from public.audit_scores a join public.transcripts t on t.id = a.transcript_id
                   where a.scored_at >= now() - make_interval(days => %s)
                   order by a.scored_at desc limit %s""", (self.PERIOD_DAYS, self.AUDIT_LIMIT)).fetchall()

        checks: list[dict] = [{"key": check.get("key"), "label": check.get("label"), "critical": check.get("critical")}
                              for check in ((rubric or {}).get("parameters") or {}).get("checks", [])]
        pack: dict = AssistantPack.build(audits, checks, f"last {self.PERIOD_DAYS} days")
        message: str = self._compose(list(reversed(history)), str(question["content"]))
        try:
            answer: str = self._ask(message, pack)
        except BridgeError as error:
            if job["attempts"] >= self._max_attempts:
                self._store(database, tenant_id, question, f"Sorry, I could not answer that. ({error})", "error")
            raise
        self._store(database, tenant_id, question, answer, "done")

    def _compose(self, history: list[dict], question: str) -> str:
        """The recent conversation (so follow-up questions make sense) followed by the question."""
        earlier: str = "\n".join(f"{'Supervisor' if row['role'] == 'user' else 'Assistant'}: {row['content']}" for row in history)
        parts: list[str] = []
        if earlier:
            parts.append("Conversation so far:\n" + earlier[-self.MAX_HISTORY_CHARS:])
        parts.append("Question: " + question[:self.MAX_QUESTION])
        return "\n\n".join(parts)

    def _ask(self, message: str, pack: dict) -> str:
        """Asks the qa_assistant network and checks that the answer is real."""
        returned: dict = self._neuro_san.run(message, {"pack": pack})
        if (returned.get("sly_data") or {}).get("demo"):
            raise BridgeError("The Neuro SAN network answered from DEMO data; the request did not carry the real data pack")
        answer: str = str(returned.get("text") or "").strip()
        if not answer or answer.lower().startswith(("error from", "error:")):
            raise BridgeError(f"The Neuro SAN network gave no usable answer: {answer[:200]!r}")
        return answer

    @staticmethod
    def _store(database: TenantDatabase, tenant_id: str, question: dict, content: str, status: str) -> None:
        """Writes the assistant's message for the asker and closes the question."""
        with database.session(tenant_id) as connection:
            connection.execute(
                """insert into public.chat_messages (tenant_id, user_id, role, content, status, reply_to)
                   values (%s, %s, 'assistant', %s, %s, %s)""", (tenant_id, question["user_id"], content, status, question["id"]))
            connection.execute("update public.chat_messages set status = %s where id = %s", (status, question["id"]))
        logger.info("Chat answer stored (%s)", status)
