"""HTTP client for the Neuro SAN server: runs the qa_audit agent network for one call."""

import json
import logging

import requests

from qa_engine.agent_trace import AgentTrace
from qa_engine.bridge_error import BridgeError

logger = logging.getLogger(__name__)


class NeuroSanClient:
    """Sends one request to an agent network and returns the ``sly_data`` the network handed back.

    The qa_audit network (registries/qa_audit.hocon) answers a request such as "Checks to run: compliance, closing"
    by delegating each check to an auditor agent. The auditors record their verdicts in ``sly_data["verdicts"]``,
    which the front man is allowed to return. The text of the final answer carries no data and is only logged.
    """

    CONNECT_TIMEOUT_SECONDS: int = 10
    READ_TIMEOUT_SECONDS: int = 1500  # one audit is ~13 on-device model calls and each can take 10 to 30 seconds

    def __init__(self, base_url: str, network: str = "qa_audit", trace: AgentTrace | None = None) -> None:
        """:param base_url: the Neuro SAN server, e.g. http://127.0.0.1:8080
        :param network: the agent network to run
        :param trace: where to write the conversation of the agents (default: the file named by QA_AGENT_TRACE_FILE, if any)
        """
        self._base_url: str = base_url.rstrip("/")
        self._network: str = network
        self._trace: AgentTrace = trace if trace is not None else AgentTrace.from_environment()

    @property
    def network(self) -> str:
        """The name of the agent network this client runs."""
        return self._network

    def run(self, message: str, sly_data: dict) -> dict:
        """Runs the network once.

        :param message: what the front man is told (the check keys to run)
        :param sly_data: private data for the coded tools; never shown to a model
        :return: the sly_data returned by the network (an empty dict if it returned none)
        :raises BridgeError: when the server is unreachable, answers with an error, or sends nothing usable
        """
        url: str = f"{self._base_url}/api/v1/{self._network}/streaming_chat"
        payload: dict = {"user_message": {"text": message}, "sly_data": sly_data}
        if self._trace.enabled:
            # Ask for every message of the run, not just the final one, so the conversation can be shown. The last message
            # (the final answer with the sly_data) is the same either way.
            payload["chat_filter"] = {"chat_filter_type": "MAXIMAL"}
            self._trace.begin(self._network, message)
        try:
            with requests.post(url, json=payload, stream=True,
                               timeout=(self.CONNECT_TIMEOUT_SECONDS, self.READ_TIMEOUT_SECONDS)) as response:
                response.raise_for_status()
                responses: list[dict] = self._read_stream(response, self._trace.message if self._trace.enabled else None)
        except requests.RequestException as error:
            logger.error("Neuro SAN call to %s failed: %s", url, error)
            raise BridgeError(f"Neuro SAN call to {url} failed: {error}") from error
        finally:
            if self._trace.enabled:
                self._trace.end(self._network)

        if not responses:
            raise BridgeError(f"Neuro SAN network '{self._network}' sent no response")
        final: dict = responses[-1]
        logger.info("Neuro SAN '%s' finished: %s", self._network, str(final.get("text") or "")[:200])
        return {"sly_data": final.get("sly_data") or {}, "text": str(final.get("text") or "")}

    @staticmethod
    def _read_stream(response: requests.Response, on_message=None) -> list[dict]:
        """Decodes the newline-delimited JSON stream into the ``response`` object of each message.

        :param on_message: called with each message as it arrives (used to show the agents' conversation live)
        """
        responses: list[dict] = []
        for raw in response.iter_lines():
            line: str = raw.decode("utf-8", errors="replace").strip() if isinstance(raw, bytes) else str(raw).strip()
            if not line:
                continue
            try:
                message: dict = json.loads(line)
            except json.JSONDecodeError as error:
                raise BridgeError(f"Neuro SAN sent a line that is not JSON: {line[:200]}") from error
            body: dict = message.get("response") if isinstance(message.get("response"), dict) else message
            responses.append(body)
            if on_message is not None:
                on_message(body)
        return responses
