"""Go/no-go test: how reliably does the model behind bridge.py handle tool calling?

Run it on the machine where the bridge and Chrome are running:

    python check_tool_calling.py          (20 rounds)
    python check_tool_calling.py 50       (50 rounds)

Each round plays the conversation Neuro SAN would have with an orchestrator that has three auditor sub-agents:
the model may call the auditors in one reply or over several, receives their (made-up) results, and must finish with
a final answer. A round is a success when every auditor was called exactly once and the model then answered.
It sends the same request format as Neuro SAN, so a pass here means the delegation step works with your Gemini Nano.
"""

import json
import statistics
import sys
import time

import requests


class ToolCallingCheck:
    """Plays the orchestrator conversation many times and reports how often the model gets it right."""

    BASE_URL: str = "http://127.0.0.1:8000"
    TIMEOUT_SECONDS: int = 300
    WARM_UP_SECONDS: int = 360
    MAX_TURNS: int = 6
    SYSTEM: str = (
        "You are the Lead QA Orchestrator. You receive a call to audit. Ask every auditor to evaluate it, "
        "then report their results."
    )
    TASK: str = (
        "Audit this call:\nAgent: Thank you for calling Horizon Telecom, this call is recorded. Could I have your PIN?\n"
        "Customer: It is 4821.\nAgent: Thanks. I have refunded the duplicate charge. Is there anything else?\n"
        "Customer: No, thank you.\nAgent: Goodbye."
    )
    AUDITORS: dict[str, str] = {
        "compliance_auditor": "Checks the recording disclosure and the caller's identity verification.",
        "resolution_auditor": "Checks that every customer issue was resolved or ticketed.",
        "closing_auditor": "Checks that the agent asked if anything else was needed and closed politely.",
    }
    RESULT: str = '{"passed": true, "reason": "Looks fine."}'

    @staticmethod
    def tools() -> list[dict]:
        """The three auditors in the format Neuro SAN sends: no parameters."""
        return [{"type": "function", "function": {"name": name, "description": description,
                                                   "parameters": {"properties": {}, "type": "object"}}}
                for name, description in ToolCallingCheck.AUDITORS.items()]

    @staticmethod
    def wait_for_model() -> None:
        """Waits until the bridge reports its model is loaded, so the one-off cold start is not counted as a failure."""
        deadline: float = time.time() + ToolCallingCheck.WARM_UP_SECONDS
        announced: bool = False
        while time.time() < deadline:
            try:
                response = requests.get(ToolCallingCheck.BASE_URL + "/health", timeout=10)
                if response.status_code == 404:
                    return  # an older bridge without /health: just start
                if response.ok and response.json().get("model_ready"):
                    return
            except (requests.RequestException, ValueError):
                return  # nothing is listening; the rounds will say so
            if not announced:
                print("Waiting for the model to finish loading (the first start can take a minute or two)...")
                announced = True
            time.sleep(5)

    @staticmethod
    def ask(messages: list[dict]) -> tuple[dict | None, float, str]:
        """Sends one request; returns (the assistant message or None, seconds taken, error text)."""
        started: float = time.time()
        try:
            response = requests.post(ToolCallingCheck.BASE_URL + "/v1/chat/completions",
                                     timeout=ToolCallingCheck.TIMEOUT_SECONDS, json={
                "model": "gemini-nano", "temperature": 0.0, "messages": messages, "tools": ToolCallingCheck.tools()})
            if response.status_code != 200:
                return None, time.time() - started, f"HTTP {response.status_code}: {response.text[:160]}"
            return response.json()["choices"][0]["message"], time.time() - started, ""
        except (requests.RequestException, KeyError, ValueError) as error:
            return None, time.time() - started, f"{type(error).__name__}: {str(error)[:140]}"

    @staticmethod
    def one_round() -> dict:
        """Plays one whole conversation and describes what happened."""
        messages: list[dict] = [{"role": "system", "content": ToolCallingCheck.SYSTEM},
                                {"role": "user", "content": ToolCallingCheck.TASK}]
        calls_per_turn: list[int] = []
        times_called: dict[str, int] = {}
        seconds: float = 0.0
        outcome: dict = {"ok": False, "error": "", "calls_per_turn": calls_per_turn, "seconds": 0.0, "connection": False}

        for _ in range(ToolCallingCheck.MAX_TURNS):
            message, taken, error = ToolCallingCheck.ask(messages)
            seconds += taken
            outcome["seconds"] = seconds
            if message is None:
                outcome["error"] = error
                outcome["connection"] = error.startswith(("ConnectionError", "ConnectTimeout"))
                return outcome

            calls: list[dict] = message.get("tool_calls") or []
            if not calls:
                missing: list[str] = [name for name in ToolCallingCheck.AUDITORS if name not in times_called]
                repeated: list[str] = [name for name, count in times_called.items() if count > 1]
                if not (message.get("content") or "").strip():
                    outcome["error"] = "empty reply"
                elif missing:
                    outcome["error"] = f"answered without calling: {', '.join(missing)}"
                elif repeated:
                    outcome["error"] = f"called more than once: {', '.join(repeated)}"
                else:
                    outcome["ok"] = True
                return outcome

            calls_per_turn.append(len(calls))
            messages.append(message)
            for call in calls:
                name: str = call["function"]["name"]
                times_called[name] = times_called.get(name, 0) + 1
                messages.append({"role": "tool", "tool_call_id": call["id"], "content": ToolCallingCheck.RESULT})

        outcome["error"] = f"no final answer after {ToolCallingCheck.MAX_TURNS} turns"
        return outcome

    @staticmethod
    def main() -> None:
        """Runs the rounds and prints a verdict."""
        # Windows error messages are localized (e.g. Portuguese) and the console codepage may not be able to print them.
        sys.stdout.reconfigure(errors="replace")
        rounds: int = int(sys.argv[1]) if len(sys.argv) > 1 else 20
        ToolCallingCheck.wait_for_model()
        print(f"Playing {rounds} rounds against {ToolCallingCheck.BASE_URL} (each takes a few seconds)...\n")
        outcomes: list[dict] = []
        for number in range(1, rounds + 1):
            outcome = ToolCallingCheck.one_round()
            outcomes.append(outcome)
            shape: str = " + ".join(str(n) for n in outcome["calls_per_turn"]) or "no"
            detail: str = f"calls per turn: {shape}" + (f"  | {outcome['error']}" if outcome["error"] else "")
            print(f"  round {number:>2}: {'ok  ' if outcome['ok'] else 'FAIL'} {outcome['seconds']:5.1f}s  {detail}")

        if all(o["connection"] for o in outcomes):
            print("\nCould not reach the bridge, so nothing was tested. Start the engine (start_all.bat), wait until the"
                  "\nBridge window says it connected to Chrome, and run this again.")
            return

        ok: int = sum(o["ok"] for o in outcomes)
        in_one_reply: int = sum(o["ok"] and o["calls_per_turn"][:1] == [len(ToolCallingCheck.AUDITORS)] for o in outcomes)
        print(f"\nComplete, correct delegations:        {ok} of {rounds}")
        print(f"  of which all three in one reply:    {in_one_reply}")
        print(f"  of which spread over several turns: {ok - in_one_reply}")
        print(f"Median time per round: {statistics.median(o['seconds'] for o in outcomes):.1f}s")
        rate: float = ok / rounds
        if rate >= 0.95:
            print("\nVERDICT: GO. The model handles tool calling reliably enough to build on.")
        elif rate >= 0.75:
            print("\nVERDICT: RISKY. It works most of the time. Tell the assistant the failure messages above;"
                  " stricter prompts or a retry may be enough.")
        else:
            print("\nVERDICT: NO-GO for Gemini Nano as the orchestrator. Tell the assistant the failure messages above.")
        print("\n" + json.dumps({"rounds": rounds, "ok": ok, "in_one_reply": in_one_reply}))


if __name__ == "__main__":
    ToolCallingCheck.main()
