"""Entry point for the audit worker: python worker.py"""

import logging

from qa_engine.handler_factory import HandlerFactory
from qa_engine.job_worker import JobWorker
from qa_engine.runner_factory import RunnerFactory
from qa_engine.settings import Settings


class WorkerApp:
    """Wires configuration to the worker and runs it."""

    @staticmethod
    def main() -> None:
        """Starts the worker loop; stop with Ctrl+C.

        Settings (all optional except DATABASE_URL): AUDIT_BACKEND and the Neuro SAN addresses (see RunnerFactory and
        HandlerFactory), and AUDIT_EXAMPLES_PER_CHECK (default 2): how many reviewer-corrected examples each audit
        check is shown; 0 turns the learning examples off.
        """
        logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
        settings = Settings()
        worker = JobWorker(settings.require("DATABASE_URL"), RunnerFactory.create(settings), HandlerFactory.create(settings),
                           int(settings.get("AUDIT_EXAMPLES_PER_CHECK", "2")))
        try:
            worker.run_forever()
        except KeyboardInterrupt:
            logging.getLogger(__name__).info("Worker stopped")


if __name__ == "__main__":
    WorkerApp.main()
