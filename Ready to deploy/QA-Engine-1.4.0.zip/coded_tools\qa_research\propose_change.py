"""Coded tool of the qa_research network: records the advisor agent's proposed new rules for one check."""

import logging
import re
from typing import Any

from neuro_san.interfaces.coded_tool import CodedTool

logger = logging.getLogger(__name__)


class ProposeChange(CodedTool):
    """Stores ``{rules, rationale}`` under ``sly_data["proposals"][check_key]``.

    Nothing here changes a rubric. The audit worker files each proposal as a pending change request, and an admin
    approves or rejects it in the dashboard.
    """

    MIN_RULES: int = 1
    MAX_RULES: int = 8
    MIN_RULE_LENGTH: int = 15
    MAX_RULE_LENGTH: int = 700
    MAX_RATIONALE: int = 700
    LIST_MARKER: re.Pattern[str] = re.compile(r"^\s*(?:[-*•]|\d+[.)])\s+")  # "- ", "* ", "1. ", "2) "

    async def async_invoke(self, args: dict[str, Any], sly_data: dict[str, Any]) -> str:
        """Validates and records one proposal.

        :param args: ``check_key``, ``rules`` (the COMPLETE new list, as a list or one rule per line) and ``rationale``
        :param sly_data: the request's bulletin board; must hold ``findings``
        :return: a confirmation, or a message that tells the advisor what to fix so it can call again
        """
        check_key: str = str(args.get("check_key") or "").strip()
        findings: dict[str, Any] = sly_data.get("findings") or {}
        if check_key not in findings:
            return f"There is no check called '{check_key}'. Valid check keys: {', '.join(sorted(findings)) or '(none)'}."

        raw: Any = args.get("rules")
        items: list[Any] = raw if isinstance(raw, list) else str(raw or "").splitlines()
        rules: list[str] = [self.LIST_MARKER.sub("", str(item)).strip() for item in items]
        rules = [rule for rule in rules if rule]
        if not (self.MIN_RULES <= len(rules) <= self.MAX_RULES):
            return f"Give between {self.MIN_RULES} and {self.MAX_RULES} rules. Call propose_change again."
        too_short: list[str] = [rule for rule in rules if len(rule) < self.MIN_RULE_LENGTH]
        if too_short:
            return f"Each rule must be a full sentence. These are too short: {too_short[0]!r}. Call propose_change again."
        rationale: str = str(args.get("rationale") or "").strip()[:self.MAX_RATIONALE]
        if not rationale:
            return "Explain in the rationale why the new rules would have prevented the mistakes. Call propose_change again."

        proposal: dict[str, Any] = {"rules": [rule[:self.MAX_RULE_LENGTH] for rule in rules], "rationale": rationale}
        if sly_data.get("demo"):
            proposal["demo"] = True  # the audit worker refuses demo proposals
        sly_data.setdefault("proposals", {})[check_key] = proposal
        logger.info("propose_change: %d rules proposed for %s", len(rules), check_key)
        return f"Recorded the proposal for {check_key}."
