"""Parses a small model's answer into a strict {passed, reason} verdict."""

import json
import logging
import re

logger = logging.getLogger(__name__)


class VerdictParser:
    """Turns raw model text into a verdict. Anything unusable is a failed check, never a silent pass."""

    FENCE_PATTERN: str = r"^```json\s*|^```\s*|```$"
    PLACEHOLDER_REASONS: frozenset[str] = frozenset({"", "none", "null", "n/a", "na", "-"})

    @staticmethod
    def parse(raw_text: str) -> dict:
        """Parses model output.

        A verdict passes only when 'passed' is the JSON boolean true (or the string "true"). Unparseable output
        fails with an explicit reason so a human can see why, instead of the old keyword guess that could pass it.

        :param raw_text: model output, possibly wrapped in Markdown code fences
        :return: {"passed": bool, "reason": str}
        """
        clean: str = re.sub(VerdictParser.FENCE_PATTERN, "", raw_text, flags=re.MULTILINE).strip()
        try:
            data: dict = json.loads(clean)
        except json.JSONDecodeError:
            logger.warning("Model output was not valid JSON: %s", clean[:200])
            return VerdictParser._recover(clean)
        if not isinstance(data, dict):
            return {"passed": False, "reason": "UNPARSEABLE_MODEL_OUTPUT: " + clean[:300]}

        return VerdictParser.from_record(data)

    @staticmethod
    def from_record(record: object) -> dict:
        """Normalizes a verdict that is already structured, for example one recorded by an agent.

        The same strictness as parse(): a check passes only on an explicit true, and anything unusable fails visibly.

        :param record: {"passed": ..., "reason": ...}
        :return: {"passed": bool, "reason": str}
        """
        if not isinstance(record, dict):
            return {"passed": False, "reason": "UNPARSEABLE_VERDICT: " + str(record)[:300]}
        passed_value = record.get("passed")
        passed: bool = passed_value is True or (isinstance(passed_value, str) and passed_value.strip().lower() == "true")
        return {"passed": passed, "reason": VerdictParser._clean_reason(record.get("reason"))}

    @staticmethod
    def _clean_reason(value: object) -> str:
        """Turns a missing or placeholder reason (null, "None", "N/A") into an empty string.

        A passed check has nothing to cite, and small models then write "None" or "N/A". Stored as text, that
        misleads reviewers into thinking it is a real explanation.
        """
        if value is None:
            return ""
        text: str = str(value).strip()
        return "" if text.lower() in VerdictParser.PLACEHOLDER_REASONS else text

    @staticmethod
    def _recover(clean: str) -> dict:
        """Salvages a verdict from almost-JSON, e.g. unescaped quotes inside the reason text.

        Only an explicit "passed": true/false token is trusted; without one the check fails as UNPARSEABLE.
        """
        passed_match = re.search(r'"passed"\s*:\s*(true|false)', clean, flags=re.IGNORECASE)
        if passed_match is None:
            return {"passed": False, "reason": "UNPARSEABLE_MODEL_OUTPUT: " + clean[:300]}
        reason_match = re.search(r'"reason"\s*:\s*"(.*)"\s*\}?\s*$', clean, flags=re.DOTALL)
        reason: str = VerdictParser._clean_reason(reason_match.group(1)) if reason_match else clean[:300]
        return {"passed": passed_match.group(1).lower() == "true", "reason": reason}
