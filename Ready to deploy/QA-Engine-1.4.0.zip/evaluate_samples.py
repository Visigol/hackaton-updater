"""Regression test for the audit: runs the mock calls through the real engine and compares with the gold answers.

    python evaluate_samples.py                 (each sample once)
    python evaluate_samples.py --runs 3        (each sample three times: also measures consistency)
    python evaluate_samples.py --only Anna     (just the samples whose name contains "Anna")

It uses the same engine as the worker (AUDIT_BACKEND, NEURO_SAN_URL, ...), so start the engine first (start_all.bat).
The files are in the evaluation folder: rubric.json (what is audited), gold.json (the expected verdicts) and samples/.
Run it after every change to the rubric, the prompts, the agents or the bridge, and keep the numbers.
"""

import argparse
import json
import logging
import sys
import time
from pathlib import Path

from qa_engine.runner_factory import RunnerFactory
from qa_engine.settings import Settings


class SampleEvaluation:
    """Compares audit results with the gold answers and prints the accuracy measures."""

    @staticmethod
    def load(folder: Path) -> tuple[dict, dict, list[dict]]:
        """Reads the rubric, the gold answers and the samples.

        :param folder: the evaluation folder
        :return: (rubric, gold by sample id, samples as {"id", "agent", "transcript"})
        """
        rubric: dict = json.loads((folder / "rubric.json").read_text(encoding="utf-8"))
        gold: dict = {key: value for key, value in json.loads((folder / "gold.json").read_text(encoding="utf-8")).items()
                      if not key.startswith("_")}
        samples: list[dict] = []
        for path in sorted((folder / "samples").glob("*.json")):
            record: dict = json.loads(path.read_text(encoding="utf-8"))
            samples.append({"id": record["id"], "agent": record.get("agent_id", ""), "transcript": record["raw_transcript"]})
        return rubric, gold, samples

    @staticmethod
    def compare(result: dict, expected: dict, check_keys: list[str]) -> dict:
        """Compares one audit result with its gold entry.

        :param result: the AuditRunner result
        :param expected: the gold entry ({"critical": bool, "<check key>": [acceptable values]})
        :param check_keys: the rubric's check keys
        :return: {"verdicts": {key: {"got", "ok"}}, "critical_got", "critical_ok", "pattern"}
        """
        verdicts: dict[str, dict] = {}
        for key in check_keys:
            got: bool = bool(result["scores"].get(key, {}).get("passed"))
            verdicts[key] = {"got": got, "ok": got in expected.get(key, [])}
        critical_got: bool = bool(result.get("critical_fail"))
        return {"verdicts": verdicts, "critical_got": critical_got,
                "critical_ok": critical_got == bool(expected.get("critical")),
                "pattern": "".join("P" if verdicts[key]["got"] else "F" for key in check_keys),
                "score": result.get("overall_score")}

    @staticmethod
    def summarize(rows: list[dict]) -> dict:
        """Computes the accuracy measures from the compared rows.

        :param rows: compare() outputs, each with "sample", "run" and "expected_critical" added
        :return: verdict agreement, critical catch rate, false-alarm rate and consistency
        """
        verdict_total: int = sum(len(row["verdicts"]) for row in rows)
        verdict_ok: int = sum(v["ok"] for row in rows for v in row["verdicts"].values())
        should_be_critical: list[dict] = [row for row in rows if row["expected_critical"]]
        should_not: list[dict] = [row for row in rows if not row["expected_critical"]]
        patterns: dict[str, set[str]] = {}
        for row in rows:
            patterns.setdefault(row["sample"], set()).add(row["pattern"])
        repeated: list[set[str]] = [p for sample, p in patterns.items() if sum(r["sample"] == sample for r in rows) > 1]
        return {
            "verdict_agreement": (verdict_ok, verdict_total),
            "critical_caught": (sum(row["critical_got"] for row in should_be_critical), len(should_be_critical)),
            "false_alarms": (sum(row["critical_got"] for row in should_not), len(should_not)),
            "consistent_samples": (sum(len(p) == 1 for p in repeated), len(repeated)),
        }

    @staticmethod
    def evaluate(runner: object, rubric: dict, gold: dict, samples: list[dict], runs: int, only: str = "") -> list[dict]:
        """Audits every selected sample `runs` times and compares each result with the gold answers."""
        check_keys: list[str] = [check["key"] for check in rubric["checks"]]
        rows: list[dict] = []
        for sample in samples:
            expected: dict = gold.get(sample["id"])
            if expected is None or only.lower() not in expected["name"].lower():
                continue
            for run in range(1, runs + 1):
                started: float = time.time()
                row: dict = SampleEvaluation.compare(runner.run(sample["transcript"], rubric), expected, check_keys)
                row.update({"sample": expected["name"], "run": run, "expected_critical": bool(expected.get("critical")),
                            "seconds": time.time() - started})
                rows.append(row)
                print(SampleEvaluation.format_row(row, check_keys))
        return rows

    @staticmethod
    def format_row(row: dict, check_keys: list[str]) -> str:
        """One line per audit: which verdicts matched the gold answer."""
        marks: str = "  ".join(f"{key}={'P' if row['verdicts'][key]['got'] else 'F'}{'' if row['verdicts'][key]['ok'] else ' (WRONG)'}"
                               for key in check_keys)
        critical: str = "critical fail" if row["critical_got"] else "no critical fail"
        flag: str = "" if row["critical_ok"] else "  <-- WRONG critical outcome"
        return f"  {row['sample']:<38} run {row['run']}: {marks}  | score {row['score']}, {critical}{flag}  ({row['seconds']:.0f}s)"

    @staticmethod
    def report(summary: dict) -> None:
        """Prints the measures in plain words."""
        ok, total = summary["verdict_agreement"]
        print(f"\nVerdicts that match the gold answers:  {ok} of {total}  ({100 * ok // total if total else 0}%)")
        caught, should = summary["critical_caught"]
        print(f"Critical fails caught:                 {caught} of {should}   (anything below 100% is serious)")
        alarms, clean = summary["false_alarms"]
        print(f"False critical alarms:                 {alarms} of {clean}")
        stable, repeated = summary["consistent_samples"]
        if repeated:
            print(f"Samples with identical verdicts on every run: {stable} of {repeated}")

    @staticmethod
    def main() -> None:
        """Runs the evaluation against the real engine."""
        sys.stdout.reconfigure(errors="replace")  # Windows consoles may not print every character
        parser = argparse.ArgumentParser(description="Audit the mock calls and compare with the gold answers.")
        parser.add_argument("--runs", type=int, default=1, help="how many times to audit each sample")
        parser.add_argument("--only", default="", help="only samples whose name contains this text")
        parser.add_argument("--folder", default="evaluation", help="the evaluation folder")
        args = parser.parse_args()

        logging.basicConfig(level=logging.WARNING)
        rubric, gold, samples = SampleEvaluation.load(Path(args.folder))
        runner = RunnerFactory.create(Settings())
        print(f"Auditing {len(samples)} sample(s) x {args.runs} run(s). Each audit takes a few minutes on the agent network.\n")
        rows = SampleEvaluation.evaluate(runner, rubric, gold, samples, args.runs, args.only)
        if rows:
            SampleEvaluation.report(SampleEvaluation.summarize(rows))
        else:
            print("No sample matched.")


if __name__ == "__main__":
    SampleEvaluation.main()
