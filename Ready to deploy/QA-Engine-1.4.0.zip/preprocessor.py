import re
from typing import Dict

class DeterministicSanitizer:
    @staticmethod
    def mask_pii(text: str) -> str:
        """Regex scrubbing to ensure zero local leakage of sensitive data."""
        text = re.sub(r'\b(?:\d[ -]*?){13,16}\b', '[REDACTED_PCI_CARD]', text)
        text = re.sub(r'\b\d{3}-\d{2}-\d{4}\b', '[REDACTED_SSN]', text)
        text = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '[REDACTED_EMAIL]', text)
        text = re.sub(r'\b(?:\+?1[-.]?)?\(?[0-9]{3}\)?[-. ]?[0-9]{3}[-. ]?[0-9]{4}\b', '[REDACTED_PHONE]', text)
        return text

    @staticmethod
    def slice_transcript(raw_text: str) -> Dict[str, str]:
        """Slices conversation to minimize token context load."""
        lines = [line.strip() for line in raw_text.strip().split("\n") if line.strip()]
        return {
            "opening": "\n".join(lines[:6]),
            "closing": "\n".join(lines[-5:]),
            "full_clean": "\n".join(lines)
        }