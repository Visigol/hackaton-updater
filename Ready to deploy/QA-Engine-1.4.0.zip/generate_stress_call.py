import json
import time
import os

os.makedirs("./inbox", exist_ok=True)

LONG_CALL_TRANSCRIPT = """
Agent: Thank you for calling Horizon Telecom Priority Support. My name is Connor. Please be advised that this call may be recorded for quality and training purposes.
Customer: Hi Connor. Look, I'm really frustrated. I just landed back at O'Hare from an anniversary trip down in Cabo San Lucas, Mexico with my wife, and my phone bill is completely insane. It's almost three hundred dollars higher than normal!
Agent: I certainly understand how frustrating unexpected charges can be, especially right after coming back from an anniversary vacation. Congratulations on the anniversary, by the way! How was Cabo?
Customer: Cabo was fantastic until I opened this email from you guys. The resort was beautiful, but the weather on Wednesday had this freak rainstorm. Anyway, I opened my billing app while waiting at baggage claim, and I see an $85 international roaming charge, plus a $35 charge for some 'Cloud Backup Extra' package that I have never in my life agreed to.
Agent: Let me pull up your statement details right here. Yes, looking at the cellular data log from October 8th through the 12th, there were three separate data bursts triggered on the local Mexican carrier towers, totaling $85 in roaming fees.
Customer: That's ridiculous! The sales rep at your downtown store told me that international roaming was included in my Unlimited Platinum tier.
Agent: I see that note on the account. But before we go any further into adjusting these fees, I need to complete our mandatory security authentication. Could I get your account number and registered phone number?
Customer: Sure, the phone number is 312-555-0188, and the account number is ACT-884109.
Agent: Thank you. And for verification, could you provide your 4-digit security PIN?
Customer: Oh man, I don't remember the PIN. My wife set that up three years ago. Look, my credit card is 4111-2222-3333-4444 and my SSN is 000-88-1234. Can't you just verify it that way?
Agent: Please don't read your card numbers over the phone, sir. Since you don't have the PIN, what is your mother's maiden name?
Customer: It's Gallagher.
Agent: Alright, that matches what I see on the backup screen. Identity verified. Now, regarding that $85 roaming fee: because our sales representative gave you incorrect information regarding Mexico roaming coverage on your plan, I am applying a one-time courtesy credit of $85 to your current balance right now.
Customer: Okay, thank you Connor. That's a huge relief. Now, what about that $35 'Cloud Backup Extra' charge?
Agent: Let me check the add-on history. It looks like that was enrolled during an automatic promotional trial six months ago when you upgraded your device.
Customer: I never used a single megabyte of cloud backup. I use Google Drive for all my photos and documents. I want that canceled immediately, and I want that $35 credited back as well.
Agent: I see where you're coming from. Unfortunately, my system does not give me the authorization to refund cloud subscriptions older than 30 days. However, I have left an internal flag on the account profile so our Tier 2 billing desk can review the enrollment log.
Customer: So is it canceled? Will I be charged again next month on the first?
Agent: They will review the log when they get to the queue and determine if the cancellation can be backdated.
Customer: Wait, that doesn't answer my question. If they don't get to it, do I get billed another $35?
Agent: Our back-office team processes requests sequentially during normal business hours. You should monitor your email for their determination.
Customer: Well, can you give me a ticket or case number so I can reference this when I call back?
Agent: It's tagged under your account phone number, so any agent will be able to see the notes.
Customer: I really prefer to have a concrete ticket ID, Connor.
Agent: The general notes work the same way as a ticket in our modern system. You're all taken care of with the $85 credit today. Thank you for calling Horizon Telecom. Have a good evening.
Customer: Wait, but what about—
"""

call_payload = {
    "id": f"stress-call-10min-{int(time.time())}",
    "tenant_id": "tenant-boltverse",
    "agent_id": "AGT-CONNOR-99",
    "customer_id": "CUST-CABO-312",
    "call_duration_seconds": 612,  # 10 minutes, 12 seconds
    "raw_transcript": LONG_CALL_TRANSCRIPT.strip()
}

output_path = f"./inbox/stress_test_{int(time.time())}.json"
with open(output_path, "w", encoding="utf-8") as f:
    json.dump(call_payload, f, indent=2)

print(f"[OK] Injected 10-minute test payload into '{output_path}'")
print(f"Transcript size: {len(LONG_CALL_TRANSCRIPT.split())} words, {len(LONG_CALL_TRANSCRIPT)} characters.")