"""Dashboard JavaScript, part 1: helpers, data loading, overview charts, audits table and the detail drawer.

Part 2 (dashboard_js_admin.py) continues the same function scope, so the two strings must be concatenated.
"""

JS_CORE = r"""
(() => {
'use strict';
const db = supabase.createClient(APP_CONFIG.supabaseUrl, APP_CONFIG.supabaseAnonKey);
const PAGE_SIZE = 12;
const PERM_HELP = 'Your database needs the one-time setup in supabase/admin_setup.sql before this is allowed.';
const state = {
  session: null, me: null, tenant: null, rubrics: [], rows: [], range: '30', search: '', status: 'all',
  sort: 'date_desc', page: 1, view: 'overview', selected: new Set(), drawerId: null, drawerBusy: false,
  requested: new Map(), // transcript id -> {baseline, at}: re-audits asked for from this page, until a new score arrives
};
const REQUEST_TTL_MS = 30 * 60 * 1000;
const $ = (selector) => document.querySelector(selector);

const VIEWS = {
  overview: { title: 'Overview', icon: 'overview', subtitle: 'How your contact center is performing', filters: true, who: 'all' },
  audits: { title: 'Audits', agentTitle: 'My audits', icon: 'list', subtitle: 'Consult, review, re-run and delete audits', agentSubtitle: 'Your results and the reasons behind them', filters: true, who: 'all' },
  new: { title: 'New audit', icon: 'plus', subtitle: 'Upload transcripts to be scored against your rubric', who: 'staff' },
  reviews: { title: 'Reviews', agentTitle: 'My requests', icon: 'shield', subtitle: 'Results that agents contested and requests for a new audit', agentSubtitle: 'Results you contested and re-audits you asked for', who: 'all' },
  reports: { title: 'Reports', icon: 'chart', subtitle: 'Coaching reports written by the performance agent', agentSubtitle: 'Your coaching reports', who: 'all' },
  learning: { title: 'Learning', icon: 'spark', subtitle: 'Where reviewers corrected the AI, and what it is learning from them', who: 'staff' },
  assistant: { title: 'Assistant', icon: 'chat', subtitle: 'Ask questions about your results', who: 'staff' },
  rubric: { title: 'Rubric', icon: 'sliders', subtitle: 'Edit the checks the AI audits against and review proposed changes', who: 'admin' },
  users: { title: 'Users & roles', icon: 'users', subtitle: 'Add people, change roles, reset passwords', who: 'admin' },
  knowledge: { title: 'Knowledge base', icon: 'book', subtitle: 'Policy documents the research agent reads to propose better rules', who: 'admin' },
  data: { title: 'Data & settings', icon: 'download', subtitle: 'Export your data and manage your organization', who: 'all' },
};
// Who may open a view: everyone, staff (admin, supervisor, team lead) or admins only.
const allowed = (view) => !!VIEWS[view] && (VIEWS[view].who === 'all' || (VIEWS[view].who === 'staff' && canWrite()) || (VIEWS[view].who === 'admin' && isAdmin()));
const viewTitle = (view) => (!canWrite() && VIEWS[view].agentTitle) || VIEWS[view].title;
const viewSubtitle = (view) => (!canWrite() && VIEWS[view].agentSubtitle) || VIEWS[view].subtitle;

const ICONS = {
  overview: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  redo: '<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6"/>',
  check: '<path d="M5 12l5 5L20 7"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  alert: '<path d="M12 3l10 18H2L12 3z"/><path d="M12 10v5M12 18h.01"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
  upload: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
  sliders: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M18 14.5a6.5 6.5 0 0 1 3.5 5.5"/>',
  download: '<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16v4zM13.5 6.5l4 4"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/>',
  up: '<path d="M6 15l6-6 6 6"/>',
  down: '<path d="M6 9l6 6 6-6"/>',
  chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L3 21l1.9-5.4A8 8 0 1 1 21 12z"/>',
  book: '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2V5z"/><path d="M19 17H6"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
  spark: '<path d="M12 3l2.2 5.8L20 11l-5.8 2.2L12 19l-2.2-5.8L4 11l5.8-2.2L12 3z"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/><path d="M9 12l2 2 4-4"/>',
};

// ---- tiny DOM helpers. All text goes through textContent / text nodes, never innerHTML.
function h(tag, props = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (value === null || value === undefined || value === false) continue;
    if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
    else node.setAttribute(key, value === true ? '' : value);
  }
  for (const child of children.flat()) {
    if (child === null || child === undefined || child === false) continue;
    node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return node;
}
function svgEl(tag, attrs = {}, ...children) {
  const node = document.createElementNS('http://www.w3.org/2000/svg', tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (typeof value === 'string' && value.startsWith('var(')) node.style.setProperty(key, value);
    else node.setAttribute(key, value);
  }
  for (const child of children) node.append(child);
  return node;
}
function icon(name, size = 18) {
  const span = document.createElement('span');
  span.className = 'ico';
  // ICONS holds trusted constants only.
  span.innerHTML = '<svg viewBox="0 0 24 24" width="' + size + '" height="' + size + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[name] || '') + '</svg>';
  return span;
}
const fmtDate = (value) => new Date(value).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
const fmtDateTime = (value) => new Date(value).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
function ago(value) {
  const seconds = Math.max(1, Math.round((Date.now() - new Date(value)) / 1000));
  if (seconds < 60) return 'just now';
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return minutes + ' min ago';
  const hours = Math.round(minutes / 60);
  if (hours < 24) return hours + ' h ago';
  return Math.round(hours / 24) + ' d ago';
}
const pct = (part, whole) => (whole ? Math.round((part / whole) * 100) : 0);
const initials = (name) => (String(name).split(/[\s_-]+/).filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('') || '?');
const canWrite = () => !!state.me && state.me.role !== 'agent';
const isAdmin = () => !!state.me && state.me.role === 'admin';
const nice = (key) => String(key).replace(/[_-]+/g, ' ').replace(/^./, (c) => c.toUpperCase());

function toast(message, kind = 'info') {
  const node = h('div', { class: 'toast ' + kind, role: 'status' }, message);
  $('#toasts').append(node);
  setTimeout(() => node.classList.add('out'), 4200);
  setTimeout(() => node.remove(), 4700);
}
function showAlert(message) { const box = $('#alert'); box.textContent = message; box.hidden = false; }
function hideAlert() { $('#alert').hidden = true; }

function showTip(event, value, label, detail) {
  const tip = $('#tip');
  tip.replaceChildren(h('strong', { text: value }), h('span', { text: label }), detail ? h('span', { class: 'tip-detail', text: detail }) : null);
  tip.hidden = false;
  const pad = 14;
  let x = event.clientX + pad, y = event.clientY + pad;
  if (x + tip.offsetWidth > window.innerWidth - 8) x = event.clientX - tip.offsetWidth - pad;
  if (y + tip.offsetHeight > window.innerHeight - 8) y = event.clientY - tip.offsetHeight - pad;
  tip.style.transform = 'translate(' + Math.max(8, x) + 'px,' + Math.max(8, y) + 'px)';
}
const hideTip = () => { $('#tip').hidden = true; };
// A tooltip must never outlive the element that opened it: the lists re-render every few seconds, and a removed
// element never sends "pointer left". Elements that own a tooltip carry data-tip; anywhere else hides it.
document.addEventListener('pointermove', (event) => {
  if (!$('#tip').hidden && !(event.target.closest && event.target.closest('[data-tip]'))) hideTip();
});
document.addEventListener('scroll', hideTip, true);
window.addEventListener('blur', hideTip);
document.documentElement.addEventListener('pointerleave', hideTip);

function confirmDialog(title, message, confirmLabel = 'Confirm', danger = false) {
  return new Promise((resolve) => {
    const dialog = h('dialog', {},
      h('form', { method: 'dialog' }, h('h3', { text: title }), h('p', { text: message }),
        h('div', { class: 'row' },
          h('button', { class: 'btn', value: 'cancel', text: 'Cancel' }),
          h('button', { class: 'btn primary' + (danger ? ' danger' : ''), value: 'ok', text: confirmLabel }))));
    dialog.addEventListener('close', () => { resolve(dialog.returnValue === 'ok'); dialog.remove(); });
    document.body.append(dialog);
    dialog.showModal();
  });
}

// Best-effort audit trail entry. The database stamps tenant and actor; a logging failure never blocks the action.
async function logActivity(action, detail = {}) {
  try { await db.from('audit_trail').insert({ action, detail, actor_email: state.me ? state.me.email : null }); } catch (error) { /* log is best effort */ }
}

async function api(method, path, body) {
  const { data } = await db.auth.getSession();
  if (!data.session) { window.location.href = '/'; throw new Error('Session expired'); }
  const response = await fetch(path, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + data.session.access_token },
    body: body ? JSON.stringify(body) : undefined,
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = Array.isArray(payload.detail) ? payload.detail.map((d) => d.msg).join('; ') : payload.detail;
    throw new Error(detail || 'Request failed (' + response.status + ')');
  }
  return payload;
}

// ---- status model
const STATUS = {
  pass: { label: 'Passed', icon: 'check', color: 'var(--good)' },
  fail: { label: 'Failed', icon: 'x', color: 'var(--serious)' },
  critical: { label: 'Critical fail', icon: 'alert', color: 'var(--critical)' },
  queued: { label: 'Queued', icon: 'clock', color: 'var(--muted)' },
  running: { label: 'Auditing', icon: 'redo', color: 'var(--accent)' },
  error: { label: 'Error', icon: 'alert', color: 'var(--critical)' },
  unaudited: { label: 'Not audited', icon: 'clock', color: 'var(--muted)' },
  needsReview: { label: 'Needs review', icon: 'alert', color: 'var(--critical)' },
  reaudit: { label: 'Re-auditing', icon: 'redo', color: 'var(--accent)' },
  reauditError: { label: 'Re-audit failed', icon: 'alert', color: 'var(--critical)' },
};
// What the pipeline shows for a row: a scored row with a new job in flight is "re-auditing".
const pipelineStatus = (row) => (row.audit ? (row.inFlight ? 'reaudit' : 'reauditError') : row.status);
const inPipeline = (row) => ['queued', 'running', 'error', 'unaudited'].includes(row.status) || row.inFlight || row.reauditFailed;
function badge(status) {
  const meta = STATUS[status];
  const node = h('span', { class: 'badge' }, icon(meta.icon, 14), meta.label);
  node.style.setProperty('--c', meta.color);
  return node;
}

// ---- data
const activeRubric = () => state.rubrics.find((r) => r.is_active) || null;
const rubricFor = (version) => state.rubrics.find((r) => r.version === version) || activeRubric();
const threshold = () => { const r = activeRubric(); return r && r.parameters && r.parameters.pass_threshold !== undefined ? Number(r.parameters.pass_threshold) : 80; };

// The audit engine flags a critical fail it could not back up with a quote of the agent (see CriticalGuard): a person decides.
// Once someone saves a review the flags are recalculated, so this clears itself.
const reviewFlags = (audit) => ((audit && audit.flags) || []).filter((f) => String(f).startsWith('NEEDS_REVIEW'));
function reviewReason(flag) {
  const parts = String(flag).replace(/^NEEDS_REVIEW:\s*/, '').split(': ');
  return { label: parts[0] || 'Check', text: parts.slice(1).join(': ').replace(/^critical fail not supported by a quote of the agent:\s*/, '') };
}

function buildRow(transcript, jobs) {
  const audits = (transcript.audit_scores || []).slice().sort((a, b) => new Date(b.scored_at) - new Date(a.scored_at));
  const audit = audits[0] || null;
  // A scored row can still have a NEW job waiting (a re-audit), so look at every job, not just the latest.
  const open = jobs.filter((j) => !['done', 'failed'].includes(j.status));
  const finished = jobs.filter((j) => j.status === 'done');
  const failed = jobs.filter((j) => j.status === 'failed').sort((a, b) => String(b.finished_at || '').localeCompare(String(a.finished_at || '')));
  // Failed after the current score: the re-audit did not work.
  const failedAfterAudit = !!(audit && failed[0] && failed[0].finished_at && new Date(failed[0].finished_at) > new Date(audit.scored_at));
  // Asked for from this page and the score has not changed yet: still pending, whatever status the job reports.
  const request = state.requested.get(transcript.id);
  const waitingForResult = !!(audit && request && request.baseline === audit.scored_at);
  const inFlight = open.length > 0 || (waitingForResult && !failedAfterAudit);
  const inProgress = open.some((j) => j.status !== 'queued');
  let status;
  if (audit) status = audit.critical_fail ? 'critical' : audit.passed ? 'pass' : 'fail';
  else if (inFlight) status = inProgress ? 'running' : 'queued';
  else if (failed.length) status = 'error';
  else status = 'unaudited';
  return {
    id: transcript.id, tenant_id: transcript.tenant_id, agent_name: transcript.agent_name, channel: transcript.channel,
    uploaded_at: transcript.uploaded_at, audit, status, date: audit ? audit.scored_at : transcript.uploaded_at,
    score: audit && audit.overall_score !== null ? Number(audit.overall_score) : null,
    job: open[0] || failed[0] || jobs[0] || null, inFlight, inProgress,
    // Times audited = finished audit jobs. A re-audit overwrites the score, so jobs are the only record of the count.
    runs: Math.max(finished.length, audit ? 1 : 0),
    reauditFailed: failedAfterAudit && open.length === 0,
    needsReview: reviewFlags(audit).length > 0 && !(audit.scores && audit.scores._review),
  };
}

// Forget re-audit requests once a new score has arrived (or after 30 minutes).
function settleRequests(transcripts) {
  for (const t of transcripts) {
    const request = state.requested.get(t.id);
    if (!request) continue;
    const latest = (t.audit_scores || []).map((a) => a.scored_at).sort().pop();
    if (latest !== request.baseline || Date.now() - request.at > REQUEST_TTL_MS) state.requested.delete(t.id);
  }
}

async function loadData() {
  const [transcripts, jobs, rubrics] = await Promise.all([
    db.from('transcripts')
      .select('id, tenant_id, agent_name, channel, uploaded_at, audit_scores(id, overall_score, passed, critical_fail, rubric_version, scored_at, scores, flags)')
      .order('uploaded_at', { ascending: false }).limit(500),
    db.from('jobs').select('*').limit(1000),
    db.from('rubrics').select('*'),
  ]);
  if (transcripts.error) throw transcripts.error;
  const jobsByTranscript = new Map();
  for (const job of jobs.data || []) {
    if (job.kind && job.kind !== 'audit') continue;
    const id = job.payload && job.payload.transcript_id;
    if (!id) continue;
    if (!jobsByTranscript.has(id)) jobsByTranscript.set(id, []);
    jobsByTranscript.get(id).push(job);
  }
  state.rubrics = (rubrics.data || []).slice().sort((a, b) => b.version - a.version);
  settleRequests(transcripts.data);
  state.rows = transcripts.data.map((t) => buildRow(t, jobsByTranscript.get(t.id) || []));
  const known = new Set(state.rows.map((r) => r.id));
  for (const id of [...state.selected]) if (!known.has(id)) state.selected.delete(id);
}

async function refresh(silent = false) {
  try { await loadData(); } catch (error) { if (!silent) showAlert('Could not load data: ' + error.message); return; }
  hideAlert();
  updateReviewBadge();
  if (silent) {
    if (state.view === 'overview') renderOverview();
    else if (state.view === 'audits') renderAudits();
  } else {
    renderCurrent();
  }
}

function inRange(row) {
  if (state.range === 'all') return true;
  return Date.now() - new Date(row.date) <= Number(state.range) * 86400000;
}
function visibleRows() {
  const needle = state.search.trim().toLowerCase();
  return state.rows.filter(inRange).filter((r) => !needle || r.agent_name.toLowerCase().includes(needle));
}

// ---- navigation + shell
function renderNav() {
  const nav = $('#nav');
  nav.replaceChildren();
  const add = (key) => {
    const item = h('button', { class: 'nav-item', type: 'button', 'data-view': key, onclick: () => go(key) }, icon(VIEWS[key].icon), viewTitle(key));
    if (key === 'reviews' && canWrite()) item.append(h('span', { class: 'count', id: 'nav-reviews-count', hidden: true }));
    nav.append(item);
  };
  ['overview', 'audits', 'new', 'reviews', 'reports'].filter(allowed).forEach(add);
  if (canWrite()) { nav.append(h('div', { class: 'nav-label', text: 'Quality' })); ['learning', 'assistant'].filter(allowed).forEach(add); }
  if (isAdmin()) { nav.append(h('div', { class: 'nav-label', text: 'Manage' })); ['rubric', 'users', 'knowledge'].filter(allowed).forEach(add); }
  nav.append(h('div', { class: 'nav-label', text: 'Workspace' }));
  add('data');
}

function renderFilters() {
  const box = $('#filters');
  box.replaceChildren();
  if (!VIEWS[state.view].filters) return;
  const ranges = [['7', '7 days'], ['30', '30 days'], ['90', '90 days'], ['all', 'All time']];
  box.append(h('div', { class: 'seg', role: 'group', 'aria-label': 'Date range' }, ranges.map(([value, label]) =>
    h('button', { type: 'button', 'aria-pressed': String(state.range === value), text: label, onclick: () => { state.range = value; state.page = 1; renderFilters(); renderCurrent(); } }))));
  if (state.view !== 'audits') return;
  box.append(h('input', { class: 'input', type: 'search', placeholder: 'Search agent...', value: state.search, 'aria-label': 'Search agent',
    oninput: (event) => { state.search = event.target.value; state.page = 1; renderAudits(); } }));
  const chips = [['all', 'All'], ['pass', 'Passed'], ['fail', 'Failed'], ['critical', 'Critical'], ['review', 'Needs review'], ['pending', 'Pending'], ['error', 'Errors']];
  box.append(h('div', { style: 'display:flex;gap:6px;flex-wrap:wrap' }, chips.map(([value, label]) =>
    h('button', { class: 'chip', type: 'button', 'aria-pressed': String(state.status === value), text: label, onclick: () => { state.status = value; state.page = 1; renderFilters(); renderAudits(); } }))));
  const sorts = [['date_desc', 'Newest first'], ['date_asc', 'Oldest first'], ['score_desc', 'Highest score'], ['score_asc', 'Lowest score'], ['agent', 'Agent A-Z']];
  box.append(h('select', { class: 'select', 'aria-label': 'Sort', onchange: (event) => { state.sort = event.target.value; renderAudits(); } },
    sorts.map(([value, label]) => h('option', { value, text: label, selected: state.sort === value }))));
}

function go(view) {
  if (!allowed(view)) view = 'overview';
  state.view = view;
  state.page = 1;
  try { history.replaceState(null, '', '#' + view); } catch (error) { /* hash is a convenience only */ }
  for (const name of Object.keys(VIEWS)) $('#view-' + name).hidden = name !== view;
  for (const item of document.querySelectorAll('.nav-item[data-view]')) {
    if (item.dataset.view === view) item.setAttribute('aria-current', 'page'); else item.removeAttribute('aria-current');
  }
  $('#title').textContent = viewTitle(view);
  $('#subtitle').textContent = viewSubtitle(view);
  const actions = $('#top-actions');
  actions.replaceChildren();
  if (view !== 'new' && canWrite()) actions.append(h('button', { class: 'btn primary', type: 'button', onclick: () => go('new') }, icon('plus'), 'New audit'));
  renderFilters();
  renderCurrent();
  window.scrollTo(0, 0);
}

function renderCurrent() {
  ({ overview: renderOverview, audits: renderAudits, new: renderNew, reviews: renderReviews, reports: renderReports, learning: renderLearning,
     assistant: renderAssistant, rubric: renderRubric, users: renderUsers, knowledge: renderKnowledge, data: renderData })[state.view]();
}

// ---- overview
function emptyState(title, message, action) {
  return h('div', { class: 'card empty fade' }, h('h3', { text: title }), h('p', { text: message }), action || null);
}

function kpi(label, value, sub, spark) {
  const card = h('div', { class: 'card kpi fade' }, h('div', { class: 'label', text: label }), h('div', { class: 'value', text: value }), h('div', { class: 'sub', text: sub }));
  if (spark && spark.length > 1) {
    const w = 140, ht = 32;
    const step = w / (spark.length - 1);
    const path = spark.map((v, i) => (i ? 'L' : 'M') + (i * step).toFixed(1) + ' ' + (ht - 3 - (v / 100) * (ht - 6)).toFixed(1)).join(' ');
    card.append(svgEl('svg', { viewBox: '0 0 ' + w + ' ' + ht, width: w, height: ht, 'aria-hidden': 'true' },
      svgEl('path', { d: path, fill: 'none', stroke: 'var(--accent)', 'stroke-width': 2, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' })));
  }
  return card;
}

function hbars(container, items, emptyMessage) {
  container.replaceChildren();
  if (!items.length) { container.append(h('div', { class: 'empty', text: emptyMessage })); return; }
  const list = h('div', { class: 'rows' });
  for (const item of items) {
    const row = h('div', { class: 'hrow', tabindex: '0', 'data-tip': '' },
      h('span', { class: 'name', text: item.name, title: item.name }),
      h('span', { class: 'track' }, h('i', { class: 'fill', style: 'display:block;width:' + Math.max(2, item.value) + '%' })),
      h('span', { class: 'val', text: item.text }));
    const show = (event) => showTip(event, item.text, item.name, item.detail);
    row.addEventListener('pointermove', show);
    row.addEventListener('pointerleave', hideTip);
    row.addEventListener('focus', () => { const box = row.getBoundingClientRect(); show({ clientX: box.left + 40, clientY: box.top }); });
    row.addEventListener('blur', hideTip);
    list.append(row);
  }
  container.append(list);
}

function renderTrend(container, points) {
  container.replaceChildren();
  if (points.length < 2) {
    container.append(h('div', { class: 'empty' }, h('h3', { text: 'Not enough data yet' }), 'Score trends appear once at least two audits are scored in this period.'));
    return;
  }
  const width = Math.max(container.clientWidth, 300), height = 260;
  const m = { l: 36, r: 16, t: 16, b: 28 };
  const t0 = points[0].time, t1 = points[points.length - 1].time;
  const x = (t) => m.l + (t1 === t0 ? 0.5 : (t - t0) / (t1 - t0)) * (width - m.l - m.r);
  const y = (v) => m.t + (1 - v / 100) * (height - m.t - m.b);
  const svg = svgEl('svg', { viewBox: '0 0 ' + width + ' ' + height, width, height, role: 'img', 'aria-label': 'Audit scores over time' });
  for (const tick of [0, 25, 50, 75, 100]) {
    svg.append(svgEl('line', { x1: m.l, x2: width - m.r, y1: y(tick), y2: y(tick), stroke: 'var(--line)', 'stroke-width': 1 }));
    svg.append(svgEl('text', { x: m.l - 8, y: y(tick) + 4, 'text-anchor': 'end', 'font-size': 11, fill: 'var(--muted)' }, String(tick)));
  }
  const pass = threshold();
  svg.append(svgEl('line', { x1: m.l, x2: width - m.r, y1: y(pass), y2: y(pass), stroke: 'var(--muted)', 'stroke-width': 1.2, 'stroke-dasharray': '5 4' }));
  svg.append(svgEl('text', { x: width - m.r, y: y(pass) - 6, 'text-anchor': 'end', 'font-size': 11, fill: 'var(--muted)' }, 'Pass mark ' + pass));
  svg.append(svgEl('path', { d: points.map((p, i) => (i ? 'L' : 'M') + x(p.time).toFixed(1) + ' ' + y(p.score).toFixed(1)).join(' '),
    fill: 'none', stroke: 'var(--accent)', 'stroke-width': 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }));
  for (const [anchor, p] of [['start', points[0]], ['middle', points[Math.floor(points.length / 2)]], ['end', points[points.length - 1]]]) {
    svg.append(svgEl('text', { x: x(p.time), y: height - 8, 'text-anchor': anchor, 'font-size': 11, fill: 'var(--muted)' }, fmtDate(p.time)));
  }
  const cross = svgEl('line', { y1: m.t, y2: height - m.b, stroke: 'var(--muted)', 'stroke-width': 1, 'stroke-dasharray': '3 3', visibility: 'hidden' });
  svg.append(cross);
  const dots = points.map((p) => {
    const dot = svgEl('circle', { cx: x(p.time), cy: y(p.score), r: 4, fill: 'var(--accent)', stroke: 'var(--surface)', 'stroke-width': 2, tabindex: 0, 'data-tip': '' });
    dot.addEventListener('focus', () => { const box = dot.getBoundingClientRect(); showTip({ clientX: box.left, clientY: box.top }, String(p.score), p.agent + ' - ' + STATUS[p.status].label, fmtDateTime(p.time)); });
    dot.addEventListener('blur', hideTip);
    svg.append(dot);
    return dot;
  });
  const overlay = svgEl('rect', { x: m.l, y: m.t, width: width - m.l - m.r, height: height - m.t - m.b, fill: 'transparent', style: 'cursor:pointer', 'data-tip': '' });
  const nearest = (event) => {
    const box = svg.getBoundingClientRect();
    const px = (event.clientX - box.left) * (width / box.width);
    let best = 0;
    points.forEach((p, i) => { if (Math.abs(x(p.time) - px) < Math.abs(x(points[best].time) - px)) best = i; });
    return best;
  };
  overlay.addEventListener('pointermove', (event) => {
    const index = nearest(event), p = points[index];
    cross.setAttribute('x1', x(p.time)); cross.setAttribute('x2', x(p.time)); cross.setAttribute('visibility', 'visible');
    dots.forEach((dot, i) => dot.setAttribute('r', i === index ? 6 : 4));
    showTip(event, String(p.score), p.agent + ' - ' + STATUS[p.status].label, fmtDateTime(p.time));
  });
  overlay.addEventListener('pointerleave', () => { cross.setAttribute('visibility', 'hidden'); dots.forEach((dot) => dot.setAttribute('r', 4)); hideTip(); });
  overlay.addEventListener('click', (event) => openDrawer(points[nearest(event)].id));
  svg.append(overlay);
  container.append(svg);
}

function pipelineDetail(row) {
  const failure = (row.job && row.job.error) || 'The audit failed.';
  if (row.audit) {
    if (row.inFlight) return row.inProgress ? 'Re-audit in progress (audited ' + row.runs + ' time' + (row.runs === 1 ? '' : 's') + ' so far)' : 'Re-audit queued, waiting for the audit worker';
    return row.reauditFailed ? 'The last re-audit failed: ' + failure : '';
  }
  if (row.status === 'error') return failure;
  if (row.status === 'queued') return 'Waiting for the audit worker';
  if (row.status === 'running') return 'Being audited now';
  return 'No audit has been requested';
}

let trendObserver = null;
function renderOverview() {
  hideTip();
  const root = $('#view-overview');
  root.replaceChildren();
  if (!state.rows.length) {
    root.append(emptyState('No audits yet', 'Upload your first transcript and the AI will score it against your rubric.',
      canWrite() ? h('button', { class: 'btn primary', type: 'button', onclick: () => go('new') }, icon('upload'), 'Upload a transcript') : null));
    return;
  }
  const rows = visibleRows();
  const scored = rows.filter((r) => r.audit && r.score !== null);
  const sum = scored.reduce((total, r) => total + r.score, 0);
  const passCount = scored.filter((r) => r.status === 'pass').length;
  const critCount = scored.filter((r) => r.status === 'critical').length;
  const chrono = scored.slice().sort((a, b) => new Date(a.date) - new Date(b.date));
  const waiting = rows.filter(inPipeline);
  const name = (state.me.email || '').split('@')[0].replace(/[._]/g, ' ');

  root.append(h('div', { class: 'hero fade' }, h('h2', { text: 'Welcome back, ' + nice(name) }),
    h('p', { text: scored.length ? 'Your team scored ' + (scored.length ? (sum / scored.length).toFixed(1) : '-') + ' on average across ' + scored.length + ' audits in this period.' : 'No scored audits in this period yet. Try a wider date range, or upload a transcript.' }),
    canWrite() ? h('button', { class: 'btn', type: 'button', onclick: () => go('new') }, icon('upload'), 'Upload transcripts') : null));

  root.append(h('div', { class: 'grid kpis' },
    kpi('Audits scored', String(scored.length), waiting.length + ' waiting in the pipeline'),
    kpi('Average score', scored.length ? (sum / scored.length).toFixed(1) : '-', 'Pass mark ' + threshold(), chrono.slice(-24).map((r) => r.score)),
    kpi('Pass rate', scored.length ? pct(passCount, scored.length) + '%' : '-', passCount + ' of ' + scored.length + ' passed'),
    kpi('Critical fails', String(critCount), scored.length ? pct(critCount, scored.length) + '% of audits' : 'None scored'),
    kpi('Agents audited', String(new Set(scored.map((r) => r.agent_name)).size), 'in this period')));

  const trend = h('div', { id: 'trend' });
  const outcomes = h('div');
  const agents = h('div');
  const checks = h('div');
  const pipeline = h('div');
  root.append(h('div', { class: 'grid cols' },
    h('div', { class: 'card span-8 fade' }, h('div', { class: 'card-head' }, h('h2', { text: 'Score trend' }), h('span', { class: 'muted small', text: 'Click a point to open the audit' })), trend),
    h('div', { class: 'card span-4 fade' }, h('div', { class: 'card-head' }, h('h2', { text: 'Outcomes' })), outcomes),
    h('div', { class: 'card span-6 fade' }, h('div', { class: 'card-head' }, h('h2', { text: 'Average score by agent' }), h('span', { class: 'muted small', text: 'Top 8' })), agents),
    h('div', { class: 'card span-6 fade' }, h('div', { class: 'card-head' }, h('h2', { text: 'Where audits fail' }), h('span', { class: 'muted small', text: 'Pass rate per check, lowest first' })), checks),
    h('div', { class: 'card span-12 fade' }, h('div', { class: 'card-head' }, h('h2', { text: 'Pipeline' }), h('span', { class: 'muted small', text: 'Transcripts not yet scored' })), pipeline)));

  const draw = () => renderTrend(trend, chrono.map((r) => ({ id: r.id, time: new Date(r.date).getTime(), score: r.score, agent: r.agent_name, status: r.status })));
  draw();
  if (trendObserver) trendObserver.disconnect();
  let lastWidth = trend.clientWidth;
  trendObserver = new ResizeObserver(() => { if (Math.abs(trend.clientWidth - lastWidth) > 4) { lastWidth = trend.clientWidth; draw(); } });
  trendObserver.observe(trend);

  // outcomes: stacked bar + legend; status colors always carry an icon and a label
  const counts = { pass: passCount, fail: scored.filter((r) => r.status === 'fail').length, critical: critCount };
  if (!scored.length) outcomes.append(h('div', { class: 'empty', text: 'No scored audits in this period.' }));
  else {
    const stack = h('div', { class: 'stack', role: 'img', 'aria-label': 'Share of passed, failed and critical audits' });
    const legend = h('div', { class: 'legend' });
    for (const key of ['pass', 'fail', 'critical']) {
      const meta = STATUS[key];
      if (counts[key]) {
        const seg = h('i', { style: 'flex:' + counts[key] + ';background:' + meta.color, tabindex: '0', 'data-tip': '' });
        seg.addEventListener('pointermove', (event) => showTip(event, counts[key] + ' (' + pct(counts[key], scored.length) + '%)', meta.label));
        seg.addEventListener('pointerleave', hideTip);
        stack.append(seg);
      }
      legend.append(h('div', {}, h('span', { class: 'l' }, badge(key)), h('span', {}, h('b', { text: String(counts[key]) }), ' ', h('span', { class: 'muted', text: pct(counts[key], scored.length) + '%' }))));
    }
    outcomes.append(stack, legend);
  }

  const byAgent = new Map();
  for (const r of scored) { const e = byAgent.get(r.agent_name) || { total: 0, n: 0 }; e.total += r.score; e.n += 1; byAgent.set(r.agent_name, e); }
  hbars(agents, [...byAgent.entries()].map(([agent, e]) => ({ name: agent, value: e.total / e.n, text: (e.total / e.n).toFixed(1), detail: e.n + ' audit' + (e.n === 1 ? '' : 's') }))
    .sort((a, b) => b.value - a.value).slice(0, 8), 'No scored audits in this period.');

  const rubricChecks = ((activeRubric() || {}).parameters || {}).checks || [];
  const labels = new Map(rubricChecks.map((c) => [c.key, c.label || nice(c.key)]));
  const stats = new Map();
  for (const r of scored) {
    for (const [key, verdict] of Object.entries(r.audit.scores || {})) {
      if (key === 'summary' || key.startsWith('_') || !verdict || typeof verdict !== 'object') continue;
      const e = stats.get(key) || { pass: 0, n: 0 };
      e.n += 1; if (verdict.passed) e.pass += 1; stats.set(key, e);
    }
  }
  hbars(checks, [...stats.entries()].map(([key, e]) => ({ name: labels.get(key) || nice(key), value: pct(e.pass, e.n), text: pct(e.pass, e.n) + '%', detail: e.pass + ' of ' + e.n + ' audits passed' }))
    .sort((a, b) => a.value - b.value), 'Check results appear after the first audit.');

  if (!waiting.length) pipeline.append(h('div', { class: 'empty', text: 'The pipeline is clear. Every transcript has been scored.' }));
  else {
    pipeline.append(h('div', { class: 'table-wrap' }, h('table', {}, h('thead', {}, h('tr', {}, h('th', { text: 'Agent' }), h('th', { text: 'Status' }), h('th', { text: 'Uploaded' }), h('th', { text: 'Detail' }))),
      h('tbody', {}, waiting.slice(0, 8).map((r) => h('tr', {}, h('td', { text: r.agent_name }), h('td', {}, badge(pipelineStatus(r))), h('td', { class: 'muted', text: ago(r.uploaded_at) }),
        h('td', { class: 'muted', text: pipelineDetail(r) })))))));
  }
}

// ---- audits table
function matchesStatus(row) {
  if (state.status === 'all') return true;
  if (state.status === 'pending') return ['queued', 'running', 'unaudited'].includes(row.status) || row.inFlight;
  if (state.status === 'review') return row.needsReview;
  return row.status === state.status;
}
function sortRows(rows) {
  const by = {
    date_desc: (a, b) => new Date(b.date) - new Date(a.date), date_asc: (a, b) => new Date(a.date) - new Date(b.date),
    score_desc: (a, b) => (b.score ?? -1) - (a.score ?? -1), score_asc: (a, b) => (a.score ?? 101) - (b.score ?? 101),
    agent: (a, b) => a.agent_name.localeCompare(b.agent_name),
  };
  return rows.slice().sort(by[state.sort] || by.date_desc);
}

function renderAudits() {
  hideTip();
  const root = $('#view-audits');
  root.replaceChildren();
  const rows = sortRows(visibleRows().filter(matchesStatus));
  if (!rows.length) {
    root.append(emptyState('Nothing matches', state.rows.length ? 'Try a different date range, status or search.' : 'Upload a transcript to create your first audit.',
      !state.rows.length && canWrite() ? h('button', { class: 'btn primary', type: 'button', onclick: () => go('new') }, 'Upload a transcript') : null));
    return;
  }
  const pages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  state.page = Math.min(state.page, pages);
  const pageRows = rows.slice((state.page - 1) * PAGE_SIZE, state.page * PAGE_SIZE);
  const selectedRows = state.rows.filter((r) => state.selected.has(r.id));

  if (selectedRows.length && canWrite()) {
    root.append(h('div', { class: 'bulk' }, h('b', { text: selectedRows.length + ' selected' }),
      h('button', { class: 'btn sm', type: 'button', onclick: () => reaudit(selectedRows) }, icon('redo', 15), 'Re-audit'),
      h('button', { class: 'btn sm danger', type: 'button', onclick: () => deleteRows(selectedRows) }, icon('trash', 15), 'Delete'),
      h('button', { class: 'btn sm ghost', type: 'button', onclick: () => { state.selected.clear(); renderAudits(); }, text: 'Clear' })));
  }

  const allOnPage = pageRows.every((r) => state.selected.has(r.id));
  const head = h('tr', {},
    canWrite() ? h('th', {}, h('input', { type: 'checkbox', 'aria-label': 'Select all on this page', checked: allOnPage,
      onchange: (event) => { for (const r of pageRows) { if (event.target.checked) state.selected.add(r.id); else state.selected.delete(r.id); } renderAudits(); } })) : h('th'),
    h('th', { text: 'Agent' }), h('th', { text: 'Result' }), h('th', { text: 'Score' }), h('th', { text: 'Rubric' }), h('th', { text: 'Audited', title: 'How many times this call has been audited' }), h('th', { text: 'When' }), h('th'));
  const body = h('tbody', {}, pageRows.map((r) => {
    const open = () => openDrawer(r.id);
    return h('tr', {},
      h('td', {}, canWrite() ? h('input', { type: 'checkbox', 'aria-label': 'Select ' + r.agent_name, checked: state.selected.has(r.id),
        onchange: (event) => { if (event.target.checked) state.selected.add(r.id); else state.selected.delete(r.id); renderAudits(); } }) : null),
      h('td', { style: 'cursor:pointer', onclick: open }, h('div', { class: 'who' }, h('span', { class: 'avatar', text: initials(r.agent_name) }),
        h('div', {}, h('div', { text: r.agent_name }), h('div', { class: 'muted small', text: r.channel })))),
      h('td', {}, h('div', { style: 'display:flex;gap:6px;flex-wrap:wrap' }, badge(r.status), r.needsReview ? badge('needsReview') : null, r.audit && (r.inFlight || r.reauditFailed) ? badge(pipelineStatus(r)) : null)),
      h('td', {}, r.score === null ? h('span', { class: 'muted', text: '-' }) :
        h('div', { class: 'score' }, h('b', { text: String(r.score) }), h('div', { class: 'bar' }, h('i', { style: 'width:' + Math.max(0, Math.min(100, r.score)) + '%' })))),
      h('td', { class: 'muted', text: r.audit ? 'v' + r.audit.rubric_version : '-' }),
      h('td', { class: 'muted', text: r.runs ? r.runs + (r.runs === 1 ? ' time' : ' times') : '-' }),
      h('td', { class: 'muted', title: fmtDateTime(r.date), text: ago(r.date) }),
      h('td', { class: 'actions' },
        h('button', { class: 'icon-btn', type: 'button', title: 'View details', 'aria-label': 'View details', onclick: open }, icon('eye')),
        canWrite() ? h('button', { class: 'icon-btn', type: 'button', title: 'Re-audit', 'aria-label': 'Re-audit', onclick: () => reaudit([r]) }, icon('redo')) : null,
        canWrite() ? h('button', { class: 'icon-btn danger', type: 'button', title: 'Delete', 'aria-label': 'Delete', onclick: () => deleteRows([r]) }, icon('trash')) : null));
  }));
  root.append(h('div', { class: 'card fade' }, h('div', { class: 'table-wrap' }, h('table', {}, h('thead', {}, head), body)),
    h('div', { class: 'pager' }, h('span', { class: 'muted small', text: rows.length + ' result' + (rows.length === 1 ? '' : 's') }),
      h('div', { style: 'display:flex;gap:8px;align-items:center' },
        h('button', { class: 'btn sm', type: 'button', disabled: state.page <= 1, onclick: () => { state.page -= 1; renderAudits(); }, text: 'Previous' }),
        h('span', { class: 'muted small', text: 'Page ' + state.page + ' of ' + pages }),
        h('button', { class: 'btn sm', type: 'button', disabled: state.page >= pages, onclick: () => { state.page += 1; renderAudits(); }, text: 'Next' })))));
}

async function reaudit(rows) {
  const jobs = rows.map((r) => ({ tenant_id: r.tenant_id, kind: 'audit', payload: { transcript_id: r.id } }));
  const { error } = await db.from('jobs').insert(jobs);
  if (error) { toast('Could not queue the audit: ' + error.message, 'error'); return; }
  for (const r of rows) if (r.audit) state.requested.set(r.id, { baseline: r.audit.scored_at, at: Date.now() });
  toast(rows.length + ' re-audit' + (rows.length === 1 ? '' : 's') + ' queued. ' + (rows.length === 1 ? 'It shows' : 'They show') + ' in the Pipeline until the new score arrives.', 'ok');
  logActivity('audit.requeued', { count: rows.length, agents: [...new Set(rows.map((r) => r.agent_name))].slice(0, 10) });
  state.selected.clear();
  await refresh();
}

async function deleteRows(rows) {
  const many = rows.length > 1;
  const confirmed = await confirmDialog(many ? 'Delete ' + rows.length + ' audits?' : 'Delete this audit?',
    'This permanently removes the transcript and its score' + (many ? 's' : '') + '. It cannot be undone.', 'Delete', true);
  if (!confirmed) return;
  const ids = rows.map((r) => r.id);
  try {
    await db.from('jobs').delete().in('payload->>transcript_id', ids);
    const scores = await db.from('audit_scores').delete().in('transcript_id', ids).select('id');
    if (scores.error) throw scores.error;
    if (rows.some((r) => r.audit) && !scores.data.length) throw new Error(PERM_HELP);
    const removed = await db.from('transcripts').delete().in('id', ids).select('id');
    if (removed.error) throw removed.error;
    if (!removed.data.length) throw new Error(PERM_HELP);
    toast(removed.data.length + ' deleted.', 'ok');
    logActivity('audit.deleted', { count: removed.data.length, agents: [...new Set(rows.map((r) => r.agent_name))].slice(0, 10) });
    state.selected.clear();
    if (state.drawerId && ids.includes(state.drawerId)) closeDrawer();
  } catch (error) {
    toast('Delete failed: ' + error.message, 'error');
  }
  await refresh();
}

// ---- detail drawer (view / review / edit details)
let drawerText = '';
function computeResult(params, verdicts) {
  let score = 0;
  const flags = [];
  for (const check of (params && params.checks) || []) {
    const verdict = verdicts[check.key] || { passed: false, reason: 'check was not run' };
    if (verdict.passed) score += (check.weight || 0) * 100;
    else if (check.critical) flags.push('REGULATORY_AUTO_FAIL: ' + check.label + ': ' + (verdict.reason || ''));
  }
  if (flags.length) return { overall_score: 0, passed: false, critical_fail: true, flags };
  const overall = Math.round(score * 100) / 100;
  const mark = params && params.pass_threshold !== undefined ? Number(params.pass_threshold) : 80;
  return { overall_score: overall, passed: overall >= mark, critical_fail: false, flags: [] };
}

function gauge(score, status, size = 96) {
  const r = 40, c = 2 * Math.PI * r, frac = Math.max(0, Math.min(100, score)) / 100;
  return svgEl('svg', { viewBox: '0 0 100 100', width: size, height: size, role: 'img', 'aria-label': 'Score ' + score + ' out of 100' },
    svgEl('circle', { cx: 50, cy: 50, r, fill: 'none', stroke: 'var(--line)', 'stroke-width': 9 }),
    svgEl('circle', { cx: 50, cy: 50, r, fill: 'none', stroke: STATUS[status].color, 'stroke-width': 9, 'stroke-linecap': 'round', 'stroke-dasharray': (c * frac) + ' ' + c, transform: 'rotate(-90 50 50)' }),
    svgEl('text', { x: 50, y: 57, 'text-anchor': 'middle', 'font-size': 24, 'font-weight': 700, fill: 'var(--ink)' }, String(score)));
}

function openDrawer(id) {
  const row = state.rows.find((r) => r.id === id);
  if (!row) return;
  state.drawerId = id;
  $('#drawer').classList.add('open'); $('#drawer').setAttribute('aria-hidden', 'false'); $('#backdrop').classList.add('open');
  $('#drawer-title').textContent = row.agent_name;
  $('#drawer-body').replaceChildren(h('div', { class: 'sk' }), h('div', { class: 'sk', style: 'width:70%' }), h('div', { class: 'sk', style: 'width:85%' }));
  db.from('transcripts').select('raw_text').eq('id', id).single().then(({ data, error }) => {
    drawerText = error || !data ? '' : data.raw_text;
    if (state.drawerId === id) paintDrawer(row, 'view');
  });
}
function closeDrawer() {
  state.drawerId = null;
  $('#drawer').classList.remove('open'); $('#drawer').setAttribute('aria-hidden', 'true'); $('#backdrop').classList.remove('open');
}

function checkList(row) {
  const audit = row.audit;
  const params = (rubricFor(audit.rubric_version) || {}).parameters || {};
  const defined = (params.checks || []).map((c) => ({ key: c.key, label: c.label || nice(c.key), weight: c.weight, critical: !!c.critical }));
  const known = new Set(defined.map((c) => c.key));
  const extra = Object.keys(audit.scores || {}).filter((k) => k !== 'summary' && !k.startsWith('_') && !known.has(k) && audit.scores[k] && typeof audit.scores[k] === 'object')
    .map((k) => ({ key: k, label: nice(k), weight: null, critical: false }));
  return [...defined, ...extra];
}

// What the audit worker recorded about who judged the checks (scores._engine); older audits have none.
function engineLabel(engine) {
  if (engine.name === 'neuro_san') return 'Judged by Neuro SAN agents' + (engine.network ? ' (' + engine.network + ')' : '');
  if (engine.name === 'bridge') return 'Judged directly by the model';
  return 'Engine: ' + engine.name;
}

function paintDrawer(row, mode) {
  const body = $('#drawer-body');
  body.replaceChildren();
  const audit = row.audit;
  const hero = h('div', { class: 'card dhero' });
  if (audit) hero.append(gauge(row.score ?? 0, row.status));
  hero.append(h('div', {}, h('div', { style: 'margin-bottom:6px;display:flex;gap:6px;flex-wrap:wrap' }, badge(row.status), row.needsReview ? badge('needsReview') : null, audit && (row.inFlight || row.reauditFailed) ? badge(pipelineStatus(row)) : null),
    row.runs ? h('div', { class: 'muted small', text: 'Audited ' + row.runs + (row.runs === 1 ? ' time' : ' times') }) : null,
    h('div', { class: 'muted small', text: row.channel + ' - uploaded ' + fmtDateTime(row.uploaded_at) }),
    audit ? h('div', { class: 'muted small', text: 'Scored ' + fmtDateTime(audit.scored_at) + ' with rubric v' + audit.rubric_version + ' - pass mark ' + threshold() }) : null,
    audit && audit.scores && (audit.scores._engine || audit.scores._review) ? h('div', { class: 'small', style: 'margin-top:4px;display:flex;gap:6px;flex-wrap:wrap' },
      audit.scores._engine ? h('span', { class: 'tag', title: 'Which engine judged the checks', text: engineLabel(audit.scores._engine) }) : null,
      audit.scores._review ? h('span', { class: 'tag', text: 'Reviewed by ' + audit.scores._review.by }) : null) : null));
  body.append(hero);

  if (!audit) {
    body.append(h('div', { class: 'card' }, h('h3', { text: 'No score yet' }),
      h('p', { class: 'muted', text: row.status === 'error' ? ((row.job && row.job.error) || 'The audit failed.') : row.status === 'queued' ? 'Waiting for the audit worker to pick this up.' : 'This transcript has not been audited.' })));
  } else if (mode === 'review') {
    paintReview(row, body);
    return;
  } else {
    const summary = audit.scores && audit.scores.summary;
    if (summary) body.append(h('div', { class: 'card' }, h('h3', { text: 'Summary' }), h('p', { class: 'muted', style: 'margin:6px 0 0', text: summary })));
    body.append(h('div', { class: 'card' }, h('h3', { text: 'Checks' }), h('div', { style: 'margin-top:6px' }, checkList(row).map((c) => {
      const verdict = (audit.scores || {})[c.key] || {};
      const ok = !!verdict.passed;
      const mark = h('span', { class: 'pf', style: 'background:' + (ok ? 'var(--good)' : 'var(--critical)') }, icon(ok ? 'check' : 'x', 15));
      return h('div', { class: 'check' }, mark, h('div', {}, h('b', { text: c.label }), ' ',
        c.weight !== null ? h('span', { class: 'tag', text: Math.round(c.weight * 100) + '%' }) : null, ' ', c.critical ? h('span', { class: 'tag crit', text: 'critical' }) : null,
        h('p', { text: verdict.reason || (ok ? 'Passed.' : 'No reason recorded.') })));
    }))));
    if (row.needsReview) body.append(h('div', { class: 'card', style: 'border-color:var(--critical)' }, h('h3', { text: 'Needs review' }),
      h('p', { class: 'muted small', style: 'margin:6px 0' }, 'The AI marked a critical check as failed but did not back it up with a quote of the agent, so the score was not set to 0. Check the call and use Review & edit score to confirm or correct it. Your correction also becomes learning data.'),
      h('ul', { style: 'margin:6px 0 0;padding-left:18px' }, reviewFlags(audit).map((f) => { const r = reviewReason(f); return h('li', {}, h('b', { text: r.label + ': ' }), r.text); }))));
    if ((audit.flags || []).length) body.append(h('div', { class: 'card' }, h('h3', { text: 'Flags' }), h('ul', { style: 'margin:8px 0 0;padding-left:18px' }, audit.flags.map((f) => h('li', { text: f })))));
  }

  if (mode === 'details') { paintDetails(row, body); return; }
  body.append(h('details', { class: 'card' }, h('summary', { text: 'Transcript (' + drawerText.length + ' characters)' }), h('pre', { class: 'transcript', text: drawerText || 'No transcript text.' })));
  const actions = h('div', { style: 'display:flex;gap:10px;flex-wrap:wrap' });
  if (canWrite()) {
    if (audit) actions.append(h('button', { class: 'btn', type: 'button', onclick: () => paintDrawer(row, 'review') }, icon('edit', 16), 'Review & edit score'));
    actions.append(h('button', { class: 'btn', type: 'button', onclick: () => paintDrawer(row, 'details') }, icon('edit', 16), 'Edit details'),
      h('button', { class: 'btn', type: 'button', onclick: () => reaudit([row]) }, icon('redo', 16), 'Re-audit'),
      h('button', { class: 'btn danger', type: 'button', onclick: () => deleteRows([row]) }, icon('trash', 16), 'Delete'));
  }
  if (!canWrite() && audit) {
    // An agent can ask a supervisor to look again; they cannot change anything themselves.
    actions.append(h('button', { class: 'btn', type: 'button', onclick: () => openRequestDialog(row, 'contest') }, icon('shield', 16), 'Contest this result'),
      h('button', { class: 'btn', type: 'button', onclick: () => openRequestDialog(row, 'reaudit') }, icon('redo', 16), 'Ask for a new audit'));
  }
  body.append(actions);
  if (canWrite() && audit) paintRequestsCard(row, body);
}

function paintReview(row, body) {
  const audit = row.audit;
  const params = (rubricFor(audit.rubric_version) || {}).parameters || {};
  const verdicts = {};
  for (const c of checkList(row)) { const v = (audit.scores || {})[c.key] || {}; verdicts[c.key] = { passed: !!v.passed, reason: v.reason || '' }; }
  const original = JSON.parse(JSON.stringify(verdicts)); // what the AI said, kept for the learning data
  const preview = h('div', { class: 'muted small' });
  const update = () => { const result = computeResult(params, verdicts); preview.textContent = 'New score: ' + result.overall_score + (result.critical_fail ? ' (critical fail)' : result.passed ? ' (pass)' : ' (fail)'); };
  const list = h('div', {}, checkList(row).map((c) => {
    const v = verdicts[c.key];
    const pass = h('button', { type: 'button', class: 'p', text: 'Pass' });
    const fail = h('button', { type: 'button', class: 'f', text: 'Fail' });
    const sync = () => { pass.setAttribute('aria-pressed', String(v.passed)); fail.setAttribute('aria-pressed', String(!v.passed)); update(); };
    pass.addEventListener('click', () => { v.passed = true; sync(); });
    fail.addEventListener('click', () => { v.passed = false; sync(); });
    sync();
    return h('div', { class: 'check', style: 'grid-template-columns:1fr' }, h('div', { style: 'display:flex;justify-content:space-between;gap:10px;align-items:center' },
      h('b', { text: c.label }), h('div', { class: 'seg2' }, pass, fail)),
      h('input', { class: 'input', value: v.reason, placeholder: 'Reason', 'aria-label': 'Reason for ' + c.label, oninput: (event) => { v.reason = event.target.value; } }));
  }));
  body.append(h('div', { class: 'card' }, h('h3', { text: 'Review & edit score' }), h('p', { class: 'muted small', text: 'Override the AI verdicts. The score is recalculated with the same rules as the audit worker, and the audit is marked as reviewed by you.' }), list, preview));
  body.append(h('div', { style: 'display:flex;gap:10px' },
    h('button', { class: 'btn primary', type: 'button', onclick: async (event) => {
      // A changed verdict with the AI's old reason would contradict itself, and teach the AI the wrong lesson.
      const unexplained = Object.keys(verdicts).filter((key) => verdicts[key].passed !== original[key].passed && verdicts[key].reason.trim() === (original[key].reason || '').trim());
      if (unexplained.length) { toast('You changed ' + unexplained.map(nice).join(' and ') + '. Please write why in the reason box, so the audit and the AI learn the right thing.', 'error'); return; }
      event.target.disabled = true;
      const result = computeResult(params, verdicts);
      const aiFlags = reviewFlags(audit);
      const scores = { ...(audit.scores || {}), ...verdicts, _review: { by: state.me.email, at: new Date().toISOString(), ...(aiFlags.length ? { ai_flagged: true, flags: aiFlags } : {}) } };
      const { data, error } = await db.from('audit_scores').update({ scores, flags: result.flags, overall_score: result.overall_score, passed: result.passed, critical_fail: result.critical_fail }).eq('id', audit.id).select('id');
      event.target.disabled = false;
      if (error || !data.length) { toast('Could not save the review: ' + (error ? error.message : PERM_HELP), 'error'); return; }
      toast('Review saved. Score is now ' + result.overall_score + '.', 'ok');
      logActivity('audit.reviewed', { transcript_id: row.id, agent: row.agent_name, from: row.score, to: result.overall_score });
      const contested = await resolvePendingContests(row, 'Score reviewed and updated by ' + state.me.email + '.');
      await captureFeedback(row, original, verdicts, contested ? 'contest' : 'review');
      await refresh();
      const fresh = state.rows.find((r) => r.id === row.id);
      if (fresh) paintDrawer(fresh, 'view');
    }, text: 'Save review' }),
    h('button', { class: 'btn', type: 'button', onclick: () => paintDrawer(row, 'view'), text: 'Cancel' })));
}

function paintDetails(row, body) {
  const agent = h('input', { class: 'input', value: row.agent_name, maxlength: '120', id: 'ed-agent' });
  const channel = h('select', { class: 'select', id: 'ed-channel' }, ['voice', 'chat', 'email'].map((c) => h('option', { value: c, text: nice(c), selected: row.channel === c })));
  const text = h('textarea', { class: 'textarea', id: 'ed-text' });
  text.value = drawerText;
  body.append(h('div', { class: 'card' }, h('h3', { text: 'Edit details' }),
    h('div', { class: 'field', style: 'margin-top:10px' }, h('label', { for: 'ed-agent', text: 'Agent name' }), agent),
    h('div', { class: 'field' }, h('label', { for: 'ed-channel', text: 'Channel' }), channel),
    h('div', { class: 'field' }, h('label', { for: 'ed-text', text: 'Transcript' }), text)));
  const save = async (andAudit, event) => {
    event.target.disabled = true;
    const changes = { agent_name: agent.value.trim(), channel: channel.value, raw_text: maskPii(text.value) };
    const { data, error } = await db.from('transcripts').update(changes).eq('id', row.id).select('id');
    event.target.disabled = false;
    if (error || !data.length) { toast('Could not save: ' + (error ? error.message : PERM_HELP), 'error'); return; }
    drawerText = changes.raw_text;
    toast('Saved.', 'ok');
    logActivity('transcript.edited', { transcript_id: row.id, agent: changes.agent_name });
    if (andAudit) await reaudit([row]); else await refresh();
    const fresh = state.rows.find((r) => r.id === row.id);
    if (fresh) paintDrawer(fresh, 'view');
  };
  body.append(h('div', { style: 'display:flex;gap:10px;flex-wrap:wrap' },
    h('button', { class: 'btn primary', type: 'button', onclick: (event) => save(false, event), text: 'Save' }),
    h('button', { class: 'btn', type: 'button', onclick: (event) => save(true, event), text: 'Save & re-audit' }),
    h('button', { class: 'btn', type: 'button', onclick: () => paintDrawer(row, 'view'), text: 'Cancel' })));
}

// Mirrors preprocessor.py (DeterministicSanitizer.mask_pii) so PII never reaches the database.
function maskPii(text) {
  return text
    .replace(/\b(?:\d[ -]*?){13,16}\b/g, '[REDACTED_PCI_CARD]')
    .replace(/\b\d{3}-\d{2}-\d{4}\b/g, '[REDACTED_SSN]')
    .replace(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g, '[REDACTED_EMAIL]')
    .replace(/\b(?:\+?1[-.]?)?\(?[0-9]{3}\)?[-. ]?[0-9]{3}[-. ]?[0-9]{4}\b/g, '[REDACTED_PHONE]');
}
"""
