-- One-time setup for the agent features: contests and review requests, learning data, performance reports,
-- rubric proposals, the knowledge base and the chat assistant.
--
-- Run it once in Supabase -> SQL Editor, AFTER admin_setup.sql. It is safe to run again.
-- It uses the helper functions your database already has: current_tenant(), current_user_role(), current_agent_name().
--
-- Privacy and isolation: every table carries tenant_id and has Row-Level Security. Agents see only their own rows. The
-- audit worker (role qa_worker) gets only the access it needs, and only inside the tenant it is working for.

-- ---------------------------------------------------------------------------------------------------------------------
-- Helper: does this audit belong to the person asking? Staff: any audit of their tenant. Agents: their own calls only.
-- SECURITY DEFINER so that checking it does not depend on (or loop through) the row policies of the tables it reads.
-- ---------------------------------------------------------------------------------------------------------------------
create or replace function public.audit_belongs_to_caller(p_audit_id uuid) returns boolean
language plpgsql stable security definer set search_path = public as $$
begin
    return exists (
        select 1
        from public.audit_scores a join public.transcripts t on t.id = a.transcript_id
        where a.id = p_audit_id
          and a.tenant_id = current_tenant()
          and (current_user_role() <> 'agent' or t.agent_name = current_agent_name()));
end $$;

-- ---------------------------------------------------------------------------------------------------------------------
-- Jobs: allow the new kinds of work. If the table limits the kind column, widen that limit.
-- ---------------------------------------------------------------------------------------------------------------------
do $$
declare
    existing record;
begin
    for existing in
        select conname from pg_constraint
        where conrelid = 'public.jobs'::regclass and contype = 'c' and pg_get_constraintdef(oid) ilike '%kind%'
    loop
        execute format('alter table public.jobs drop constraint %I', existing.conname);
    end loop;
end $$;

alter table public.jobs drop constraint if exists jobs_kind_check;
alter table public.jobs add constraint jobs_kind_check check (kind in ('audit', 'report', 'research', 'chat'));

drop policy if exists jobs_staff_insert_extra on public.jobs;
create policy jobs_staff_insert_extra on public.jobs for insert to authenticated
    with check (tenant_id = (select current_tenant()) and kind in ('report', 'research', 'chat')
                and (select current_user_role()) in ('admin', 'supervisor', 'team_lead'));

-- ---------------------------------------------------------------------------------------------------------------------
-- Agents may read their own audits (the existing policies stay as they are; policies add up).
-- ---------------------------------------------------------------------------------------------------------------------
drop policy if exists agent_select_own on public.audit_scores;
create policy agent_select_own on public.audit_scores for select to authenticated
    using (tenant_id = (select current_tenant()) and (select current_user_role()) = 'agent' and public.audit_belongs_to_caller(id));

-- ---------------------------------------------------------------------------------------------------------------------
-- Review requests: an agent contests a result or asks for a new audit; staff resolve it.
-- ---------------------------------------------------------------------------------------------------------------------
create table if not exists public.review_requests (
    id                 uuid primary key default gen_random_uuid(),
    tenant_id          uuid not null default current_tenant() references public.tenants (id),
    audit_id           uuid not null references public.audit_scores (id) on delete cascade,
    transcript_id      uuid not null references public.transcripts (id) on delete cascade,
    kind               text not null check (kind in ('contest', 'reaudit')),
    check_keys         text[] not null default '{}',
    comment            text not null check (length(btrim(comment)) >= 10),
    status             text not null default 'pending' check (status in ('pending', 'accepted', 'rejected')),
    requested_by       uuid not null default auth.uid(),
    requested_by_email text,
    resolution         text,
    resolved_by        uuid,
    resolved_by_email  text,
    created_at         timestamptz not null default now(),
    resolved_at        timestamptz
);
create unique index if not exists review_requests_one_pending
    on public.review_requests (audit_id, requested_by, kind) where status = 'pending';
create index if not exists review_requests_tenant_status on public.review_requests (tenant_id, status, created_at desc);
alter table public.review_requests enable row level security;

drop policy if exists rr_select on public.review_requests;
create policy rr_select on public.review_requests for select to authenticated
    using (tenant_id = (select current_tenant())
           and ((select current_user_role()) <> 'agent' or requested_by = auth.uid()));

drop policy if exists rr_insert on public.review_requests;
create policy rr_insert on public.review_requests for insert to authenticated
    with check (tenant_id = (select current_tenant()) and requested_by = auth.uid() and public.audit_belongs_to_caller(audit_id));

drop policy if exists rr_update on public.review_requests;
create policy rr_update on public.review_requests for update to authenticated
    using (tenant_id = (select current_tenant()) and (select current_user_role()) in ('admin', 'supervisor', 'team_lead'))
    with check (tenant_id = (select current_tenant()));

-- ---------------------------------------------------------------------------------------------------------------------
-- Rule feedback: every time a human confirms or corrects the AI on a check. This is the learning data. No update or
-- delete policy exists, so the history cannot be rewritten from the app.
-- ---------------------------------------------------------------------------------------------------------------------
create table if not exists public.rule_feedback (
    id               uuid primary key default gen_random_uuid(),
    tenant_id        uuid not null default current_tenant() references public.tenants (id),
    audit_id         uuid references public.audit_scores (id) on delete set null,
    transcript_id    uuid references public.transcripts (id) on delete cascade,
    check_key        text not null,
    rubric_version   int,
    ai_passed        boolean not null,
    ai_reason        text,
    human_passed     boolean not null,
    human_reason     text,
    changed          boolean generated always as (ai_passed <> human_passed) stored,
    source           text not null check (source in ('review', 'contest')),
    created_by       uuid default auth.uid(),
    created_by_email text,
    created_at       timestamptz not null default now()
);
create index if not exists rule_feedback_tenant_check on public.rule_feedback (tenant_id, check_key, created_at desc);
alter table public.rule_feedback enable row level security;

drop policy if exists rf_select on public.rule_feedback;
create policy rf_select on public.rule_feedback for select to authenticated
    using (tenant_id = (select current_tenant()) and (select current_user_role()) in ('admin', 'supervisor', 'team_lead'));

drop policy if exists rf_insert on public.rule_feedback;
create policy rf_insert on public.rule_feedback for insert to authenticated
    with check (tenant_id = (select current_tenant()) and created_by = auth.uid()
                and (select current_user_role()) in ('admin', 'supervisor', 'team_lead'));

-- ---------------------------------------------------------------------------------------------------------------------
-- Performance reports: written by the worker, read by staff, and each agent can read their own.
-- ---------------------------------------------------------------------------------------------------------------------
create table if not exists public.performance_reports (
    id              uuid primary key default gen_random_uuid(),
    tenant_id       uuid not null default current_tenant() references public.tenants (id),
    agent_name      text not null,
    period          text not null,
    trends          jsonb not null default '{}'::jsonb,
    recommendations jsonb not null default '{}'::jsonb,
    generated_at    timestamptz not null default now()
);
create index if not exists performance_reports_tenant_agent on public.performance_reports (tenant_id, agent_name, generated_at desc);
alter table public.performance_reports enable row level security;

drop policy if exists pr_select_staff on public.performance_reports;
create policy pr_select_staff on public.performance_reports for select to authenticated
    using (tenant_id = (select current_tenant()) and (select current_user_role()) <> 'agent');

drop policy if exists pr_select_own on public.performance_reports;
create policy pr_select_own on public.performance_reports for select to authenticated
    using (tenant_id = (select current_tenant()) and (select current_user_role()) = 'agent'
           and agent_name = (select current_agent_name()));

-- ---------------------------------------------------------------------------------------------------------------------
-- Rubric change requests: proposals from the research agent. An admin approves or rejects. Nothing changes by itself.
-- ---------------------------------------------------------------------------------------------------------------------
create table if not exists public.rubric_change_requests (
    id            uuid primary key default gen_random_uuid(),
    tenant_id     uuid not null default current_tenant() references public.tenants (id),
    proposed_by   text not null default 'user' check (proposed_by in ('system', 'user')),
    source_doc_id uuid,
    diff          jsonb not null default '{}'::jsonb,
    status        text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
    created_at    timestamptz not null default now()
);
alter table public.rubric_change_requests add column if not exists resolved_by uuid;
alter table public.rubric_change_requests add column if not exists resolved_by_email text;
alter table public.rubric_change_requests add column if not exists resolved_at timestamptz;
alter table public.rubric_change_requests add column if not exists note text;
alter table public.rubric_change_requests enable row level security;

drop policy if exists rcr_select on public.rubric_change_requests;
create policy rcr_select on public.rubric_change_requests for select to authenticated
    using (tenant_id = (select current_tenant()) and (select current_user_role()) in ('admin', 'supervisor', 'team_lead'));

drop policy if exists rcr_update_admin on public.rubric_change_requests;
create policy rcr_update_admin on public.rubric_change_requests for update to authenticated
    using (tenant_id = (select current_tenant()) and (select current_user_role()) = 'admin')
    with check (tenant_id = (select current_tenant()));

-- ---------------------------------------------------------------------------------------------------------------------
-- Knowledge base: policy documents (as text) the research agent reads. Admin writes; staff reads.
-- ---------------------------------------------------------------------------------------------------------------------
create table if not exists public.knowledge_base_docs (
    id          uuid primary key default gen_random_uuid(),
    tenant_id   uuid not null default current_tenant() references public.tenants (id),
    title       text not null,
    source_url  text,
    content     text,
    uploaded_by uuid default auth.uid(),
    uploaded_at timestamptz not null default now()
);
alter table public.knowledge_base_docs add column if not exists content text;
alter table public.knowledge_base_docs add column if not exists uploaded_by uuid;
alter table public.knowledge_base_docs enable row level security;

drop policy if exists kb_select_staff on public.knowledge_base_docs;
create policy kb_select_staff on public.knowledge_base_docs for select to authenticated
    using (tenant_id = (select current_tenant()) and (select current_user_role()) in ('admin', 'supervisor', 'team_lead'));

drop policy if exists kb_insert_admin on public.knowledge_base_docs;
create policy kb_insert_admin on public.knowledge_base_docs for insert to authenticated
    with check (tenant_id = (select current_tenant()) and (select current_user_role()) = 'admin');

drop policy if exists kb_delete_admin on public.knowledge_base_docs;
create policy kb_delete_admin on public.knowledge_base_docs for delete to authenticated
    using (tenant_id = (select current_tenant()) and (select current_user_role()) = 'admin');

-- ---------------------------------------------------------------------------------------------------------------------
-- Chat messages: a supervisor's conversation with the assistant. Each person sees only their own.
-- ---------------------------------------------------------------------------------------------------------------------
create table if not exists public.chat_messages (
    id         uuid primary key default gen_random_uuid(),
    tenant_id  uuid not null default current_tenant() references public.tenants (id),
    user_id    uuid not null default auth.uid(),
    role       text not null check (role in ('user', 'assistant')),
    content    text not null,
    status     text not null default 'done' check (status in ('pending', 'done', 'error')),
    reply_to   uuid references public.chat_messages (id) on delete cascade,
    created_at timestamptz not null default now()
);
create index if not exists chat_messages_user_time on public.chat_messages (user_id, created_at);
alter table public.chat_messages enable row level security;

drop policy if exists cm_select_own on public.chat_messages;
create policy cm_select_own on public.chat_messages for select to authenticated
    using (tenant_id = (select current_tenant()) and user_id = auth.uid());

drop policy if exists cm_insert_user on public.chat_messages;
create policy cm_insert_user on public.chat_messages for insert to authenticated
    with check (tenant_id = (select current_tenant()) and user_id = auth.uid() and role = 'user'
                and (select current_user_role()) in ('admin', 'supervisor', 'team_lead'));

drop policy if exists cm_delete_own on public.chat_messages;
create policy cm_delete_own on public.chat_messages for delete to authenticated
    using (tenant_id = (select current_tenant()) and user_id = auth.uid());

-- ---------------------------------------------------------------------------------------------------------------------
-- The audit worker (role qa_worker): only what each job type needs, only inside the tenant it is working for.
-- ---------------------------------------------------------------------------------------------------------------------
do $$
begin
    if not exists (select 1 from pg_roles where rolname = 'qa_worker') then
        raise notice 'The role qa_worker does not exist, so the worker permissions were skipped. Create it first.';
        return;
    end if;

    grant select, insert on public.performance_reports to qa_worker;
    grant select, insert on public.rubric_change_requests to qa_worker;
    grant select on public.rule_feedback to qa_worker;
    grant select on public.knowledge_base_docs to qa_worker;
    grant select, insert, update on public.chat_messages to qa_worker;

    drop policy if exists pr_worker_select on public.performance_reports;
    create policy pr_worker_select on public.performance_reports for select to qa_worker
        using (tenant_id = (select current_tenant()));
    drop policy if exists pr_worker_insert on public.performance_reports;
    create policy pr_worker_insert on public.performance_reports for insert to qa_worker
        with check (tenant_id = (select current_tenant()));

    drop policy if exists rcr_worker_select on public.rubric_change_requests;
    create policy rcr_worker_select on public.rubric_change_requests for select to qa_worker
        using (tenant_id = (select current_tenant()));
    drop policy if exists rcr_worker_insert on public.rubric_change_requests;
    create policy rcr_worker_insert on public.rubric_change_requests for insert to qa_worker
        with check (tenant_id = (select current_tenant()) and proposed_by = 'system' and status = 'pending');

    drop policy if exists rf_worker_select on public.rule_feedback;
    create policy rf_worker_select on public.rule_feedback for select to qa_worker
        using (tenant_id = (select current_tenant()));

    drop policy if exists kb_worker_select on public.knowledge_base_docs;
    create policy kb_worker_select on public.knowledge_base_docs for select to qa_worker
        using (tenant_id = (select current_tenant()));

    drop policy if exists cm_worker_select on public.chat_messages;
    create policy cm_worker_select on public.chat_messages for select to qa_worker
        using (tenant_id = (select current_tenant()));
    drop policy if exists cm_worker_insert on public.chat_messages;
    create policy cm_worker_insert on public.chat_messages for insert to qa_worker
        with check (tenant_id = (select current_tenant()) and role = 'assistant');
    drop policy if exists cm_worker_update on public.chat_messages;
    create policy cm_worker_update on public.chat_messages for update to qa_worker
        using (tenant_id = (select current_tenant())) with check (tenant_id = (select current_tenant()));
end $$;
