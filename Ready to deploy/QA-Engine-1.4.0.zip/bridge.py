import asyncio
import json
import os
import re
import time
from typing import Any, Dict, List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, ConfigDict
from playwright.async_api import async_playwright, BrowserContext, Page

from bridge_tools import ToolCallAdapter, ToolCallError

app = FastAPI(title="Chrome Gemini Nano Local Bridge")

playwright_instance = None
browser_context: Optional[BrowserContext] = None
driver_page: Optional[Page] = None

DEFAULT_SYSTEM_PROMPT = "You are an automated QA auditor. Output pure JSON without markdown."
TOOL_RETRIES = 3  # a tool-calling reply that cannot be used is retried (twice), with the reason fed back to the model
# Structured output (Chrome's responseConstraint) can be slow or hang on some builds. Switch it off with
# BRIDGE_STRUCTURED_OUTPUT=off. The first call after Chrome starts is slow (the model and schema load; 2 minutes has
# been seen), so the limits are generous and the bridge warms the model up when it starts.
STRUCTURED_OUTPUT = os.environ.get("BRIDGE_STRUCTURED_OUTPUT", "on").strip().lower() != "off"
CONSTRAINT_TIMEOUT_SECONDS = float(os.environ.get("BRIDGE_CONSTRAINT_TIMEOUT_SECONDS", "150"))
MODEL_TIMEOUT_SECONDS = float(os.environ.get("BRIDGE_MODEL_TIMEOUT_SECONDS", "300"))
model_ready: bool = False

# Chrome's on-device model answers ONE request at a time. Neuro SAN's coordinator calls several auditors at once, so
# without a queue every request starts its own timeout clock while waiting for the others, and the slow ones are aborted
# (structured output) or fail. Requests therefore take the model one by one here, and the clocks only run while the
# model is really working on that request.
_model_lock: Optional[asyncio.Lock] = None
_model_lock_loop: Optional[asyncio.AbstractEventLoop] = None
_waiting_for_model: int = 0


def model_lock() -> asyncio.Lock:
    """The lock that serializes access to the model (re-created if the event loop changed, which only tests do)."""
    global _model_lock, _model_lock_loop
    loop = asyncio.get_running_loop()
    if _model_lock is None or _model_lock_loop is not loop:
        _model_lock, _model_lock_loop = asyncio.Lock(), loop
    return _model_lock


class ChatMessage(BaseModel):
    # Neuro SAN also sends assistant messages with tool_calls and "tool" messages with tool_call_id; keep those fields.
    model_config = ConfigDict(extra="allow")
    role: str
    content: Optional[str] = None


class ChatCompletionRequest(BaseModel):
    model: str = "gemini-nano"
    messages: List[ChatMessage]
    temperature: Optional[float] = 0.0
    tools: Optional[List[Dict[str, Any]]] = None
    tool_choice: Optional[Any] = None


class SummarizeRequest(BaseModel):
    text: str
    type: str = "key-points"
    format: str = "markdown"
    length: str = "short"

@app.get("/", response_class=HTMLResponse)
async def root_page():
    """Provides a local origin so Chrome allows window.LanguageModel and window.Summarizer."""
    return """
    <!DOCTYPE html>
    <html>
      <head><title>Gemini Nano Bridge Host</title></head>
      <body>
        <h2>Gemini Nano CDP Host Active</h2>
        <p>This page serves as a local secure origin for Chrome on-device AI.</p>
      </body>
    </html>
    """

async def get_or_create_page() -> Page:
    """Ensures Chrome is sitting on a secure local context, not about:blank."""
    global driver_page, browser_context
    if driver_page is None or driver_page.is_closed():
        if browser_context.pages:
            driver_page = browser_context.pages[0]
        else:
            driver_page = await browser_context.new_page()

    # If on about:blank, navigate to localhost origin
    if "about:blank" in driver_page.url or driver_page.url == "":
        try:
            await driver_page.goto("http://127.0.0.1:8000/", timeout=5000)
        except Exception:
            pass
    return driver_page

@app.on_event("startup")
async def startup_event():
    global playwright_instance, browser_context
    playwright_instance = await async_playwright().start()
    try:
        browser = await playwright_instance.chromium.connect_over_cdp("http://localhost:9222")
        browser_context = browser.contexts[0]
        print("\n[SUCCESS] Connected to Chrome DevTools Protocol on port 9222.\n")
        asyncio.create_task(warm_up())  # runs in the background; /health reports when it is done
    except Exception as e:
        print(f"\n[ERROR] Could not connect to Chrome CDP on port 9222: {e}\n")
        raise e

@app.on_event("shutdown")
async def shutdown_event():
    global playwright_instance
    if playwright_instance:
        await playwright_instance.stop()

@app.post("/api/summarize")
async def summarize_text(req: SummarizeRequest):
    """Executes on-device summarization via window.Summarizer."""
    page = await get_or_create_page()
    js_script = f"""
    async () => {{
        const SummarizerAPI = window.Summarizer || (window.ai && window.ai.summarizer);
        if (!SummarizerAPI) {{
            return JSON.stringify({{
                error: "Summarizer API not available on page: " + window.location.href
            }});
        }}
        try {{
            const summarizer = await SummarizerAPI.create({{
                type: "{req.type}",
                format: "{req.format}",
                length: "{req.length}"
            }});
            const summary = await summarizer.summarize({json.dumps(req.text)});
            if (summarizer.destroy) summarizer.destroy();
            return JSON.stringify({{ summary: summary }});
        }} catch (err) {{
            return JSON.stringify({{ error: "Summarizer.create failed: " + err.message }});
        }}
    }}
    """
    try:
        async with model_lock():  # the summarizer uses the same on-device model, so it waits for its turn too
            raw_res = await page.evaluate(js_script)
        res = json.loads(raw_res)
        if "error" in res:
            print(f"[BRIDGE ERROR] Summarize: {res['error']}")
            raise HTTPException(status_code=500, detail=res["error"])
        return res
    except Exception as e:
        print(f"[BRIDGE EXCEPTION] Summarize: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Summarization error: {str(e)}")


# Runs in Chrome. It is a constant: every value arrives in `args`, so nothing is pasted into the script text.
CHAT_JS = """
async (args) => {
    // Runs work(signal) but gives up, and aborts it, after `ms` milliseconds.
    const timed = async (work, ms) => {
        const controller = new AbortController();
        let timer;
        const timeout = new Promise((_, reject) => {
            timer = setTimeout(() => { controller.abort(); reject(new Error("timed out after " + (ms / 1000) + "s")); }, ms);
        });
        try { return await Promise.race([work(controller.signal), timeout]); } finally { clearTimeout(timer); }
    };
    const ModelAPI = window.LanguageModel || (window.ai && window.ai.languageModel);
    if (!ModelAPI) {
        return JSON.stringify({ error: "LanguageModel API not available on page: " + window.location.href });
    }
    try {
        const initialPrompts = [{ role: "system", content: args.system }];
        // Most deterministic first. Chrome's default sampling is random, so identical calls can score differently.
        // Each attempt relaxes one thing, in case this Chrome build rejects sampling options for web pages.
        const attempts = [
            { name: "deterministic", options: { initialPrompts, temperature: args.temperature, topK: 1 } },
            { name: "default-sampling", options: { initialPrompts } },
            { name: "legacy-system-prompt", options: { systemPrompt: args.system } },
        ];
        let session = null, mode = null, lastErr = null, chosenOptions = null;
        for (const attempt of attempts) {
            try {
                session = await ModelAPI.create(attempt.options);
                mode = attempt.name;
                chosenOptions = attempt.options;
                break;
            } catch (err) {
                lastErr = err;
            }
        }
        if (!session) throw lastErr;

        let output, constrained = false, constraintError = null;
        if (args.schema) {
            try {
                // Structured output: Chrome only lets the model produce JSON that matches the schema.
                output = await timed((signal) => session.prompt(args.user, { responseConstraint: args.schema, signal }),
                                     args.constraintTimeoutMs);
                constrained = true;
            } catch (err) {
                constraintError = err.message;
                // After an abort the session may be unusable, so the plain attempt gets a fresh one.
                if (session.destroy) session.destroy();
                session = await ModelAPI.create(chosenOptions);
                output = await session.prompt(args.user);
            }
        } else {
            output = await session.prompt(args.user);
        }
        if (session.destroy) session.destroy();
        return JSON.stringify({ result: output, mode: mode, constrained: constrained, constraintError: constraintError });
    } catch (err) {
        return JSON.stringify({ error: "Model execution failed: " + err.message });
    }
}
"""

_last_logged_mode: Optional[str] = None


async def run_model(page: Page, system_text: str, user_text: str, temperature: float, schema: Optional[dict] = None) -> dict:
    """Sends one prompt to Chrome's model and returns {"result", "mode", "constrained"}; 500 if Chrome reports an error."""
    global _last_logged_mode, _waiting_for_model
    try:
        lock = model_lock()
        queued: bool = lock.locked()
        if queued:
            _waiting_for_model += 1
            print(f"[BRIDGE] The model is busy; this request waits its turn ({_waiting_for_model} waiting).")
        try:
            async with lock:
                if queued:
                    _waiting_for_model -= 1
                    queued = False
                raw_res = await asyncio.wait_for(page.evaluate(CHAT_JS, {
                    "system": system_text, "user": user_text, "temperature": temperature or 0.0, "schema": schema,
                    "constraintTimeoutMs": int(CONSTRAINT_TIMEOUT_SECONDS * 1000)}), timeout=MODEL_TIMEOUT_SECONDS)
        finally:
            if queued:  # cancelled while still waiting for its turn
                _waiting_for_model -= 1
    except asyncio.TimeoutError:
        message = (f"Chrome's model did not answer within {MODEL_TIMEOUT_SECONDS:.0f}s. Is another audit using it, "
                   "or is the model still loading?")
        print(f"[BRIDGE ERROR] Chat: {message}")
        raise HTTPException(status_code=504, detail=message)
    res = json.loads(raw_res)
    if "error" in res:
        print(f"[BRIDGE ERROR] Chat: {res['error']}")
        raise HTTPException(status_code=500, detail=res["error"])

    mode = res.get("mode")
    if mode != _last_logged_mode:
        _last_logged_mode = mode
        print(f"[BRIDGE] Model sampling mode: {mode}"
              + ("" if mode == "deterministic" else "  (NOT deterministic: repeated audits may differ)"))
    if schema is not None and not res.get("constrained"):
        reason = res.get("constraintError") or "not supported by this Chrome"
        print(f"[BRIDGE] Structured output was not used ({reason}); relying on the prompt to get JSON.")
    return res


async def warm_up() -> None:
    """Loads the model once at start-up, so the first real request does not pay the 1-2 minute cold start."""
    global model_ready
    try:
        started = time.time()
        print("[BRIDGE] Warming up the model (the first call after a restart can take a minute or two)...")
        page = await get_or_create_page()
        await run_model(page, DEFAULT_SYSTEM_PROMPT, "Reply with the single word OK.", 0.0)
        model_ready = True
        print(f"[BRIDGE] Model ready after {time.time() - started:.0f}s.")
    except Exception as error:  # a failed warm-up must not stop the bridge; real requests report their own errors
        print(f"[BRIDGE] Warm-up failed: {error}")


@app.get("/health")
async def health():
    """Tells the launcher whether the model has been loaded."""
    return {"status": "ok", "model_ready": model_ready}


async def tool_turn(page: Page, req: ChatCompletionRequest, messages: List[dict], system_text: str) -> dict:
    """Answers a request that carries tools: either calls some of them or gives the final answer."""
    prompt = ToolCallAdapter.build_user_prompt(messages, req.tools, system_text)
    schema = ToolCallAdapter.response_schema(req.tools) if STRUCTURED_OUTPUT else None
    last_error: Optional[str] = None
    for attempt in range(TOOL_RETRIES):
        text = prompt if last_error is None else (
            prompt + "\n\nYOUR PREVIOUS REPLY WAS REJECTED: " + last_error + "\nReply again, following HOW TO REPLY exactly.")
        res = await run_model(page, system_text, text, req.temperature, schema)
        try:
            message = ToolCallAdapter.parse_reply(res["result"], req.tools, messages, system_text)
            names = [c["function"]["name"] for c in message.get("tool_calls") or []]
            print(f"[BRIDGE] Tool turn: {'calls ' + ', '.join(names) if names else 'final answer'}")
            return message
        except ToolCallError as error:
            last_error = str(error)
            print(f"[BRIDGE] Tool reply rejected (attempt {attempt + 1} of {TOOL_RETRIES}): {last_error}")
    raise HTTPException(status_code=500, detail=f"The model could not produce a valid tool-calling reply: {last_error}")


@app.post("/v1/chat/completions")
async def chat_completions(req: ChatCompletionRequest):
    """Executes on-device chat completion via window.LanguageModel, with tool calling for Neuro SAN agents."""
    page = await get_or_create_page()
    messages = [m.model_dump() for m in req.messages]
    system_text = "\n".join([m["content"] for m in messages if m["role"] == "system" and m.get("content")])
    system_text = system_text or DEFAULT_SYSTEM_PROMPT

    try:
        if req.tools:
            message = await tool_turn(page, req, messages, system_text)
        else:
            user_text = "\n".join([m["content"] for m in messages if m["role"] == "user" and m.get("content")])
            res = await run_model(page, system_text, user_text, req.temperature)
            content = res["result"].strip()
            content = re.sub(r"^```json\s*|^```\s*|```$", "", content, flags=re.MULTILINE).strip()
            message = {"role": "assistant", "content": content}

        return {
            "id": "chatcmpl-nano-cdp",
            "object": "chat.completion",
            "model": "gemini-nano",
            "choices": [{
                "index": 0,
                "message": message,
                "finish_reason": "tool_calls" if message.get("tool_calls") else "stop"
            }]
        }
    except HTTPException:
        raise
    except Exception as e:
        print(f"[BRIDGE EXCEPTION] Chat: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Inference error: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
