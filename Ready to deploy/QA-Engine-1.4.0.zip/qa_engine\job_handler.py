"""Interface of a handler for one kind of job (everything except audits, which JobWorker runs itself)."""

from qa_engine.tenant_database import TenantDatabase


class JobHandler:
    """Does the work of one job kind, for example a performance report or a chat answer.

    A handler reads and writes only through ``database.session(tenant_id)``, so tenant isolation is enforced by the
    database. It signals failure by raising ``BridgeError`` (the agent network or model failed), ``LookupError`` (data
    it needs is missing) or ``psycopg.Error``; the worker then retries the job and finally marks it failed.
    """

    kind: str = ""

    def handle(self, job: dict, database: TenantDatabase) -> None:
        """Processes one claimed job.

        :param job: the jobs row: ``id``, ``tenant_id``, ``kind``, ``payload`` (a dict) and ``attempts``
        :param database: tenant-scoped access to the database
        :raises NotImplementedError: when a subclass does not implement it
        """
        raise NotImplementedError
