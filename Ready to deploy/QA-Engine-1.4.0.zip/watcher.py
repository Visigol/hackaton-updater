"""Entry point for hot-folder ingestion: python watcher.py

Transcripts dropped in ./inbox are sanitized, stored in Supabase under the ingest user's tenant, and queued for the
worker (worker.py), which runs the audit. Replaces the earlier all-in-one watcher.
"""

import logging
import time

from watchdog.observers import Observer

from qa_engine.ingest_handler import IngestHandler
from qa_engine.settings import Settings


class WatcherApp:
    """Wires configuration to the ingest handler and watches the inbox folder."""

    INBOX: str = "./inbox"
    PROCESSED: str = "./processed"
    FAILED: str = "./failed"

    @staticmethod
    def main() -> None:
        """Starts the folder observer; stop with Ctrl+C."""
        logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
        logger = logging.getLogger(__name__)
        settings = Settings()
        handler = IngestHandler(
            settings.require("SUPABASE_URL"), settings.require("SUPABASE_ANON_KEY"),
            settings.require("INGEST_EMAIL"), settings.require("INGEST_PASSWORD"),
            WatcherApp.INBOX, WatcherApp.PROCESSED, WatcherApp.FAILED)
        observer = Observer()
        observer.schedule(handler, path=WatcherApp.INBOX, recursive=False)
        observer.start()
        logger.info("Watching %s for transcript files. Ctrl+C to stop.", WatcherApp.INBOX)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            observer.stop()
        observer.join()


if __name__ == "__main__":
    WatcherApp.main()
