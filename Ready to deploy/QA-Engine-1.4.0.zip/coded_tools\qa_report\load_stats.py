"""Coded tool of the qa_report network: gives the coaching agent the statistics it must write about."""

import logging
from typing import Any

from neuro_san.interfaces.coded_tool import CodedTool

logger = logging.getLogger(__name__)


class LoadStats(CodedTool):
    """Returns the agent's audit statistics, read from ``sly_data["stats"]`` and written out as plain text.

    The numbers are computed by the audit worker (qa_engine/performance_stats.py), so the model never calculates or
    invents them; it only describes them.

    Demo mode: when the network is started without ``stats`` (for example from the Neuro SAN Studio chat) a built-in
    sample is used. Anything produced that way carries ``sly_data["demo"] = True`` and the worker refuses it.
    """

    DEMO_STATS: dict[str, Any] = {
        "agent_name": "Anna (demo)", "period": "last 30 days", "audits": 12, "average_score": 78.3, "pass_rate": 67,
        "critical_fails": 2, "best_score": 100.0, "worst_score": 0.0,
        "trend": {"direction": "declining", "change": -6.5},
        "checks": [
            {"key": "compliance", "label": "Compliance & Authentication", "audited": 12, "failed": 2, "pass_rate": 83,
             "failure_reasons": ["Account charges were stated before the caller was verified."]},
            {"key": "procedural", "label": "Procedural Resolution", "audited": 12, "failed": 1, "pass_rate": 92,
             "failure_reasons": ["A refund was promised but no ticket number was given."]},
            {"key": "closing", "label": "Etiquette & Closing", "audited": 12, "failed": 3, "pass_rate": 75,
             "failure_reasons": ["The agent did not ask whether anything else was needed."]},
        ],
    }

    async def async_invoke(self, args: dict[str, Any], sly_data: dict[str, Any]) -> str:
        """Writes the statistics as text.

        :param args: none are used
        :param sly_data: the request's bulletin board; holds ``stats`` when the audit worker made the request
        :return: the statistics, one fact per line
        """
        if not sly_data.get("stats"):
            logger.warning("load_stats: no stats in sly_data, so the DEMO sample is being used")
            sly_data["stats"] = dict(self.DEMO_STATS)
            sly_data["demo"] = True
        stats: dict[str, Any] = sly_data["stats"]
        trend: dict[str, Any] = stats.get("trend") or {}
        lines: list[str] = [
            ("DEMO DATA, not real. " if sly_data.get("demo") else "") + f"Agent: {stats.get('agent_name')}. Period: {stats.get('period')}.",
            f"Audits: {stats.get('audits')}. Average score: {stats.get('average_score')}. Pass rate: {stats.get('pass_rate')}%. "
            f"Critical fails: {stats.get('critical_fails')}. Best score: {stats.get('best_score')}. Worst score: {stats.get('worst_score')}.",
            f"Trend: {trend.get('direction')}" + (f" ({trend.get('change'):+} points between the first and second half)"
                                                   if trend.get("change") is not None else "") + ".",
            "Results per check:",
        ]
        for check in stats.get("checks") or []:
            line = f"- {check.get('label')}: passed {check.get('pass_rate')}% ({check.get('failed')} failed of {check.get('audited')})."
            reasons = check.get("failure_reasons") or []
            if reasons:
                line += " Typical reasons it failed: " + " | ".join(reasons)
            lines.append(line)
        logger.info("load_stats: delivered the statistics of %s", stats.get("agent_name"))
        return "\n".join(lines)
