"""Builds the job handlers (reports, research, chat) from configuration."""

from qa_engine.chat_handler import ChatHandler
from qa_engine.job_handler import JobHandler
from qa_engine.neuro_san_client import NeuroSanClient
from qa_engine.report_handler import ReportHandler
from qa_engine.research_handler import ResearchHandler
from qa_engine.settings import Settings


class HandlerFactory:
    """Each handler runs its own agent network on the Neuro SAN server at NEURO_SAN_URL."""

    @staticmethod
    def create(settings: Settings) -> list[JobHandler]:
        """Returns one handler per extra job kind.

        RESEARCH_MIN_CORRECTIONS (default 2) is how many reviewer corrections make a rubric check worth working on.
        """
        base_url: str = settings.get("NEURO_SAN_URL", "http://127.0.0.1:8080")
        return [
            ReportHandler(NeuroSanClient(base_url, settings.get("NEURO_SAN_REPORT_NETWORK", "qa_report"))),
            ResearchHandler(NeuroSanClient(base_url, settings.get("NEURO_SAN_RESEARCH_NETWORK", "qa_research")),
                            int(settings.get("RESEARCH_MIN_CORRECTIONS", "2"))),
            ChatHandler(NeuroSanClient(base_url, settings.get("NEURO_SAN_ASSISTANT_NETWORK", "qa_assistant"))),
        ]
