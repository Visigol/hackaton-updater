"""Unit tests for parsing small-model answers."""

import unittest

from qa_engine.verdict_parser import VerdictParser


class TestVerdictParser(unittest.TestCase):
    """A verdict passes only on an explicit true; unusable output fails visibly."""

    def test_plain_json_pass(self) -> None:
        """Valid JSON with passed=true passes."""
        verdict = VerdictParser.parse('{"passed": true, "reason": "ok"}')
        self.assertTrue(verdict["passed"])

    def test_markdown_fenced_json_is_parsed(self) -> None:
        """Code fences around the JSON are stripped."""
        verdict = VerdictParser.parse('```json\n{"passed": false, "reason": "no ID check"}\n```')
        self.assertFalse(verdict["passed"])
        self.assertEqual("no ID check", verdict["reason"])

    def test_string_false_is_not_a_pass(self) -> None:
        """The string "false" must not be truthy."""
        self.assertFalse(VerdictParser.parse('{"passed": "false", "reason": "x"}')["passed"])

    def test_prose_fails_with_explicit_reason(self) -> None:
        """Free text is a failed check marked UNPARSEABLE, never a keyword-guessed pass."""
        verdict = VerdictParser.parse("The agent did well, true story.")
        self.assertFalse(verdict["passed"])
        self.assertTrue(verdict["reason"].startswith("UNPARSEABLE_MODEL_OUTPUT"))


if __name__ == "__main__":
    unittest.main()
