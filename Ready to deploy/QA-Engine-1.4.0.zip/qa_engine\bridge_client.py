"""HTTP client for bridge.py (Chrome Gemini Nano). This is the seam where other LLM providers plug in later."""

import logging

import requests

from qa_engine.bridge_error import BridgeError

logger = logging.getLogger(__name__)


class BridgeClient:
    """Calls the OpenAI-compatible chat endpoint and the summarize endpoint exposed by bridge.py."""

    SUMMARIZE_TIMEOUT_SECONDS: int = 120
    CHAT_TIMEOUT_SECONDS: int = 60

    def __init__(self, base_url: str, model: str = "gemini-nano") -> None:
        """Creates a client.

        :param base_url: bridge root URL, e.g. http://127.0.0.1:8000
        :param model: model name sent in chat requests
        """
        self._base_url: str = base_url.rstrip("/")
        self._model: str = model

    def summarize(self, text: str) -> str:
        """Returns a key-points summary produced by Chrome's on-device Summarizer.

        :param text: sanitized transcript
        :raises BridgeError: on any transport or payload problem
        """
        payload: dict = {"text": text, "type": "key-points", "length": "short"}
        body: dict = self._post("/api/summarize", payload, self.SUMMARIZE_TIMEOUT_SECONDS)
        summary: str | None = body.get("summary")
        if not summary:
            raise BridgeError(f"Summarize response had no 'summary': {body}")
        return summary

    def complete(self, user_prompt: str) -> str:
        """Returns the model's text answer to a single user prompt.

        :param user_prompt: the full audit prompt
        :raises BridgeError: on any transport or payload problem
        """
        payload: dict = {"model": self._model, "messages": [{"role": "user", "content": user_prompt}]}
        body: dict = self._post("/v1/chat/completions", payload, self.CHAT_TIMEOUT_SECONDS)
        choices: list = body.get("choices") or []
        if not choices:
            raise BridgeError(f"Chat response had no choices: {body}")
        content: str | None = (choices[0].get("message") or {}).get("content")
        if content is None:
            raise BridgeError(f"Chat response had no message content: {body}")
        return content

    def _post(self, path: str, payload: dict, timeout_seconds: int) -> dict:
        """POSTs JSON and returns the decoded body, converting every failure into BridgeError."""
        url: str = self._base_url + path
        try:
            response: requests.Response = requests.post(url, json=payload, timeout=timeout_seconds)
            response.raise_for_status()
            return response.json()
        except (requests.RequestException, ValueError) as error:
            logger.error("Bridge call to %s failed: %s", url, error)
            raise BridgeError(f"Bridge call to {url} failed: {error}") from error
