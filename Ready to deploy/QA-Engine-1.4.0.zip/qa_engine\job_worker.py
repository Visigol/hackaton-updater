"""Queue worker. Connects as the restricted qa_worker role, so every query runs under tenant Row-Level Security."""

import logging
import time

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

from qa_engine.audit_runner import AuditRunner
from qa_engine.bridge_error import BridgeError
from qa_engine.job_handler import JobHandler
from qa_engine.learned_examples import LearnedExamples
from qa_engine.tenant_database import TenantDatabase

logger = logging.getLogger(__name__)


class JobWorker:
    """Claims jobs one at a time and processes each inside its tenant's RLS scope.

    Audits are done here. Every other kind of job (reports, research, chat) is done by a ``JobHandler`` registered
    for that kind.

    Isolation design (see ROADMAP.md, section 5b): the only cross-tenant statement is public.claim_job(). Every
    other statement runs in a transaction that first sets app.current_tenant from the claimed job, so the database,
    not this code, prevents reading or writing another tenant's rows.
    """

    MAX_ATTEMPTS: int = 3
    IDLE_SLEEP_SECONDS: int = 3
    ERROR_SLEEP_SECONDS: int = 15

    def __init__(self, database_url: str, runner: AuditRunner, handlers: list[JobHandler] | None = None,
                 examples_per_check: int = 0) -> None:
        """:param database_url: transaction-pooler URL for the qa_worker role
        :param runner: executes the rubric against a transcript
        :param handlers: one handler per additional job kind
        :param examples_per_check: how many reviewer-corrected examples to show the auditors for each check (0 = none)
        """
        self._examples_per_check: int = examples_per_check
        self._database_url: str = database_url
        self._runner: AuditRunner = runner
        self._handlers: dict[str, JobHandler] = {handler.kind: handler for handler in handlers or []}
        self._database: TenantDatabase = TenantDatabase(database_url)

    @property
    def kinds(self) -> list[str]:
        """The job kinds this worker claims."""
        return ["audit", *self._handlers]

    def run_forever(self) -> None:
        """Polls the queue until interrupted. Database outages are logged and retried, not fatal."""
        logger.info("Worker started; polling for jobs of kind: %s", ", ".join(self.kinds))
        announced_idle: bool = False
        while True:
            try:
                if self.run_once():
                    announced_idle = False
                else:
                    if not announced_idle:
                        logger.info("Queue empty; waiting for new jobs")  # silence would look like a hang
                        announced_idle = True
                    time.sleep(self.IDLE_SLEEP_SECONDS)
            except psycopg.OperationalError as error:
                logger.error("Database unreachable, retrying in %ss: %s", self.ERROR_SLEEP_SECONDS, error)
                time.sleep(self.ERROR_SLEEP_SECONDS)

    def run_once(self) -> bool:
        """Claims and processes at most one job.

        :return: True if a job was processed (successfully or not), False if the queue was empty
        """
        job: dict | None = self._claim()
        if job is None:
            return False

        job_id, tenant_id = job["id"], str(job["tenant_id"])
        logger.info("Claimed %s job %s (tenant %s, attempt %s)", job.get("kind"), job_id, tenant_id, job["attempts"])
        handler: JobHandler | None = self._handlers.get(job.get("kind"))
        if handler is not None:
            self._run_handler(handler, job)
            return True
        try:
            transcript_id: str | None = (job.get("payload") or {}).get("transcript_id")
            if not transcript_id:
                raise LookupError(f"Job {job_id} payload has no transcript_id")
            transcript_text, rubric_version, rubric = self._load_context(tenant_id, transcript_id)
            examples: dict = LearnedExamples.load(self._database, tenant_id, rubric, transcript_id, self._examples_per_check)
            result: dict = self._runner.run(transcript_text, rubric, examples)
            self._save_result(tenant_id, job_id, transcript_id, rubric_version, result)
            logger.info("Job %s done: score=%s passed=%s critical_fail=%s", job_id, result["overall_score"],
                        result["passed"], result["critical_fail"])
        except (BridgeError, LookupError, psycopg.Error) as error:
            logger.error("Job %s failed: %s", job_id, error)
            self._record_failure(tenant_id, job_id, job["attempts"], str(error))
        return True

    def _run_handler(self, handler: JobHandler, job: dict) -> None:
        """Runs a non-audit job; marks it done, or records the failure so it is retried."""
        job_id, tenant_id = job["id"], str(job["tenant_id"])
        try:
            handler.handle(job, self._database)
            with self._database.session(tenant_id) as connection:
                connection.execute(
                    "update public.jobs set status = 'done', finished_at = now(), error = null where id = %s", (job_id,))
            logger.info("%s job %s done", job.get("kind"), job_id)
        except (BridgeError, LookupError, psycopg.Error) as error:
            logger.error("%s job %s failed: %s", job.get("kind"), job_id, error)
            self._record_failure(tenant_id, job_id, job["attempts"], str(error))

    def _connect(self) -> psycopg.Connection:
        """Opens a connection. Prepared statements are off because the transaction pooler cannot reuse them."""
        return psycopg.connect(self._database_url, row_factory=dict_row, prepare_threshold=None)

    @staticmethod
    def _scope_to_tenant(connection: psycopg.Connection, tenant_id: str) -> None:
        """Pins the open transaction to one tenant; 'true' makes the setting local to this transaction."""
        connection.execute("select set_config('app.current_tenant', %s, true)", (tenant_id,))

    def _claim(self) -> dict | None:
        """Atomically claims the oldest queued job of a kind this worker handles (the only cross-tenant statement)."""
        with self._connect() as connection:
            row: dict | None = connection.execute("select * from public.claim_job(%s)", (self.kinds,)).fetchone()
        return row if row and row.get("id") else None

    def _load_context(self, tenant_id: str, transcript_id: str) -> tuple[str, int, dict]:
        """Reads the transcript text and the tenant's active rubric under RLS."""
        with self._connect() as connection:
            self._scope_to_tenant(connection, tenant_id)
            transcript: dict | None = connection.execute(
                "select raw_text from public.transcripts where id = %s", (transcript_id,)).fetchone()
            rubric: dict | None = connection.execute(
                "select version, parameters from public.rubrics where is_active").fetchone()
        if transcript is None:
            raise LookupError(f"Transcript {transcript_id} not visible to tenant {tenant_id}")
        if rubric is None:
            raise LookupError(f"Tenant {tenant_id} has no active rubric")
        return transcript["raw_text"], rubric["version"], rubric["parameters"]

    def _save_result(self, tenant_id: str, job_id: str, transcript_id: str, rubric_version: int, result: dict) -> None:
        """Writes the score (idempotent per transcript and rubric version) and closes the job in one transaction."""
        with self._connect() as connection:
            self._scope_to_tenant(connection, tenant_id)
            connection.execute(
                """insert into public.audit_scores
                       (tenant_id, transcript_id, rubric_version, scores, flags, overall_score, passed, critical_fail)
                   values (%s, %s, %s, %s, %s, %s, %s, %s)
                   on conflict (transcript_id, rubric_version) do update set
                       scores = excluded.scores, flags = excluded.flags, overall_score = excluded.overall_score,
                       passed = excluded.passed, critical_fail = excluded.critical_fail, scored_at = now()""",
                (tenant_id, transcript_id, rubric_version, Jsonb(result["scores"]), Jsonb(result["flags"]),
                 result["overall_score"], result["passed"], result["critical_fail"]))
            connection.execute(
                "update public.jobs set status = 'done', finished_at = now(), error = null where id = %s", (job_id,))

    def _record_failure(self, tenant_id: str, job_id: str, attempts: int, message: str) -> None:
        """Requeues the job until MAX_ATTEMPTS is reached, then marks it failed with the error text."""
        status: str = "failed" if attempts >= self.MAX_ATTEMPTS else "queued"
        with self._connect() as connection:
            self._scope_to_tenant(connection, tenant_id)
            connection.execute(
                "update public.jobs set status = %s, error = %s, finished_at = now() where id = %s",
                (status, message[:1000], job_id))
