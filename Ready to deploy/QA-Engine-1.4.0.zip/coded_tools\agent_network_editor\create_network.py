# Copyright © 2025-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT

import logging
from typing import Any

from neuro_san.interfaces.coded_tool import CodedTool

from coded_tools.agent_network_editor.agent_name_guard import AgentNameGuard
from coded_tools.agent_network_editor.and_logger import AndLogger
from coded_tools.agent_network_editor.constants import AGENT_NETWORK_DEFINITION
from coded_tools.agent_network_editor.constants import AGENT_NETWORK_NAME
from coded_tools.agent_network_editor.progress_handler import ProgressHandler


class CreateNetwork(CodedTool):
    """
    CodedTool implementation which creates an agent network definition with agent name as key
    and empty dictionary as value then store in sly data.

    Note that if there exists an agent network definition in the sly data, it will be reset and overwritten.

    Agent network definition is a structured representation of an agent network, expressed as a dictionary.
    Each key is an agent name, and its value is an object containing:
    - a description of the agent
    - an instructions to the agent
    - a list of down-chain agents (agents reporting to it)
    """

    async def async_invoke(self, args: dict[str, Any], sly_data: dict[str, Any]) -> dict[str, Any] | str:
        """
        :param args: An argument dictionary whose keys are the parameters
                to the coded tool and whose values are the values passed for them
                by the calling agent.  This dictionary is to be treated as read-only.

                The argument dictionary expects the following keys:
                    "agent_names": list of the names of the agents in the network
                    "is_tool_list": list of booleans indicating whether each agent is a function or not.
                        Must be the same length as agent_names.

        :param sly_data: A dictionary whose keys are defined by the agent hierarchy,
                but whose values are meant to be kept out of the chat stream.

                This dictionary is largely to be treated as read-only.
                It is possible to add key/value pairs to this dict that do not
                yet exist as a bulletin board, as long as the responsibility
                for which coded_tool publishes new entries is well understood
                by the agent chain implementation and the coded_tool implementation
                adding the data is not invoke()-ed more than once.

                Keys expected for this implementation are:
                    None

        :return:
            In case of successful execution:
                a text string confirming successful creation of the agent network definition.
            otherwise:
                a text string of an error message in the format:
                "Error: <error message>"
        """
        agent_network_name: str = args.get("agent_network_name")
        if not agent_network_name:
            return "Error: No agent_network_name provided."
        # Type-check before len()/iteration: a non-list (str/dict) or wrong element types
        # would otherwise be iterated per-character/per-key and build a bogus network.
        agent_names: list[str] = args.get("agent_names")
        if (
            not agent_names
            or not isinstance(agent_names, list)
            or not all(isinstance(name, str) for name in agent_names)
        ):
            return "Error: agent_names must be a non-empty list of strings."
        is_tool_list: list[bool] = args.get("is_tool_list")
        if (
            not is_tool_list
            or not isinstance(is_tool_list, list)
            or not all(isinstance(flag, bool) for flag in is_tool_list)
        ):
            return "Error: is_tool_list must be a non-empty list of booleans."
        if len(agent_names) != len(is_tool_list):
            return "Error: The length of agent_names and is_tool_list must be the same."
        # Validate all node names before mutating sly_data, so an invalid name doesn't
        # leave a partially-created network. Collect every offending name so the caller
        # can fix them all in one pass rather than one per turn. External references must
        # be referenced inside a tools list, not created as nodes; local names must be
        # valid tool names.
        name_errors: list[str] = []
        for agent_name in agent_names:
            name_error: str | None = AgentNameGuard.agent_name_error(agent_name)
            if name_error:
                name_errors.append(name_error)
        if name_errors:
            return "\n".join(name_errors)

        logger = AndLogger(logging.getLogger(self.__class__.__name__))
        logger.info(">>>>>>>>>>>>>>>>>>Create New Agent Netwrok Definiton for %s>>>>>>>>>>>>>>>>>", agent_network_name)
        # Reset/overwrite any existing network only after all inputs validate.
        sly_data[AGENT_NETWORK_DEFINITION] = {}
        for i, agent_name in enumerate(agent_names):
            logger.info(">>>>>>>>>>>>>>>>>>>Adding Agent>>>>>>>>>>>>>>>>>>")
            logger.info("Agent Name: %s", agent_name)
            logger.info("Is Tool: %s", str(is_tool_list[i]))
            sly_data[AGENT_NETWORK_DEFINITION][agent_name] = {}
            if not is_tool_list[i]:
                sly_data[AGENT_NETWORK_DEFINITION][agent_name]["instructions"] = ""
                sly_data[AGENT_NETWORK_DEFINITION][agent_name]["description"] = ""
        logger.info("The resulting agent network definition: \n %s", str(sly_data[AGENT_NETWORK_DEFINITION]))

        # Put the agent network name in the sly data
        sly_data[AGENT_NETWORK_NAME] = agent_network_name

        await ProgressHandler.report_progress(
            args, sly_data, sly_data[AGENT_NETWORK_DEFINITION], sly_data[AGENT_NETWORK_NAME]
        )

        logger.debug(">>>>>>>>>>>>>>>>>>> DONE %s !!!>>>>>>>>>>>>>>>>>>", self.__class__.__name__)
        return f"Successfully created agent network definition for {agent_network_name}."
