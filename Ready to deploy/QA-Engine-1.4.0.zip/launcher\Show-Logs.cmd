@echo off
title QA Engine - Show logs
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0show-logs.ps1" %*
timeout /t 3 >nul
