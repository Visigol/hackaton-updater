import json, time, os
os.makedirs("./inbox", exist_ok=True)
payload = {
    "id": f"call-{int(time.time())}",
    "tenant_id": "tenant-boltverse",
    "agent_id": "AGT-8821",
    "customer_id": "CUST-4102",
    "call_duration_seconds": 210,
    "raw_transcript": """Agent: Thank you for calling Boltverse Support, my name is Marcus. This call is monitored and recorded for quality assurance.
Customer: Hi Marcus, I have an unauthorized $45 charge on my card 4112-3341-8899-2210. My SSN is 000-12-3456.
Agent: I can help resolve that. Could you verify your account number for verification?
Customer: Yes, it is ACT-99201.
Agent: Thank you. Identity verified. I see the charge was an error, and I have credited the $45 back to your account immediately.
Customer: That is great news, thank you Marcus.
Agent: You are welcome. Is there anything else I can assist you with today?
Customer: No, that covers everything.
Agent: Thank you for choosing Boltverse. Have a great day!"""
}
with open("./inbox/sample_call.json", "w", encoding="utf-8") as f:
    json.dump(payload, f, indent=2)
print("Dropped test file into ./inbox/sample_call.json")