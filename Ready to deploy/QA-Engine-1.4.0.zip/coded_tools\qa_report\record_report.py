"""Coded tool of the qa_report network: records the coaching report an agent wrote."""

import logging
import re
from typing import Any

from neuro_san.interfaces.coded_tool import CodedTool

logger = logging.getLogger(__name__)


class RecordReport(CodedTool):
    """Stores the report under ``sly_data["report"]``, the key the front man returns to the audit worker."""

    MAX_ITEMS: int = 5
    MAX_TEXT: int = 400
    LIST_MARKER: re.Pattern[str] = re.compile(r"^\s*(?:[-*•]|\d+[.)])\s+")  # "- ", "* ", "1. ", "2) "

    async def async_invoke(self, args: dict[str, Any], sly_data: dict[str, Any]) -> str:
        """Validates and records the report.

        :param args: ``summary`` (text), and ``strengths``, ``improvements``, ``actions`` (lists, or text with one item per line)
        :param sly_data: the request's bulletin board
        :return: a confirmation, or a message that tells the agent what is missing so it can call again
        """
        summary: str = str(args.get("summary") or "").strip()[:self.MAX_TEXT * 2]
        improvements: list[str] = self._as_list(args.get("improvements"))
        actions: list[str] = self._as_list(args.get("actions"))
        if not summary:
            return "The report needs a summary of two or three sentences. Call record_report again with it."
        if not improvements and not actions:
            return "The report needs at least one improvement or one action. Call record_report again."

        sly_data["report"] = {"summary": summary, "strengths": self._as_list(args.get("strengths")),
                              "improvements": improvements, "actions": actions}
        if sly_data.get("demo"):
            sly_data["report"]["demo"] = True  # the audit worker refuses demo reports
        logger.info("record_report: recorded a report with %d improvements and %d actions", len(improvements), len(actions))
        return "Recorded the report."

    @staticmethod
    def _as_list(value: Any) -> list[str]:
        """A list of short strings, from a list or from text with one item per line."""
        items: list[Any] = value if isinstance(value, list) else str(value or "").splitlines()
        cleaned: list[str] = [RecordReport.LIST_MARKER.sub("", str(item)).strip() for item in items]
        return [item[:RecordReport.MAX_TEXT] for item in cleaned if item][:RecordReport.MAX_ITEMS]
