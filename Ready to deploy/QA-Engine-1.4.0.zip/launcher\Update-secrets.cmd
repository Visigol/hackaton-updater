@echo off
title QA Engine - Update secrets
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update-secrets.ps1" %*
echo.
pause
