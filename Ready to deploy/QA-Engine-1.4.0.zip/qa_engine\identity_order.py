"""Computes, from the transcript text alone, whether the agent verified the caller BEFORE stating account details.

A small model cannot reliably compare the order of two lines in a long call, but code can. The result is given to the
auditor as a fact, and it decides the verdict of the identity check itself when the lines are found.
"""

import re


class IdentityOrder:
    """Finds the first account detail the agent states and the first identity question the agent asks."""

    AGENT_LINE: re.Pattern[str] = re.compile(r"^\s*agent\s*:\s*(.*)$", re.IGNORECASE)
    CUSTOMER_LINE: re.Pattern[str] = re.compile(r"^\s*customer\s*:\s*(.*)$", re.IGNORECASE)

    # Something only the account holder should be asked: a date of birth, a PIN or a security answer.
    VERIFICATION: re.Pattern[str] = re.compile(
        r"\b(date of birth|birth ?date|dob|data de nascimento|pin|passcode|security (?:answer|question|code|password)"
        r"|palavra[- ]passe)\b", re.IGNORECASE)
    ASKING: re.Pattern[str] = re.compile(
        r"\?|\b(could you|can you|may i|please|confirm|verify|provide|give me|tell me|what is|what's|need)\b", re.IGNORECASE)

    NUMBER_WORDS: str = (r"one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|"
                         r"seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand")
    MONEY_DIGITS: re.Pattern[str] = re.compile(
        r"[$€£]\s?\d[\d.,]*|\b\d[\d.,]*\s?(?:dollars?|euros?|eur|usd|gbp|pounds?)\b", re.IGNORECASE)
    MONEY_WORDS: re.Pattern[str] = re.compile(
        rf"\b(?:{NUMBER_WORDS})\b[a-z\s-]{{0,40}}?\b(?:dollars?|euros?|cents?)\b", re.IGNORECASE)
    OTHER_DETAILS: re.Pattern[str] = re.compile(
        r"\bbilling address\b|\bcard (?:on file )?(?:ends|ending)\b|\bbalance (?:is|of|comes|stands)\b", re.IGNORECASE)

    CHECK_WORDS: re.Pattern[str] = re.compile(r"identity|verification", re.IGNORECASE)
    QUOTE_LENGTH: int = 170

    @staticmethod
    def applies_to(key: str, label: str) -> bool:
        """True for the check that is only about verifying the caller (not a broader compliance check)."""
        text: str = f"{key or ''} {label or ''}"
        return bool(IdentityOrder.CHECK_WORDS.search(text)) and "compliance" not in text.lower()

    @staticmethod
    def analyze(transcript: str) -> dict | None:
        """Returns the facts, or None when the transcript has no "Agent:" lines to read.

        :return: {"outcome": "ok" | "details_before_verification" | "details_without_verification" | "unknown",
                  "detail_line", "detail_text", "verification_line", "verification_text"} (line numbers start at 1)
        """
        lines: list[str] = [line for line in (transcript or "").splitlines() if line.strip()]
        detail: tuple[int, str] | None = None
        verification: tuple[int, str] | None = None
        customer_said: str = ""
        found_agent: bool = False
        for number, line in enumerate(lines, 1):
            customer = IdentityOrder.CUSTOMER_LINE.match(line)
            if customer:
                customer_said += " " + customer.group(1).lower()
                continue
            agent = IdentityOrder.AGENT_LINE.match(line)
            if not agent:
                continue
            found_agent = True
            text: str = agent.group(1).strip()
            if verification is None and IdentityOrder.VERIFICATION.search(text) and IdentityOrder.ASKING.search(text):
                verification = (number, text)
            if detail is None and IdentityOrder._reveals_detail(text, customer_said):
                detail = (number, text)
        if not found_agent:
            return None

        if detail and (verification is None or verification[0] > detail[0]):
            outcome = "details_without_verification" if verification is None else "details_before_verification"
        elif verification:
            outcome = "ok"
        else:
            outcome = "unknown"
        return {"outcome": outcome,
                "detail_line": detail[0] if detail else None, "detail_text": detail[1] if detail else "",
                "verification_line": verification[0] if verification else None,
                "verification_text": verification[1] if verification else ""}

    @staticmethod
    def _reveals_detail(agent_text: str, customer_said: str) -> bool:
        """True when the agent states an amount or other account detail the customer had not already said."""
        if IdentityOrder.OTHER_DETAILS.search(agent_text):
            return True
        for match in IdentityOrder.MONEY_DIGITS.finditer(agent_text):
            digits: str = re.sub(r"\D", "", match.group(0))
            if digits and digits not in re.sub(r"\D", "", customer_said):
                return True
        for match in IdentityOrder.MONEY_WORDS.finditer(agent_text):
            if match.group(0).lower() not in customer_said:
                return True
        return False

    @staticmethod
    def facts_text(facts: dict | None) -> str:
        """The paragraph handed to the auditor, or an empty string when nothing was found."""
        if not facts or facts["outcome"] == "unknown":
            return ""
        if facts["outcome"] == "ok":
            sentence = (f'The agent asked the identity question on line {facts["verification_line"]}'
                        + (f' and first stated an account detail on line {facts["detail_line"]}, which is AFTER it.'
                           if facts["detail_line"] else " and stated no account detail before it."))
        elif facts["outcome"] == "details_before_verification":
            sentence = (f'The agent first stated an account detail on line {facts["detail_line"]}, BEFORE asking the identity '
                        f'question on line {facts["verification_line"]}. That breaks the order rule.')
        else:
            sentence = (f'The agent stated an account detail on line {facts["detail_line"]} and never asked a PIN, '
                        "security answer or date of birth question.")
        return "COMPUTED FACTS (counted by code, reliable): " + sentence + "\n"

    @staticmethod
    def reason(facts: dict) -> str:
        """The verdict reason written from the facts, quoting the lines so a person can check them."""
        detail: str = f'line {facts["detail_line"]}: "{facts["detail_text"][:IdentityOrder.QUOTE_LENGTH]}"' if facts["detail_line"] else ""
        asked: str = (f'line {facts["verification_line"]}: "{facts["verification_text"][:IdentityOrder.QUOTE_LENGTH]}"'
                      if facts["verification_line"] else "")
        if facts["outcome"] == "details_before_verification":
            return f"Account details were stated before the caller was verified. Detail at {detail}. Verification only at {asked}."
        if facts["outcome"] == "details_without_verification":
            return f"The caller was never asked for a PIN, security answer or date of birth, yet account details were stated at {detail}."
        return f"The caller was verified at {asked}" + (f", before any account detail ({detail})." if detail else " and no account detail came before it.")
