"""Entry point: python switch_llm.py [nano|gemini]

Points every QA agent network at Chrome's Gemini Nano or at cloud Gemini. With no argument it reads AI_PROVIDER from the
environment / .env (default nano), plus GEMINI_MODEL and GEMINI_TEMPERATURE for gemini. The launcher runs it on every
start, so changing AI_PROVIDER in .env is all it takes.
"""

import argparse
import logging
import sys
from pathlib import Path

from qa_engine.llm_switch import LlmSwitch
from qa_engine.settings import Settings


class SwitchApp:
    """Reads the provider and applies it to the registries folder next to this file."""

    @staticmethod
    def main() -> int:
        """Applies the provider; returns the process exit code."""
        logging.basicConfig(level=logging.INFO, format="%(message)s")
        parser = argparse.ArgumentParser(description="Switch the language model of the QA agent networks.")
        parser.add_argument("provider", nargs="?", choices=LlmSwitch.PROVIDERS, help="nano or gemini (default: AI_PROVIDER)")
        parser.add_argument("--registries", default=str(Path(__file__).resolve().parent / "registries"))
        arguments = parser.parse_args()

        settings = Settings()
        provider: str = arguments.provider or settings.get("AI_PROVIDER", "nano").strip().lower()
        model: str = settings.get("GEMINI_MODEL", "").strip()
        temperature_text: str = settings.get("GEMINI_TEMPERATURE", "").strip()
        try:
            temperature: float | None = float(temperature_text) if temperature_text else None
            changed = LlmSwitch.apply(Path(arguments.registries), provider, model, temperature)
        except (ValueError, FileNotFoundError) as error:
            print(f"switch_llm: {error}", file=sys.stderr)
            return 1
        if provider == "gemini" and not settings.get("GOOGLE_API_KEY", ""):
            print("switch_llm: WARNING AI_PROVIDER is gemini but GOOGLE_API_KEY is not set.", file=sys.stderr)
        print(f"AI provider: {provider}" + (f" ({model or LlmSwitch.DEFAULT_GEMINI_MODEL})" if provider == "gemini" else "")
              + (f"; updated {', '.join(changed)}" if changed else "; already up to date"))
        return 0


if __name__ == "__main__":
    sys.exit(SwitchApp.main())
