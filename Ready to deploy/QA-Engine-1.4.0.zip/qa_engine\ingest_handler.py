"""Hot-folder ingestion: sanitizes a dropped transcript, stores it, and enqueues an audit job."""

import json
import logging
import os
import shutil
import time

from postgrest.exceptions import APIError
from supabase import Client
from supabase import create_client
from watchdog.events import FileSystemEvent
from watchdog.events import FileSystemEventHandler

from preprocessor import DeterministicSanitizer

try:
    from supabase_auth.errors import AuthError  # newer supabase releases
except ImportError:  # the auth client was renamed; older releases ship it as gotrue
    from gotrue.errors import AuthError

logger = logging.getLogger(__name__)


class IngestHandler(FileSystemEventHandler):
    """Signs in as a real tenant user, so every insert is subject to Row-Level Security like any user's.

    The tenant is never taken from the file: it comes from the signed-in user's row in public.users.
    """

    def __init__(self, supabase_url: str, anon_key: str, email: str, password: str, inbox: str, processed: str,
                 failed: str) -> None:
        """:param supabase_url: project URL
        :param anon_key: publishable key (safe in clients only because RLS is on)
        :param email: ingest user login
        :param password: ingest user password
        :param inbox: watched folder
        :param processed: folder for ingested files
        :param failed: folder for files that could not be ingested
        """
        self._client: Client = create_client(supabase_url, anon_key)
        self._email: str = email
        self._password: str = password
        self._processed: str = processed
        self._failed: str = failed
        for folder in (inbox, processed, failed):
            os.makedirs(folder, exist_ok=True)

    def on_created(self, event: FileSystemEvent) -> None:
        """Override of FileSystemEventHandler: ingest each new .json file."""
        if event.is_directory or not str(event.src_path).endswith(".json"):
            return
        time.sleep(0.5)  # let the writer finish flushing the file
        self.ingest(str(event.src_path))

    def ingest(self, filepath: str) -> None:
        """Stores one transcript and enqueues its audit; moves the file to processed/ or failed/."""
        logger.info("New transcript: %s", filepath)
        try:
            with open(filepath, "r", encoding="utf-8") as file:
                record: dict = json.load(file)
            tenant_id: str = self._sign_in()
            sanitized: str = DeterministicSanitizer.mask_pii(record["raw_transcript"])
            transcript_row: dict = {
                "tenant_id": tenant_id,
                "external_ref": record.get("id"),
                "agent_name": record.get("agent_id", "UNKNOWN"),
                "call_duration_seconds": record.get("call_duration_seconds"),
                "raw_text": sanitized,  # PII never reaches the database
            }
            stored = self._client.table("transcripts").upsert(
                transcript_row, on_conflict="tenant_id,external_ref").execute()
            transcript_id: str = stored.data[0]["id"]
            self._client.table("jobs").insert(
                {"tenant_id": tenant_id, "kind": "audit", "payload": {"transcript_id": transcript_id}}).execute()
            logger.info("Queued audit for %s (transcript %s)", record.get("id"), transcript_id)
            shutil.move(filepath, os.path.join(self._processed, os.path.basename(filepath)))
        except (OSError, json.JSONDecodeError, KeyError, IndexError, APIError, AuthError) as error:
            logger.error("Ingest failed for %s: %s", filepath, error)
            if os.path.exists(filepath):
                shutil.move(filepath, os.path.join(self._failed, os.path.basename(filepath)))

    def _sign_in(self) -> str:
        """Signs in (tokens expire after an hour, so this runs per file) and returns the user's tenant id."""
        session = self._client.auth.sign_in_with_password({"email": self._email, "password": self._password})
        user_id: str = session.user.id
        rows = self._client.table("users").select("tenant_id").eq("id", user_id).execute().data
        if not rows:
            raise KeyError(f"User {self._email} has no row in public.users (or the access-token hook is not enabled)")
        return rows[0]["tenant_id"]
