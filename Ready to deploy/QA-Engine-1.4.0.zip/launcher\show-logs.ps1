# Opens one live window per log of the running QA engine and tiles them on the screen (for demos).
# It only READS the log files: it does not start, stop or change the engine. Start the engine first.
param([switch]$All)      # -All also shows the watcher and Studio logs

$ErrorActionPreference = 'Continue'
. "$PSScriptRoot\common.ps1"

# Which AI is in use decides whether there is a bridge log (cloud Gemini has none).
$provider = 'nano'
$statusFile = Join-Path $script:RunDir 'status.json'
if (Test-Path $statusFile) { $saved = Get-Content $statusFile -Raw | ConvertFrom-Json; if ($saved.provider) { $provider = $saved.provider } }

$windows = @(
    @{ Title = 'WORKER - audits, reports, research and chat jobs'; Log = 'worker'; Color = 'Green' },
    @{ Title = 'AGENTS - who talks to whom'; Log = 'agents'; Color = 'White' }
)
if ($provider -eq 'nano') { $windows += @{ Title = 'BRIDGE - Gemini Nano in Chrome'; Log = 'bridge'; Color = 'Yellow' } }
$windows += @{ Title = 'NEURO SAN - agent network server'; Log = 'neurosan'; Color = 'Cyan' }
if ($All) {
    $windows += @{ Title = 'WATCHER - transcript inbox'; Log = 'watcher'; Color = 'Magenta' }
    $windows += @{ Title = 'STUDIO'; Log = 'studio'; Color = 'Gray' }
}

New-Item -ItemType Directory -Force -Path $script:LogDir | Out-Null
if (-not (Test-Path (Join-Path $script:RunDir 'supervisor.pid'))) { Write-Warn 'The engine does not seem to be running. Start it first (QA Engine - Start); the windows will fill when it does.' }

Add-Type -AssemblyName System.Windows.Forms
Add-Type -Namespace Win32 -Name Tile -MemberDefinition '[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool MoveWindow(System.IntPtr hWnd, int x, int y, int width, int height, bool repaint);' -ErrorAction SilentlyContinue
$area = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$count = $windows.Count
$columns = if ($count -le 2) { $count } else { 2 }
$rows = [Math]::Ceiling($count / $columns)
$width = [int]($area.Width / $columns)
$height = [int]($area.Height / $rows)

$index = 0
foreach ($window in $windows) {
    $logPath = Join-Path $script:LogDir ($window.Log + '.log')
    if (-not (Test-Path $logPath)) { New-Item -ItemType File -Path $logPath -Force | Out-Null }   # so the tail can start before the first line
    $title = $window.Title
    $script = @"
`$Host.UI.RawUI.WindowTitle = '$title'
`$Host.UI.RawUI.BackgroundColor = 'Black'
`$Host.UI.RawUI.ForegroundColor = '$($window.Color)'
Clear-Host
Write-Host '$title' -ForegroundColor White
Write-Host ('-' * 70) -ForegroundColor DarkGray
Get-Content -Path '$logPath' -Encoding UTF8 -Wait -Tail 40
"@
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($script))
    $process = Start-Process powershell -ArgumentList '-NoLogo', '-NoExit', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', $encoded -PassThru
    for ($i = 0; $i -lt 40 -and $process.MainWindowHandle -eq [IntPtr]::Zero; $i++) { Start-Sleep -Milliseconds 150; $process.Refresh() }
    if ($process.MainWindowHandle -ne [IntPtr]::Zero) {
        $column = $index % $columns
        $row = [Math]::Floor($index / $columns)
        [Win32.Tile]::MoveWindow($process.MainWindowHandle, $area.X + $column * $width, $area.Y + $row * $height, $width, $height, $true) | Out-Null
    }
    $index++
}
Write-Ok ("Opened $count log window(s). Close them with the X; the engine keeps running.")
